import type { SSEEvent } from '../types';

/**
 * Helper that creates a resilient `EventSource` that automatically
 * reconnects using exponential back‑off.
 *
 * @param url          SSE endpoint (e.g. '/simulate/stream')
 * @param onEvent      Callback for every parsed SSEEvent
 * @param onError      Optional error callback
 * @returns           An object with a `close()` method.
 */
export function createResilientEventSource(
  url: string,
  onEvent: (e: SSEEvent) => void,
  onError?: (err: any) => void
) {
  // Back‑off configuration
  const INITIAL_DELAY = 500; // ms
  const MAX_DELAY = 30_000; // 30 s
  const FACTOR = 2;

  let attempt = 0;
  let timeoutId: ReturnType<typeof setTimeout> | null = null;
  let es: EventSource | null = null;

  const connect = () => {
    try {
        es = new EventSource(url);

        es.onopen = () => {
            attempt = 0; // Reset attempts on successful connection
            console.log("⚡️ SSE connection opened.");
        };

        es.onmessage = ev => {
          try {
            const parsed: SSEEvent = JSON.parse(ev.data);
            onEvent(parsed);
          } catch (e) {
            console.error('⚡️ SSE JSON parse error', e);
          }
        };

        es.onerror = err => {
          if (es?.readyState === EventSource.CLOSED) {
              console.warn('⚡️ SSE connection closed by server or network error.');
          }
          es?.close();
          es = null;
          
          onError?.(err);

          const delay = Math.min(INITIAL_DELAY * Math.pow(FACTOR, attempt), MAX_DELAY);
          attempt += 1;
          timeoutId = setTimeout(connect, delay);
          console.warn(`⚡️ SSE reconnecting in ${delay} ms (attempt #${attempt})`);
        };
    } catch(e) {
        onError?.(e);
    }
  };

  connect();

  return {
    /** Gracefully close the stream and cancel any scheduled reconnect. */
    close() {
      if (es) es.close();
      if (timeoutId) clearTimeout(timeoutId);
      console.log("⚡️ SSE connection manually closed.");
    },
  };
}
