import { IdeaEvaluation, MvpBlueprint, PitchDeck, InvestorSummary } from '../types/mvpStudio';

const API_BASE_URL = 'http://localhost:8000';

export const mvpStudioService = {
  async evaluateIdea(idea: string): Promise<IdeaEvaluation> {
    console.log('API: evaluateIdea called with:', idea);
    await new Promise(resolve => setTimeout(resolve, 3000));

    const isReject = idea.toLowerCase().includes('kava');
    const verdict = isReject ? 'REJECT' : 'PROCEED';

    const mockEvaluation: IdeaEvaluation = {
      verdict: verdict,
      score: idea.length % 10 < 5 ? 6.5 : 8.2,
      summary: `SlavkoKernel council je analizirao vašu ideju i donio odluku.`,
      pattern_analysis: `Prepoznati obrazac: ${idea.toLowerCase().includes('marketplace') ? 'P2P Marketplace' : 'B2B SaaS'}.`,
      risk_assessment: `Glavni rizici: ${isReject ? 'Zasićeno tržište, niska marža.' : 'Tehnička kompleksnost, skalabilnost.'}`,
      eval_notes: `Detaljna analiza pokazuje snažan potencijal u niši, ali zahtijeva fokus na UX.`,
      think_recommendation: `Preporuka: Fokusirajte se na validaciju tržišta i izgradnju minimalnog seta funkcionalnosti.`,
      logs: [
        { timestamp: new Date().toISOString(), agent: 'SYSTEM', message: 'Inicijalizacija SlavkoKernel councila...', status: 'INFO' },
        { timestamp: new Date().toISOString(), agent: 'PATTERN_AGENT', message: 'Analiziram poslovni obrazac...', status: 'PROCESSING' },
        { timestamp: new Date().toISOString(), agent: 'PATTERN_AGENT', message: 'Prepoznat obrazac: P2P Marketplace.', status: 'SUCCESS' },
        { timestamp: new Date().toISOString(), agent: 'RISK_AGENT', message: 'Procjenjujem rizike...', status: 'PROCESSING' },
        { timestamp: new Date().toISOString(), agent: 'RISK_AGENT', message: 'Identificirani ključni rizici: tehnička kompleksnost, tržišna validacija.', status: 'SUCCESS' },
        { timestamp: new Date().toISOString(), agent: 'EVAL_AGENT', message: 'Evaluacija potencijala i inovativnosti...', status: 'PROCESSING' },
        { timestamp: new Date().toISOString(), agent: 'EVAL_AGENT', message: 'Ocjena: 8.2/10, Potencijal: VISOK.', status: 'SUCCESS' },
        { timestamp: new Date().toISOString(), agent: 'THINK_AGENT', message: 'Sintetiziram sve podatke...', status: 'PROCESSING' },
        { timestamp: new Date().toISOString(), agent: 'THINK_AGENT', message: 'Konačni sažetak generiran.', status: 'SUCCESS' },
        { timestamp: new Date().toISOString(), agent: 'COUNCIL', message: 'Council donosi konačnu odluku...', status: 'PROCESSING' },
        { timestamp: new Date().toISOString(), agent: 'COUNCIL', message: `Odluka: ${verdict}.`, status: 'SUCCESS' },
      ],
    };

    if (mockEvaluation.verdict === 'REJECT') {
      mockEvaluation.logs.push({
        timestamp: new Date().toISOString(),
        agent: 'SYSTEM',
        message: 'Ideja nije prošla prag. Potrebna je revizija.',
        status: 'ERROR',
      });
    }

    return mockEvaluation;
  },

  async generateMvp(idea: string, evaluation: IdeaEvaluation): Promise<MvpBlueprint> {
    console.log('API: generateMvp called with:', idea, evaluation);
    await new Promise(resolve => setTimeout(resolve, 4000));

    const mockMvpBlueprint: MvpBlueprint = {
      project_name: `MVP za ${idea.substring(0, 30)}...`,
      value_proposition: `Brza validacija ideje kroz funkcionalni prototip.`,
      target_users: ['Rani usvajači', 'Beta testeri'],
      core_flows: [
        { name: 'Registracija korisnika', steps: ['Unos emaila', 'Potvrda lozinke', 'Onboarding tour'] },
        { name: 'Glavna funkcionalnost', steps: ['Kreiranje stavke', 'Uređivanje', 'Brisanje'] },
      ],
      ui_sections: [
        { id: 'hero', type: 'hero', heading: 'Dobrodošli u vaš MVP!', copy: 'Ovo je početna stranica vašeg prototipa.', cta_text: 'Započnite' },
        { id: 'features', type: 'features', heading: 'Ključne značajke', copy: 'Brzo testirajte najvažnije funkcionalnosti.', cta_text: 'Saznajte više' },
        { id: 'pricing', type: 'pricing', heading: 'Cijene', copy: 'Jednostavan model za rane korisnike.', cta_text: 'Odaberite plan' },
        { id: 'cta', type: 'cta', heading: 'Spremni za testiranje?', copy: 'Počnite koristiti vaš MVP odmah.', cta_text: 'Registrirajte se' },
      ],
      tech_stack: ['React', 'Node.js', 'PostgreSQL'],
      estimated_time_weeks: 4,
    };
    return mockMvpBlueprint;
  },

  async generatePitchDeck(
    idea: string,
    evaluation: IdeaEvaluation,
    mvpBlueprint: MvpBlueprint
  ): Promise<PitchDeck> {
    console.log('API: generatePitchDeck called');
    await new Promise(resolve => setTimeout(resolve, 2000));

    const mockPitchDeck: PitchDeck = {
      slides: [
        { title: 'Problem', bullets: ['Tržište ima problem X', 'Postojeća rješenja su neadekvatna'] },
        { title: 'Rješenje', bullets: ['Naš MVP nudi Y', 'Jednostavno i efikasno'] },
        { title: 'Tržište', bullets: ['Ciljana skupina Z', 'Veliki potencijal rasta'] },
        { title: 'Tim', bullets: ['Iskusan tim', 'Strastveni za inovacije'] },
        { title: 'Financije', bullets: ['Tražimo 500k EUR', 'Za razvoj i marketing'] },
      ],
    };
    return mockPitchDeck;
  },

  async generateInvestorSummary(
    idea: string,
    evaluation: IdeaEvaluation,
    mvpBlueprint: MvpBlueprint,
    pitchDeck: PitchDeck
  ): Promise<InvestorSummary> {
    console.log('API: generateInvestorSummary called');
    await new Promise(resolve => setTimeout(resolve, 1000));

    const mockInvestorSummary: InvestorSummary = {
      problem: 'Postojeći sustavi su spori i skupi.',
      solution: 'Naš AI-pogonjeni MVP Studio automatizira validaciju ideje i generiranje prototipa.',
      market_size: 'Globalno tržište za AI alate za razvoj je u eksponencijalnom rastu.',
      competitive_advantage: 'Jedinstvena kombinacija AI evaluacije, MVP generacije i pitch decka u jednom alatu.',
      funding_ask: 'Tražimo 500.000 EUR za daljnji razvoj platforme i širenje na nova tržišta.',
      use_of_funds: ['Razvoj tima', 'Marketing', 'Infrastruktura'],
      email_template: `Poštovani investitori,\n\nPredstavljamo vam FORMATDISC MVP Studio, platformu koja revolucionira validaciju ideja i razvoj prototipa. Naša AI platforma SlavkoKernel™ evaluira ideje u 60 sekundi i automatski generira funkcionalne MVP simulacije te pitch deckove.\n\nProblem: Postojeći sustavi su spori i skupi.\nRješenje: Naš AI-pogonjeni MVP Studio automatizira validaciju ideje i generiranje prototipa.\n\nTražimo 500.000 EUR za daljnji razvoj i širenje.\n\nS poštovanjem,\nMladen Gertner\nFORMATDISC`,
    };
    return mockInvestorSummary;
  },
};
