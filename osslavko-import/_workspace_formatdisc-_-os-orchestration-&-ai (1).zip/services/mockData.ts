import { SimulationResult } from '../types';

export const mockSimulationResult: SimulationResult = {
  id: 42,
  prompt: 'A marketplace for renting high-end gardening tools to neighbours in urban areas. Subscription + 10% fee.',
  pattern: {
    identified_pattern: 'P2P Asset Marketplace',
    market_size_estimation: 'TAM ~ $3–5B global; dense urban clusters have highest adoption potential.',
    target_audience: [
      'Urban homeowners with limited storage',
      'Semi‑professional gardeners',
      'Local landscaping micro‑businesses',
    ],
  },
  risk: {
    technical_risks: [
      'High friction in identity verification and deposit handling.',
      'Inventory quality tracking and damage disputes are non‑trivial.',
    ],
    market_risks: [
      'Established general rental platforms can copy vertical quickly.',
      'Seasonality in demand may cause liquidity issues.',
    ],
    execution_risks: [
      'Local‑market ops complexity across cities.',
      'Need for strong trust & safety playbook from day one.',
    ],
    overall_risk_score: 63,
  },
  eval: {
    viability_score: 72,
    innovation_score: 61,
    potential_impact: 'MEDIUM',
  },
  think: {
    final_summary: 'Viable in dense urban markets with strong operational discipline and trust mechanics. Not a winner in all geos, but can work as a focused vertical.',
    key_strengths: [
      'Clear pain point (idle expensive tools).',
      'Asset‑light with strong network effects if liquidity is reached.',
    ],
    key_weaknesses: [
      'Ops heavy; trust and liability issues.',
      'Hard to defend if horizontal players enter.',
    ],
    believable: true,
  },
  simulation: {
    customer_conversations: [
      {
        persona: 'Urban homeowner, 35, occasional gardener',
        conversation_log: [
          { speaker: 'user', text: 'Why would I use this instead of just buying tools?' },
          { speaker: 'system', text: 'You’d only pay when you actually need the tool and avoid storage issues.' },
        ],
        outcome_summary: 'User is interested if UX is simple and the price is materially lower than buying.',
        user_sentiment: 'positive',
      },
    ],
    overall_feedback_summary: 'Positively received if friction is low and pricing is transparent; concerns exist around trust, damage and hassle.',
  },
  verdict: {
    decision: 'PROCEED_WITH_CONSTRAINTS',
    consensus: 0.83,
  },
  timeline: [
    {
      step: 'pattern_agent',
      timestamp: '2025-01-01T10:00:01.234Z',
      output: {
        identified_pattern: 'P2P Asset Marketplace',
        market_size_estimation: 'TAM ~ $3–5B global; dense urban clusters have highest adoption potential.',
        target_audience: [
          'Urban homeowners with limited storage',
          'Semi‑professional gardeners',
          'Local landscaping micro‑businesses',
        ],
      },
    },
    {
      step: 'risk_agent',
      timestamp: '2025-01-01T10:00:03.100Z',
      output: {
        technical_risks: [
          'High friction in identity verification and deposit handling.',
          'Inventory quality tracking and damage disputes are non‑trivial.',
        ],
        market_risks: [
          'Established general rental platforms can copy vertical quickly.',
          'Seasonality in demand may cause liquidity issues.',
        ],
        execution_risks: [
          'Local‑market ops complexity across cities.',
          'Need for strong trust & safety playbook from day one.',
        ],
        overall_risk_score: 63,
      },
    },
    {
      step: 'council_verdict',
      timestamp: '2025-01-01T10:00:06.420Z',
      output: {
        decision: 'PROCEED_WITH_CONSTRAINTS',
        consensus: 0.83,
      },
    },
  ],
  created_at: '2025-01-01T10:00:00.000Z',
  duration_ms: 6420,
  status: 'complete',
  audit: {
    digest: 'b9e8d3b4...f1c0',
    signature: 'MEUCIQDK...==',
    public_key: '-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAy.../-----END PUBLIC KEY-----',
  },
};
