import { SimulationResult, AuthTokens, User, SSEEvent } from '../types';

const API_BASE_URL =
  process.env.NEXT_PUBLIC_BACKEND_API_URL || 'http://localhost:8000';

// ---------------------------------------------------------
// LocalStorage helpers – expose both tokens
// ---------------------------------------------------------

export const storeTokens = (tokens: AuthTokens) => {
  localStorage.setItem('accessToken', tokens.access_token);
  localStorage.setItem('refreshToken', tokens.refresh_token);
};

export const clearTokens = () => {
  localStorage.removeItem('accessToken');
  localStorage.removeItem('refreshToken');
};

export const getAccessToken = () => localStorage.getItem('accessToken');
export const getRefreshToken = () => localStorage.getItem('refreshToken');

/** Lightweight auth check for the UI – does NOT verify token validity. */
export const isAuthenticated = () => Boolean(getAccessToken());

// ---------------------------------------------------------
// Small helper: safely pull `detail` from a Response
// ---------------------------------------------------------

async function extractErrorDetail(response: Response, fallback: string) {
  try {
    const data = await response.json();
    if (data && typeof data === 'object' && 'detail' in data && data.detail) {
      return String((data as any).detail);
    }
  } catch {
    // ignore JSON parse / shape errors
  }
  return fallback;
}

// ---------------------------------------------------------
// Concurrency guard for token refreshing
// ---------------------------------------------------------

let isRefreshing = false;
let refreshPromise: Promise<void> | null = null;

async function refreshToken(): Promise<void> {
  if (isRefreshing) return refreshPromise!;

  isRefreshing = true;
  refreshPromise = (async () => {
    const rt = getRefreshToken();
    if (!rt) {
      clearTokens();
      throw new Error('No refresh token available');
    }

    try {
      const resp = await fetch(`${API_BASE_URL}/auth/refresh`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refresh_token: rt }),
      });

      if (!resp.ok) {
        const detail = await extractErrorDetail(resp, 'Refresh failed');
        clearTokens();
        throw new Error(detail);
      }

      const newTokens: AuthTokens = await resp.json();
      storeTokens(newTokens);
    } catch (e) {
      clearTokens();
      throw e;
    } finally {
      isRefreshing = false;
      refreshPromise = null;
    }
  })();

  return refreshPromise;
}

// ---------------------------------------------------------
// Generic request wrapper
// ---------------------------------------------------------

async function _performRequest(url: string, init: RequestInit = {}): Promise<Response> {
  const access = getAccessToken();
  const authHeaders = access ? { Authorization: `Bearer ${access}` } : {};

  init = {
    ...init,
    headers: {
      ...(init.headers ?? {}),
      ...authHeaders,
    },
  };

  let response = await fetch(`${API_BASE_URL}${url}`, init);

  if (response.status === 401) {
    try {
      await refreshToken();
      const newAccess = getAccessToken();
      init.headers = {
        ...(init.headers ?? {}),
        ...(newAccess ? { Authorization: `Bearer ${newAccess}` } : {}),
      };
      response = await fetch(`${API_BASE_URL}${url}`, init);

      if (!response.ok && response.status === 401) {
        clearTokens();
        throw new Error('Retry with refreshed token failed due to 401.');
      }
    } catch (e) {
      throw e;
    }
  }

  // Allow 202 for long‑running simulations
  if (!response.ok && response.status !== 202) {
    const detail = await extractErrorDetail(response, 'API request failed');
    throw new Error(detail);
  }

  return response;
}

// ---------------------------------------------------------
// Generic JSON request helper
// ---------------------------------------------------------

async function requestJson<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await _performRequest(url, init);
  return response.json() as Promise<T>;
}

// ---------------------------------------------------------
// API endpoints
// ---------------------------------------------------------

export const backendApiService = {
  /** Form‑encoded password login, stores tokens on success. */
  async loginUser(email: string, password: string): Promise<AuthTokens> {
    const formData = new URLSearchParams();
    formData.append('username', email);
    formData.append('password', password);

    const response = await fetch(`${API_BASE_URL}/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: formData.toString(),
    });

    if (!response.ok) {
      const detail = await extractErrorDetail(response, 'Login failed');
      throw new Error(detail);
    }

    const tokens: AuthTokens = await response.json();
    storeTokens(tokens);
    return tokens;
  },

  /** Client‑side logout helper – clears tokens immediately. */
  logout() {
    clearTokens();
  },

  /** Starts a new simulation job and returns its numeric ID. */
  async startSimulation(idea: string): Promise<{ id: number }> {
    return requestJson<{ id: number; status: string; created_at: string }>(`/simulate/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt: idea }),
    }).then((data) => ({ id: data.id }));
  },

  /**
   * Subscribes to Server‑Sent Events for a specific simulation.
   * Caller is responsible for closing the returned EventSource.
   */
  streamSimulationEvents(
    simulationId: number,
    onMessage: (data: SSEEvent) => void,
    onError: (event: Event) => void,
  ): EventSource {
    const accessToken = getAccessToken();
    const tokenParam = accessToken ? `?token=${encodeURIComponent(accessToken)}` : '';
    const url = `${API_BASE_URL}/simulate/${simulationId}/events${tokenParam}`;

    const eventSource = new EventSource(url);

    eventSource.onmessage = (event) => {
      try {
        const data: SSEEvent = JSON.parse(event.data);
        onMessage(data);
      } catch (e) {
        console.error('Failed to parse SSE message data:', event.data, e);
      }
    };

    eventSource.onerror = (error) => {
      onError(error);
      eventSource.close();
    };

    return eventSource;
  },

  /** Returns the full history of completed simulations for the user. */
  async getSimulationHistory(): Promise<SimulationResult[]> {
    return requestJson<SimulationResult[]>(`/results/`, {
      method: 'GET',
    });
  },

  /** Returns all structured data for a single simulation run. */
  async getSimulationDetails(simulationId: number): Promise<SimulationResult> {
    return requestJson<SimulationResult>(`/results/${simulationId}`, {
      method: 'GET',
    });
  },

  /** Returns the authenticated user's basic profile. */
  async getUserProfile(): Promise<User> {
    return requestJson<User>('/auth/me', {
      method: 'GET',
    });
  },
};
