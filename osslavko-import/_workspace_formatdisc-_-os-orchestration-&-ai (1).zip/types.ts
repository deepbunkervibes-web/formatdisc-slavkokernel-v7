
// ---------------------------------------------------------
// SlavkoKernel v8 – Data Models
// ---------------------------------------------------------

/**
 * Output PatternAgenta:
 * pretvara sirovu ideju u prepoznatljiv tržišni obrazac.
 */
export interface PatternAgentResult {
  /** Kratka oznaka obrasca (npr. "B2B SaaS", "two‑sided marketplace"). */
  identified_pattern: string;
  /** Tekstualna procjena adresabilnog tržišta. */
  market_size_estimation: string;
  /** Jedan ili više konkretnih ciljnih segmenata. */
  target_audience: string[];
}

/**
 * Output RiskAgenta:
 * navodi rizike i daje agregirani numerički rizik.
 */
export interface RiskAgentResult {
  technical_risks: string[];
  market_risks: string[];
  execution_risks: string[];
  /** Normalizirani rizik 0–100; veći broj znači veći rizik. */
  overall_risk_score: number;
}

/**
 * Output EvalAgenta:
 * dodjeljuje osnovne scoreove i klasificira potencijalni utjecaj.
 */
export interface EvalAgentResult {
  viability_score: number;
  innovation_score: number;
  potential_impact: 'LOW' | 'MEDIUM' | 'HIGH';
}

/**
 * Output ThinkAgenta:
 * sintetizira sve u ljudski čitljiv sažetak.
 */
export interface ThinkAgentResult {
  final_summary: string;
  key_strengths: string[];
  key_weaknesses: string[];
  /** Odražava vjeruje li agent ideji na temelju svih signala. */
  believable: boolean;
}

/**
 * Jedna simulirana konverzacija krajnjeg korisnika
 * za kvalitativni feedback.
 */
export interface SimulatedConversation {
  /** Persona u ovoj simulaciji (npr. "CFO, Series B SaaS"). */
  persona: string;
  conversation_log: Array<{
    speaker: 'user' | 'system';
    text: string;
  }>;
  outcome_summary: string;
  user_sentiment: 'positive' | 'neutral' | 'negative';
}

/**
 * Output SimulatorAgenta:
 * skup simuliranih konverzacija + meta‑sažetak.
 */
export interface SimulatorAgentResult {
  customer_conversations: SimulatedConversation[];
  overall_feedback_summary: string;
}

/**
 * Završna odluka vijeća (councila) nad svim agentima.
 */
export interface CouncilDecision {
  /** Ljudski čitljiva odluka (npr. "PROCEED", "PIVOT", "DROP"). */
  decision: string;
  /** Razina konsenzusa 0–1 (1 = jednoglasno). */
  consensus: number;
}

/**
 * Kriptografski audit zapisa simulacije.
 * Dizajnirano za vanjske verifikatore.
 */
export interface SimulationAudit {
  digest?: string;
  signature?: string;
  public_key?: string;
}

/**
 * Jedan strukturirani korak u kernel timelineu.
 *
 * Napomena:
 * Trenutno je `output: any` radi kompatibilnosti.
 * U kasnijoj verziji možemo uvesti:
 *
 *   type TimelineOutput =
 *     | { kind: 'pattern'; data: PatternAgentResult }
 *     | { kind: 'risk'; data: RiskAgentResult }
 *     | { kind: 'eval'; data: EvalAgentResult }
 *     | { kind: 'think'; data: ThinkAgentResult }
 *     | { kind: 'simulation'; data: SimulatorAgentResult }
 *     | { kind: 'verdict'; data: CouncilDecision | string }
 *     | { kind: 'audit'; data: SimulationAudit }
 *     | { kind: 'system'; data: string }
 *     | { kind: 'raw'; data: unknown };
 *
 * i onda promijeniti `output: TimelineOutput`.
 */
export interface TimelineEntry {
  /** Logički naziv koraka (npr. "pattern_agent", "council_vote"). */
  step: string;
  /** Neobavezni ISO timestamp (najčešće postavljen server‑side). */
  timestamp?: string;
  /**
   * Sirovi payload; shema ovisi o tipu koraka.
   */
  output: any;
}

/**
 * Primarna struktura za završenu SlavkoKernel v8 simulaciju.
 * Koristi se za povijest, replay i dashboarde.
 */
export interface Simulation {
  id: number;
  /** Izvorni korisnički prompt / opis ideje. */
  prompt: string;

  /** Struktuirani outputi pojedinih agenata. */
  pattern: PatternAgentResult;
  risk: RiskAgentResult;
  eval: EvalAgentResult;
  think: ThinkAgentResult;
  simulation: SimulatorAgentResult;

  /**
   * Završni council verdict.
   * String je zadržan radi backward/forward kompatibilnosti
   * sa starijim kernelima koji vraćaju samo tekstualni verdict.
   */
  verdict: CouncilDecision | string;

  /** Cijeli execution trace s backenda. */
  timeline: TimelineEntry[];

  /** ISO timestamp kreiranja simulacije. */
  created_at: string;
  /** Ukupno trajanje u milisekundama. */
  duration_ms: number;
  /** Status na backendu, npr. "complete", "failed". */
  status: string;

  /** Neobavezni kriptografski audit zapis. */
  audit: SimulationAudit | null;
}

/** Alias za jasan naming u UI sloju. */
export type SimulationResult = Simulation;

// ---------------------------------------------------------
// Core Application & Auth Models
// ---------------------------------------------------------

/**
 * Autentificirani korisnik kakvog frontend vidi.
 */
export interface User {
  id: number;
  /** Korisničko ime (ne e‑mail); usklađeno s backend poljem. */
  username: string;
  /** ISO timestamp registracije / pridruživanja. */
  joined: string;
}

/**
 * Tokeni dobiveni nakon prijave / osvježavanja.
 */
export interface AuthTokens {
  access_token: string;
  token_type: string;
  refresh_token: string;
}

/**
 * Visokorazinska faza aplikacije
 * (frontend state machine).
 */
export enum AppState {
  IDLE = 'IDLE',
  AUTHENTICATING = 'AUTHENTICATING',
  SIMULATING = 'SIMULATING',
  RESULTS = 'RESULTS',
  HISTORY = 'HISTORY',
}

// ---------------------------------------------------------
// SlavkoKernel v8 – SSE & Timeline Transport
// ---------------------------------------------------------

/**
 * Shape server‑sent eventa koji kernel emitira tijekom simulacije.
 */
export interface SSEEvent {
  type: 'timeline' | 'verdict' | 'audit' | 'error' | 'complete';

  /** Postavljeno kada je type === 'timeline'. */
  entry?: TimelineEntry;

  /** Postavljeno kada je type === 'verdict'. */
  verdict?: CouncilDecision;

  /** Postavljeno kada je type === 'audit'. */
  audit?: SimulationAudit;

  /** Postavljeno kada je type === 'error' ili za generičke poruke. */
  message?: string;
}
