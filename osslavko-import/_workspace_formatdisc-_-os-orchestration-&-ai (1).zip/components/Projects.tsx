import React from 'react';
import { motion } from 'framer-motion';
import { Zap, Gauge, ShieldCheck } from 'lucide-react';
import { GlassCard } from './GlassCard';

const projectCards = [
  { icon: Zap, title: 'SlavkoKernel™', desc: 'Fast, multi-agent orchestrator' },
  { icon: Gauge, title: 'SlavkoScore™', desc: 'Real-time scoring engine' },
  { icon: ShieldCheck, title: 'Dominor™', desc: 'End-to-end governance platform' },
];

const MotionDiv = motion.div as any;

export const Projects: React.FC = React.memo(() => (
  <section id="projects" className="py-20 bg-black text-gray-200">
    <div className="max-w-7xl mx-auto text-center space-y-12 px-6">
      <h2 className="text-4xl font-bold text-gray-100">Our Core Technology</h2>
       <p className="text-lg text-gray-400 max-w-2xl mx-auto">
        A suite of interoperable agents designed for high-stakes decision making.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mx-auto max-w-5xl">
        {projectCards.map((p, i) => (
          <MotionDiv
            key={i}
            whileHover={{ y: -10 }}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{
              y: { type: 'spring', stiffness: 300 },
              duration: 0.6,
              delay: i * 0.1,
            }}
          >
             <GlassCard className="p-8 h-full transition-all duration-300 hover:shadow-xl hover:drop-shadow-glow hover:scale-102">
                <p.icon className="mx-auto w-12 h-12 text-hackerGreen drop-shadow-glow mb-4" />
                <h3 className="text-xl font-semibold mb-3 text-gray-100">{p.title}</h3>
                <p className="text-sm text-gray-400">{p.desc}</p>
            </GlassCard>
          </MotionDiv>
        ))}
      </div>
    </div>
  </section>
));