import React from 'react';
import { Download, Copy, RotateCcw } from 'lucide-react';
import { MvpBlueprint, PitchDeck, InvestorSummary } from '../types/mvpStudio';
import { motion } from 'framer-motion';

interface ResultActionsProps {
  mvpBlueprint: MvpBlueprint | null;
  pitchDeck: PitchDeck | null;
  investorSummary: InvestorSummary | null;
  onReset: () => void;
}

const MotionDiv = motion.div as any;
const MotionButton = motion.button as any;

export function ResultActions({ mvpBlueprint, pitchDeck, investorSummary, onReset }: ResultActionsProps) {
  
  const handleDownloadPitchDeck = () => {
    if (!pitchDeck) return;
    const text = pitchDeck.slides.map((s, i) => `Slide ${i + 1}: ${s.title}\n${s.bullets.map(b => `- ${b}`).join('\n')}`).join('\n\n');
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'pitch-deck.txt';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleCopyEmailTemplate = () => {
    if (!investorSummary) return;
    navigator.clipboard.writeText(investorSummary.email_template);
    alert('Email predložak kopiran u clipboard!');
  };

  const canPerformActions = mvpBlueprint && pitchDeck && investorSummary;

  return (
    <MotionDiv 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
      className="rounded-xl bg-secondaryBg border border-borderColor p-6 space-y-4"
    >
      <h3 className="text-lg font-semibold text-primaryText">Sljedeći koraci</h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <MotionButton
          onClick={handleDownloadPitchDeck}
          disabled={!canPerformActions}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-tertiaryBg text-primaryText text-sm font-medium
                     hover:bg-tertiaryBg/70 transition-colors border border-borderColor disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Download size={16} /> Preuzmi Pitch Deck
        </MotionButton>
        <MotionButton
          onClick={handleCopyEmailTemplate}
          disabled={!canPerformActions}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-tertiaryBg text-primaryText text-sm font-medium
                     hover:bg-tertiaryBg/70 transition-colors border border-borderColor disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Copy size={16} /> Kopiraj Email za Investitore
        </MotionButton>
        <MotionButton
          onClick={onReset}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-tertiaryBg text-primaryText text-sm font-medium
                     hover:bg-tertiaryBg/70 transition-colors border border-borderColor"
        >
          <RotateCcw size={16} /> Nova ideja
        </MotionButton>
      </div>
    </MotionDiv>
  );
}