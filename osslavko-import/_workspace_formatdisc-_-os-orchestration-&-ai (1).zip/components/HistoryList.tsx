import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Play, Clock, Search, Loader2, ChevronLeft, ChevronRight } from 'lucide-react';
import { backendApiService } from '../services/backendApiService';
import { SimulationResult } from '../types';

interface HistoryListProps {
  onBack: () => void;
  onViewDetails: (simulationId: number) => void;
}

const MotionDiv = motion.div as any;

export const HistoryList: React.FC<HistoryListProps> = ({ onBack, onViewDetails }) => {
  const [history, setHistory] = useState<SimulationResult[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredHistory, setFilteredHistory] = useState<SimulationResult[]>([]);
  
  // Pagination State
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  useEffect(() => {
    const fetchHistory = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const data = await backendApiService.getSimulationHistory();
        setHistory(data);
      } catch (err: any)
      {
        setError(err.message || 'Failed to load simulation history.');
      } finally {
        setIsLoading(false);
      }
    };
    fetchHistory();
  }, []);

  useEffect(() => {
    const lowercasedSearchTerm = searchTerm.toLowerCase();
    const results = history.filter(item => {
      const verdictText = typeof item.verdict === 'string' ? item.verdict : item.verdict.decision;
      return item.prompt.toLowerCase().includes(lowercasedSearchTerm) ||
      verdictText.toLowerCase().includes(lowercasedSearchTerm)
    });
    setFilteredHistory(results);
    setCurrentPage(1); // Reset to first page on search
  }, [history, searchTerm]);

  // Pagination Logic
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = filteredHistory.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(filteredHistory.length / itemsPerPage);

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(prev => prev + 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(prev => prev - 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-hackerGray text-gray-200 font-sans pb-20">
      <header className="border-b border-hackerAccent bg-black/90 text-gray-200 backdrop-blur sticky top-0 z-30">
        <div className="max-w-4xl mx-auto flex justify-between items-center px-4 py-3">
            <div className="flex items-center gap-4">
            <button onClick={onBack} className="p-2 hover:bg-hackerAccent rounded-full transition-colors">
                <ArrowLeft className="text-gray-400" />
            </button>
            <div className="flex flex-col">
                <h1 className="text-hackerGreen font-bold tracking-tight">SIMULATION HISTORY</h1>
                <span className="text-xs text-gray-500 font-mono">Review past kernel outputs</span>
            </div>
            </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-8 space-y-6">
        <div className="relative mb-6">
          <input
            type="text"
            placeholder="Search by idea prompt or verdict..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-hackerAccent text-hackerGreen placeholder:text-gray-500 font-mono text-sm p-3 pl-10 rounded-lg border border-hackerAccent focus:outline-none focus:ring-2 focus:ring-hackerGreen focus:border-hackerGreen transition-all"
            aria-label="Search simulation history"
          />
          <Search size={20} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
        </div>

        {isLoading ? (
          <div className="flex flex-col items-center justify-center h-64 text-gray-500">
            <Loader2 className="animate-spin text-hackerGreen mb-4" size={32} />
            <p>Loading history from Kernel archives...</p>
          </div>
        ) : error ? (
          <div className="flex flex-col items-center justify-center h-64 text-red-500">
            <p>ERROR: {error}</p>
            <p className="text-sm text-gray-500">Please try again later or ensure you are logged in.</p>
          </div>
        ) : filteredHistory.length === 0 && history.length > 0 ? (
          <div className="flex flex-col items-center justify-center h-64 text-gray-500">
            <Search size={48} className="mb-4" />
            <p className="text-lg">No matching simulations found.</p>
            <p className="text-sm">Try a different search term.</p>
          </div>
        ) : filteredHistory.length === 0 && history.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64 text-gray-500">
            <Search size={48} className="mb-4" />
            <p className="text-lg">No simulation history found.</p>
            <p className="text-sm">Run a simulation to see it appear here!</p>
          </div>
        ) : (
          <>
            <MotionDiv layout className="grid grid-cols-1 gap-4">
              {currentItems.map((item, index) => {
                const verdictText = typeof item.verdict === 'string' ? item.verdict : item.verdict.decision;
                return (
                <MotionDiv
                  key={item.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="bg-hackerAccent/80 backdrop-blur-sm rounded-xl p-5 border border-hackerAccent/60 shadow-md hover:shadow-xl hover:drop-shadow-glow transition-all duration-200 transform hover:scale-102 cursor-pointer"
                  onClick={() => onViewDetails(item.id)}
                >
                  <div className="flex flex-col md:flex-row items-start md:items-center justify-between">
                      <div className="flex-1 mb-3 md:mb-0 mr-4">
                          <h3 className="text-lg font-bold text-hackerGreen mb-1 leading-tight">{item.prompt.substring(0, 80)}{item.prompt.length > 80 ? '...' : ''}</h3>
                          <div className="flex items-center text-sm text-gray-500 gap-2">
                              <Clock size={16} />
                              <span>{new Date(item.created_at).toLocaleString()}</span>
                          </div>
                      </div>
                      <div className="flex items-center gap-4 shrink-0">
                          <span className={`px-3 py-1 text-xs font-semibold rounded-full ${
                              verdictText.toLowerCase().includes('low') || verdictText.toLowerCase().includes('minimum') ? 'border border-red-500/70 bg-red-950/60 text-red-300' :
                              verdictText.toLowerCase().includes('medium') ? 'border border-yellow-500/70 bg-yellow-950/60 text-yellow-300' :
                              'border border-hackerGreen/60 bg-hackerAccent/70 text-hackerGreen'
                          }`}>
                              {verdictText}
                          </span>
                          <span className="flex items-center gap-1 text-hackerGreen hover:text-emerald-300 transition-colors">
                              <Play size={16} /> View
                          </span>
                      </div>
                  </div>
                </MotionDiv>
              )})}
            </MotionDiv>

            {/* Pagination Controls */}
            {totalPages > 1 && (
              <div className="flex justify-center items-center gap-4 mt-8 pt-4 border-t border-hackerAccent/30">
                <button
                  onClick={handlePrevPage}
                  disabled={currentPage === 1}
                  className="p-2 rounded-lg bg-hackerAccent hover:bg-hackerAccent/80 disabled:opacity-50 disabled:cursor-not-allowed text-hackerGreen transition-colors"
                  aria-label="Previous Page"
                >
                  <ChevronLeft size={20} />
                </button>
                <span className="text-sm text-gray-400 font-mono">
                  Page {currentPage} of {totalPages}
                </span>
                <button
                  onClick={handleNextPage}
                  disabled={currentPage === totalPages}
                  className="p-2 rounded-lg bg-hackerAccent hover:bg-hackerAccent/80 disabled:opacity-50 disabled:cursor-not-allowed text-hackerGreen transition-colors"
                  aria-label="Next Page"
                >
                  <ChevronRight size={20} />
                </button>
              </div>
            )}
          </>
        )}
      </main>
    </div>
  );
};