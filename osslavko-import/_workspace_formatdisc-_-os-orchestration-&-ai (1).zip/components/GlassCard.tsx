import React from 'react';

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
}

export const GlassCard: React.FC<GlassCardProps> = React.memo(({ children, className = '' }) => {
  return (
    <div
      className={`bg-hackerAccent/80 backdrop-blur-sm border border-hackerAccent/60 rounded-xl shadow-md ${className}`}
    >
      {children}
    </div>
  );
});
