import React from 'react';

export const Footer: React.FC = React.memo(() => (
    <footer className="mt-12 py-8 border-t border-border text-center">
        <div className="max-w-7xl mx-auto px-6 flex flex-col items-center gap-4">
             <div className="text-xs font-mono text-tertiary uppercase tracking-widest">
                FORMATDISC • SlavkoKernel v8
             </div>
             <p className="text-xs text-secondary max-w-md mx-auto leading-relaxed">
                vl. Mladen Gertner • OIB: 18915075854 • 10000 Zagreb
                <br />
                <a href="mailto:info@formatdisc.hr" className="hover:text-primary transition-colors">info@formatdisc.hr</a>
             </p>
             <div className="text-[10px] text-tertiary opacity-60">
                U spomen pokojnoga oca
             </div>
        </div>
    </footer>
));