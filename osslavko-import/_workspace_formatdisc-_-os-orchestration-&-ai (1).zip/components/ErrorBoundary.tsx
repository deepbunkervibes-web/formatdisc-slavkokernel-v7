import React, { Component, ErrorInfo, ReactNode } from 'react';

interface Props {
  children?: ReactNode;
}

interface State {
  hasError: boolean;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State;

  // FIX: Added a constructor to explicitly handle props and initialize state.
  // This resolves the TypeScript error "Property 'props' does not exist on type 'ErrorBoundary'"
  // by ensuring the component is correctly initialized with props from its parent.
  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
    };
  }

  public static getDerivedStateFromError(_: Error): State {
    // Ažurirajte stanje tako da će sljedeći render prikazati zamjenski UI.
    return { hasError: true };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error:', error, errorInfo);
    // Ovdje možete logirati grešku u neki servis za praćenje grešaka
  }

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-primaryBg text-primaryText p-4">
          <div className="text-center rounded-xl bg-secondaryBg border border-borderColor p-8 shadow-lg max-w-lg">
            <h2 className="text-2xl font-semibold text-accentRed mb-4">Nešto je pošlo po zlu!</h2>
            <p className="text-secondaryText mb-6">
              Oprostite, došlo je do neočekivane greške. Pokušajte ponovno ili osvježite stranicu.
            </p>
            <button
              onClick={() => window.location.reload()}
              className="inline-flex items-center gap-2 rounded-full px-6 py-3
                         bg-accentBlue text-white text-sm font-semibold tracking-tight
                         hover:bg-blue-600 transition-colors shadow-lg shadow-accentBlue/20"
            >
              Osvježi stranicu
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
