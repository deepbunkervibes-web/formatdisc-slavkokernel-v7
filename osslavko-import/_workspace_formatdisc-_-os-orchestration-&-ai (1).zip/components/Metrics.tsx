import React from 'react';
import { motion } from 'framer-motion';

const MotionDiv = motion.div as any;

export const Metrics: React.FC = React.memo(() => {
  const metrics = [
    { label: 'Latency', value: '34ms' },
    { label: 'Error Rate', value: '0.8%' },
    { label: 'Throughput', value: '120 req/s' },
  ];

  return (
    <section id="metrics" className="py-20 bg-hackerGray text-center">
      <div className="max-w-5xl mx-auto px-6">
        <h2 className="text-4xl font-bold mb-3 text-gray-100">Built for Production</h2>
        <p className="text-lg text-gray-400 mb-12">Reliable, scalable, and audit-proof orchestration.</p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {metrics.map((m, i) => (
            <MotionDiv
              key={i}
              className="bg-hackerAccent rounded-xl p-8 border border-hackerAccent/60 shadow-md"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: i * 0.1 }}
            >
              <p className="text-sm text-gray-400 uppercase tracking-wider font-semibold">{m.label}</p>
              <p className="text-5xl font-extrabold text-hackerGreen drop-shadow-glow">{m.value}</p>
            </MotionDiv>
          ))}
        </div>
      </div>
    </section>
  );
});