import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle2, XCircle } from 'lucide-react';

const MotionDiv = motion.div as any;

export const WhyUs: React.FC = React.memo(() => {
  return (
    <section id="why-us" className="py-20 bg-kernel-dark relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_rgba(0,244,166,0.05),_transparent_50%)] pointer-events-none"></div>

      <div className="max-w-6xl mx-auto px-6">
        
        {/* Why Croatia */}
        <div className="mb-20">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-gray-100">
                Dizajnirano za hrvatsku realnost
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                {[
                    { title: "Neravnomjerna infrastruktura", desc: "Podrška za hibride – kombinacija on‑prem, clouda i edgea." },
                    { title: "Ograničeni timovi", desc: "Automatizacija rutine (patching, backup, monitoring) umjesto širenja IT odjela." },
                    { title: "Regulativa", desc: "GDPR + AI Act, audit trail, kriptografski potpisane operacije." },
                    { title: "Jezik i podrška", desc: "Hrvatski jezik, lokalno znanje, konkretne studije slučaja iz regije." }
                ].map((item, idx) => (
                    <MotionDiv 
                        key={idx}
                        className="border-l-2 border-hackerGreen pl-6 py-2"
                        initial={{ opacity: 0, x: -20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: idx * 0.1 }}
                    >
                        <h4 className="font-bold text-lg text-white mb-2">{item.title}</h4>
                        <p className="text-sm text-gray-400">{item.desc}</p>
                    </MotionDiv>
                ))}
            </div>
        </div>

        {/* Differentiation */}
        <div className="bg-black/40 rounded-2xl p-8 md:p-12 border border-kernel-border">
            <div className="text-center mb-10">
                <h3 className="text-2xl font-bold text-white mb-4">Nismo samo još jedan alat za udaljeno upravljanje uređajima</h3>
                <p className="text-gray-400">Mi smo orkestracijski sloj iznad kaosa.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                {/* Competitors */}
                <div>
                    <h4 className="text-gray-500 font-mono text-sm uppercase tracking-widest mb-6 border-b border-gray-800 pb-2">Klasični UEM / OS alati</h4>
                    <ul className="space-y-4">
                        {[
                            "Fokus na inventar, policyje i remote instalaciju",
                            "Globalni proizvodi, slabo prilagođeni hrvatskim specifičnostima",
                            "Minimalna integracija s AI‑om, gotovo bez auditabilnosti odluka"
                        ].map((item, i) => (
                            <li key={i} className="flex items-start gap-3 text-gray-500">
                                <XCircle size={20} className="shrink-0 mt-0.5" />
                                <span>{item}</span>
                            </li>
                        ))}
                    </ul>
                </div>

                {/* FORMATDISC */}
                <div>
                    <h4 className="text-hackerGreen font-mono text-sm uppercase tracking-widest mb-6 border-b border-hackerGreen/30 pb-2">FORMATDISC</h4>
                    <ul className="space-y-4">
                        {[
                            "AI‑native orkestracija: SlavkoKernel council donosi odluke nad OS‑om i aplikacijama",
                            "Kriptografski potpisan audit trail svake ključne promjene",
                            "Duboke integracije s OpenAI, Anthropic, Gemini, Mistral, lokalnim LLM‑ovima",
                            "Lokalizacija, podrška i razumijevanje specifičnih problema hrvatskog i balkanskog tržišta"
                        ].map((item, i) => (
                            <li key={i} className="flex items-start gap-3 text-gray-200">
                                <CheckCircle2 size={20} className="text-hackerGreen shrink-0 mt-0.5" />
                                <span>{item}</span>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>
        </div>

      </div>
    </section>
  );
});