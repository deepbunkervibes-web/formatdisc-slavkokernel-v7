import React from 'react';
import { motion } from 'framer-motion';
import { AlertTriangle, Clock, Database, ShieldAlert, RefreshCcw } from 'lucide-react';

const MotionDiv = motion.div as any;

export const ProblemSection: React.FC = React.memo(() => {
  const problems = [
    { 
      label: 'IT budžeta na legacy', 
      value: '80%', 
      desc: 'Većina sredstava odlazi na održavanje starog, umjesto na inovacije.',
      icon: Database 
    },
    { 
      label: 'Tvrtki gubi 3h+ dnevno', 
      value: '48%', 
      desc: 'Zaposlenici gube vrijeme na spor softver i ručne procese.',
      icon: Clock
    },
    { 
      label: 'Vremena na patching', 
      value: '75%', 
      desc: 'IT timova troši do 25 sati tjedno na rutinska ažuriranja.',
      icon: RefreshCcw
    },
    { 
      label: 'Rizik ranjivosti', 
      value: '36%', 
      desc: 'Poduzeća prijavljuju povećane ranjivosti zbog zastarjele tehnologije.',
      icon: ShieldAlert
    },
  ];

  return (
    <section id="problem" className="py-20 bg-hackerGray text-center relative overflow-hidden">
        {/* Background elements */}
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-red-500/50 to-transparent opacity-50"></div>
        
      <div className="max-w-6xl mx-auto px-6 relative z-10">
        <div className="mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-100">
              Vaši sustavi rade na aparatima. <br />
              <span className="text-red-500">AI može biti respirator, ali netko mora voditi orkestar.</span>
            </h2>
            <p className="text-lg text-gray-400 max-w-3xl mx-auto">
              Digitalna transformacija u Hrvatskoj često znači “krpanje” starog, ne stvaranje novog. 
              FORMATDISC platforma sjeda iznad postojećih sustava i orkestrira operativne sustave, 
              aplikacije i AI, tako da vaše okruženje napokon radi stabilno, sigurno i predvidivo.
            </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {problems.map((m, i) => (
            <MotionDiv
              key={i}
              className="bg-black/40 backdrop-blur-sm rounded-xl p-6 border border-red-900/30 hover:border-red-500/50 transition-colors group"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.1 }}
            >
              <div className="flex justify-center mb-4 text-red-500/80 group-hover:text-red-400 transition-colors">
                  <m.icon size={32} />
              </div>
              <p className="text-4xl font-black text-white mb-2 font-mono group-hover:text-red-100 transition-colors">{m.value}</p>
              <p className="text-sm text-red-400 uppercase tracking-wider font-bold mb-3">{m.label}</p>
              <p className="text-sm text-gray-500 leading-snug">{m.desc}</p>
            </MotionDiv>
          ))}
        </div>
      </div>
    </section>
  );
});