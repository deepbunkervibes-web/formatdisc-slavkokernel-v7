import React from 'react';
import { motion } from 'framer-motion';

const MotionDiv = motion.div as any;

export const MagicSphere: React.FC = React.memo(() => {
  return (
    <div className="relative w-48 h-48 mx-auto">
      {/* Core glow */}
      <MotionDiv
        className="absolute inset-0 rounded-full bg-hackerGreen/20 blur-2xl"
        animate={{ scale: [1, 1.1, 1] }}
        transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}
      />
      
      {/* Main sphere body with gradient */}
      <MotionDiv
        className="absolute inset-0 rounded-full"
        style={{
          background: 'radial-gradient(circle at 30% 30%, #00F4A6, #0a0a0a 70%)',
        }}
        animate={{
          rotate: [0, 360],
        }}
        transition={{
          duration: 30,
          repeat: Infinity,
          ease: 'linear',
        }}
      />
      
      {/* Secondary rotating highlight */}
      <MotionDiv
        className="absolute inset-2 rounded-full opacity-70"
        style={{
           background: 'radial-gradient(circle at 70% 70%, #00F4A6, transparent 60%)',
        }}
        animate={{
          rotate: [360, 0],
        }}
        transition={{
          duration: 40,
          repeat: Infinity,
          ease: 'linear',
        }}
      />
      
      {/* Grid overlay */}
      <div 
        className="absolute inset-0 rounded-full opacity-20"
        style={{
          backgroundImage: `
            linear-gradient(rgba(0, 244, 166, 0.5) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0, 244, 166, 0.5) 1px, transparent 1px)
          `,
          backgroundSize: '20px 20px',
        }}
      />

      {/* Border */}
      <div className="absolute inset-0 rounded-full border-2 border-hackerGreen/20" />
    </div>
  );
});