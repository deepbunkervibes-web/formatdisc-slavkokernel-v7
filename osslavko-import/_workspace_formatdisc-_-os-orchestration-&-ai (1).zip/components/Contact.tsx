import React from 'react';

export const Contact: React.FC = React.memo(() => (
  <section id="contact" className="py-20 bg-black">
    <div className="max-w-4xl mx-auto text-center px-6">
      <h2 className="text-4xl font-bold mb-6 text-gray-100">Kontaktirajte nas</h2>
      
      <p className="text-lg mb-8 text-gray-400 max-w-2xl mx-auto">
        Imate pitanja o implementaciji, sigurnosti ili cijenama? Javite nam se za besplatnu konzultaciju.
      </p>

      <div className="mb-12">
        <a
            href="mailto:info@formatdisc.hr"
            className="relative inline-flex items-center justify-center px-10 py-4 text-lg font-bold rounded-full 
                    bg-hackerGreen text-black font-mono tracking-tight
                    transition-transform transition-shadow transition-colors duration-200
                    hover:scale-105 hover:bg-emerald-300 hover:shadow-xl hover:drop-shadow-glow
                    focus:outline-none focus:ring-2 focus:ring-hackerGreen focus:ring-offset-2 focus:ring-offset-black"
        >
            info@formatdisc.hr
        </a>
      </div>

      <div className="border-t border-gray-800 pt-12 mt-12">
        <p className="text-xl md:text-2xl font-bold text-gray-300 leading-relaxed">
            "FORMATDISC je vaš orkestrator između starog i novog svijeta – <br className="hidden md:block"/>
            između legacy sustava i AI‑native infrastrukture. Lokalno razumijevanje hrvatskog poslovnog okruženja, uz globalno dokazanu arhitekturu (SlavkoKernel, SlavkoScore, SlavkoMetrics, META HIBRID), čini ga prirodnim partnerom za sljedeće desetljeće digitalne transformacije u regiji."
        </p>
      </div>
    </div>
  </section>
));