import React, { useState, useEffect } from 'react';
import type { SimulationResult } from '../types';

interface Props {
  raw: SimulationResult | null;
}

/**
 * Small panel that shows the raw JSON payload + a scrolling log of received SSE events.
 * It is rendered inside a `<details>` block in `SimulationViewer`.
 */
export function SimulationConsole({ raw }: Props) {
  const [sseLog, setSseLog] = useState<string[]>([]);

  useEffect(() => {
    const handler = (e: CustomEvent) => {
      setSseLog(prev => [...prev.slice(-100), `${new Date().toLocaleTimeString()} – ${e.detail}`]);
    };
    window.addEventListener('kernel:sse', handler as EventListener);
    return () => window.removeEventListener('kernel:sse', handler as EventListener);
  }, []);

  return (
    <div className="mt-4 space-y-4">
      {/* Raw JSON payload */}
      <section className="p-4 bg-gray-50 dark:bg-gray-800 rounded overflow-x-auto">
        <h3 className="font-semibold mb-2 text-gray-700 dark:text-gray-200">Raw SimulationResult</h3>
        <pre className="text-xs whitespace-pre-wrap break-words">
          {raw ? JSON.stringify(raw, null, 2) : '— No payload loaded —'}
        </pre>
      </section>

      {/* SSE Log */}
      <section className="p-4 bg-gray-50 dark:bg-gray-800 rounded h-48 overflow-y-auto">
        <h3 className="font-semibold mb-2 text-gray-700 dark:text-gray-200">Live SSE Log</h3>
        <pre className="text-xs whitespace-pre-wrap">
          {sseLog.length ? sseLog.join('\n') : '— No events received yet —'}
        </pre>
      </section>
    </div>
  );
}
