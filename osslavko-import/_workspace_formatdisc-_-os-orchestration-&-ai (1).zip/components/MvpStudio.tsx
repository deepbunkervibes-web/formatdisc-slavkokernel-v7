import React, { useState, useCallback } from 'react';
import { MvpStudioState, IdeaEvaluation } from '../types/mvpStudio';
import { mvpStudioService } from '../services/mvpStudioService';

import { IdeaInput } from './IdeaInput';
import { EvaluationView } from './EvaluationView';
import { MvpPreview } from './MvpPreview';
import { PitchDeckView } from './PitchDeckView';
import { ResultActions } from './ResultActions';
import { StatusBar } from './ui/StatusBar';
import { Tabs } from './ui/Tabs';
import { Terminal } from './ui/Terminal';

export function MvpStudio() {
  const [state, setState] = useState<MvpStudioState>({
    phase: 'IDEA_INPUT',
    idea: '',
    evaluation: null,
    mvpBlueprint: null,
    pitchDeck: null,
    investorSummary: null,
    error: null,
  });

  const [activeTab, setActiveTab] = useState<'council' | 'mvp' | 'deck'>('council');

  const handleSubmitIdea = useCallback(async (idea: string) => {
    setState((prev) => ({ ...prev, phase: 'EVALUATING', idea, error: null }));
    setActiveTab('council');

    try {
      const evaluation = await mvpStudioService.evaluateIdea(idea);
      setState((prev) => ({ ...prev, evaluation }));

      if (evaluation.verdict === 'PROCEED') {
        handleGenerateMvp(idea, evaluation);
      } else {
        setState((prev) => ({ ...prev, phase: 'RESULT' })); // Go to result phase to show rejection/revision
      }
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'Nepoznata greška tijekom evaluacije.';
      setState((prev) => ({ ...prev, error: msg, phase: 'IDEA_INPUT' }));
    }
  }, []);

  const handleGenerateMvp = useCallback(
    async (idea: string, evaluation: IdeaEvaluation) => {
      setState((prev) => ({ ...prev, phase: 'MVP_BUILDING' }));
      setActiveTab('mvp');

      try {
        const mvpBlueprint = await mvpStudioService.generateMvp(idea, evaluation);
        
        const [pitchDeck, investorSummary] = await Promise.all([
          mvpStudioService.generatePitchDeck(idea, evaluation, mvpBlueprint),
          mvpStudioService.generateInvestorSummary(idea, evaluation, mvpBlueprint, {} as any)
        ]);
        
        const finalInvestorSummary = await mvpStudioService.generateInvestorSummary(idea, evaluation, mvpBlueprint, pitchDeck);

        setState((prev) => ({
          ...prev,
          phase: 'RESULT',
          mvpBlueprint,
          pitchDeck,
          investorSummary: finalInvestorSummary,
        }));
      } catch (error) {
        const msg = error instanceof Error ? error.message : 'Nepoznata greška tijekom generiranja MVP-a.';
        setState((prev) => ({ ...prev, error: msg, phase: 'EVALUATING' }));
      }
    },
    []
  );

  const handleReset = useCallback(() => {
    setState({
      phase: 'IDEA_INPUT',
      idea: '',
      evaluation: null,
      mvpBlueprint: null,
      pitchDeck: null,
      investorSummary: null,
      error: null,
    });
    setActiveTab('council');
  }, []);

  const renderContent = () => {
    const { phase, idea, evaluation, mvpBlueprint, pitchDeck, investorSummary, error } = state;

    if (phase === 'IDEA_INPUT') {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <IdeaInput
                    initialIdea={idea}
                    onSubmit={handleSubmitIdea}
                    error={error}
                />
            </div>
        );
    }
    
    return (
      <div className="w-full">
        <div className="max-w-7xl mx-auto px-4 py-8 space-y-6">
          <StatusBar phase={phase} evaluation={evaluation} />

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <EvaluationView evaluation={evaluation} phase={phase} />

            <div className="space-y-4">
              <Tabs
                activeTab={activeTab}
                setActiveTab={setActiveTab}
                mvpBlueprint={mvpBlueprint}
                pitchDeck={pitchDeck}
              />
              <div className="min-h-[500px] rounded-xl bg-secondaryBg border border-borderColor p-6 overflow-auto">
                {activeTab === 'council' && evaluation && (
                  <Terminal logs={evaluation.logs.map(log => `${new Date(log.timestamp).toLocaleTimeString()} [${log.agent}]: ${log.message}`)} isProcessing={phase === 'EVALUATING' || phase === 'MVP_BUILDING'} />
                )}
                {activeTab === 'mvp' && mvpBlueprint && <MvpPreview blueprint={mvpBlueprint} />}
                {activeTab === 'deck' && pitchDeck && <PitchDeckView deck={pitchDeck} />}
              </div>
            </div>
          </div>

          {phase === 'RESULT' && (
            <ResultActions
              mvpBlueprint={mvpBlueprint}
              pitchDeck={pitchDeck}
              investorSummary={investorSummary}
              onReset={handleReset}
            />
          )}

          {error && (
            <div className="rounded-lg bg-accentRed/20 border border-accentRed p-4 text-sm text-accentRed">
              <strong>Greška:</strong> {error}
            </div>
          )}
        </div>
      </div>
    );
  };
  
  return renderContent();
}
