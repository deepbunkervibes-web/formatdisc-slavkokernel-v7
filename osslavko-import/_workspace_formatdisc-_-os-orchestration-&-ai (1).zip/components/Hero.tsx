import React from 'react';
import { motion } from 'framer-motion';

interface HeroProps {
  isAuthenticated: boolean;
  onLoginClick: () => void;
}

const MotionDiv = motion.div as any;

export const Hero: React.FC<HeroProps> = React.memo(({ isAuthenticated, onLoginClick }) => {
  const handleAccessConsole = () => {
    if (isAuthenticated) {
      const simulateSection = document.getElementById('simulate');
      if (simulateSection) {
        simulateSection.scrollIntoView({ behavior: 'smooth' });
      }
    } else {
      onLoginClick();
    }
  };

  return (
    <section className="min-h-screen bg-[#0a0f1a] text-white flex flex-col relative overflow-hidden">
      
      {/* Animated Background Layers */}
      <div className="absolute inset-0 z-0 pointer-events-none">
        {/* Base Gradient */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#0a0f1a] via-[#0f1623] to-black" />
        
        {/* Animated Orbs */}
        <MotionDiv
          className="absolute top-[-20%] left-[-10%] w-[800px] h-[800px] rounded-full bg-blue-900/10 blur-[120px]"
          animate={{
            x: [0, 50, 0],
            y: [0, 30, 0],
            scale: [1, 1.1, 1],
            opacity: [0.3, 0.5, 0.3],
          }}
          transition={{
            duration: 15,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
        <MotionDiv
          className="absolute bottom-[-20%] right-[-10%] w-[600px] h-[600px] rounded-full bg-emerald-900/5 blur-[100px]"
          animate={{
            x: [0, -40, 0],
            y: [0, -60, 0],
            scale: [1, 1.2, 1],
            opacity: [0.2, 0.4, 0.2],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
        <MotionDiv
          className="absolute top-[40%] left-[60%] w-[400px] h-[400px] rounded-full bg-purple-900/5 blur-[80px]"
          animate={{
            scale: [1, 1.3, 1],
            opacity: [0.1, 0.2, 0.1],
          }}
          transition={{
            duration: 12,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />

        {/* Grid Overlay */}
        <div 
            className="absolute inset-0 opacity-[0.03]"
            style={{
                backgroundImage: `linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)`,
                backgroundSize: '50px 50px'
            }}
        />
      </div>

      <header className="relative z-10 w-full max-w-6xl mx-auto flex items-center justify-between px-6 py-5">
        <div className="flex items-center gap-3">
          <div className="w-7 h-7 rounded-full bg-white/10 flex items-center justify-center border border-white/5">
            <span className="text-xs font-mono">FD</span>
          </div>
          <span className="text-sm tracking-wide text-neutral-300 font-medium">FORMATDISC™</span>
        </div>
        <button 
          onClick={handleAccessConsole}
          className="text-xs font-mono px-3 py-1.5 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 transition text-neutral-400 hover:text-white"
        >
          Access Console
        </button>
      </header>

      <div className="relative z-10 w-full max-w-6xl mx-auto px-6 flex-1 grid md:grid-cols-2 gap-10 items-center pb-16">
        <div className="space-y-6">
          <MotionDiv 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-semibold leading-tight tracking-tight">
              Vaš AI su‑programer <br/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-emerald-400">za MVP ideje</span>
            </h1>
          </MotionDiv>
          
          <MotionDiv 
             initial={{ opacity: 0, y: 20 }}
             animate={{ opacity: 1, y: 0 }}
             transition={{ duration: 0.8, delay: 0.2 }}
          >
            <p className="text-neutral-400 text-base md:text-lg leading-relaxed max-w-lg">
              SlavkoKernel™ evaluira ideju u 60 sekundi, a zatim automatski gradi MVP simulaciju i pitch deck.
              Bez registracije. Samo upišite ideju – i gledajte rezultat.
            </p>
          </MotionDiv>

          <MotionDiv 
             initial={{ opacity: 0, y: 20 }}
             animate={{ opacity: 1, y: 0 }}
             transition={{ duration: 0.8, delay: 0.4 }}
             className="flex items-center gap-3 pt-2"
          >
            <a href="#simulate" className="inline-flex items-center justify-center px-6 py-3 rounded-full bg-white text-black text-sm font-semibold hover:bg-neutral-200 transition shadow-lg shadow-white/5">
              Provjeri ideju
            </a>
            <a href="#how" className="px-6 py-3 text-sm text-neutral-300 hover:text-white transition font-medium">
              Kako radi
            </a>
          </MotionDiv>
        </div>

        <MotionDiv 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.3 }}
          className="rounded-xl border border-white/10 bg-black/40 backdrop-blur-md overflow-hidden shadow-2xl shadow-blue-900/10"
        >
          <div className="flex items-center gap-2 px-4 py-3 border-b border-white/10 bg-white/5">
            <span className="w-2.5 h-2.5 bg-red-500/80 rounded-full"></span>
            <span className="w-2.5 h-2.5 bg-yellow-500/80 rounded-full"></span>
            <span className="w-2.5 h-2.5 bg-green-500/80 rounded-full"></span>
            <span className="ml-auto text-xs font-mono text-neutral-500">mvp-studio.ts</span>
          </div>
          <pre className="p-5 text-xs md:text-sm font-mono leading-relaxed overflow-x-auto text-neutral-300">
            <code>{`// Jednostavni primjer poziva na backend
async function evaluateIdea(idea: string) {
  
  // 1. Pošalji ideju agentima
  const res = await kernel.evaluate({ 
    prompt: idea,
    model: "gemini-2.5-flash"
  });

  // 2. Provjeri verdict
  if (res.score >= 8.5) {
    return await kernel.buildMVP(res);
  }
  
  return res.feedback;
}
`}</code>
          </pre>
        </MotionDiv>
      </div>
    </section>
  );
});