import React from 'react';
import { IdeaEvaluation, MvpStudioPhase } from '../types/mvpStudio';
import { CheckCircle2, XCircle, AlertCircle, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';

interface EvaluationViewProps {
  evaluation: IdeaEvaluation | null;
  phase: MvpStudioPhase;
}

const MotionDiv = motion.div as any;

export function EvaluationView({ evaluation, phase }: EvaluationViewProps) {
  if (!evaluation) {
    return (
      <div className="rounded-xl bg-secondaryBg border border-borderColor p-6 flex flex-col items-center justify-center text-secondaryText min-h-[500px]">
        <Loader2 size={24} className="animate-spin mb-4" />
        Čekam evaluaciju…
      </div>
    );
  }

  const { verdict, score, summary, pattern_analysis, risk_assessment, eval_notes, think_recommendation } = evaluation;

  const getVerdictStyle = () => {
    switch (verdict) {
      case 'PROCEED':
        return { icon: <CheckCircle2 size={24} />, color: 'text-accentGreen', bg: 'bg-accentGreen/10', border: 'border-accentGreen/30' };
      case 'REJECT':
        return { icon: <XCircle size={24} />, color: 'text-accentRed', bg: 'bg-accentRed/10', border: 'border-accentRed/30' };
      case 'REVISE':
      default:
        return { icon: <AlertCircle size={24} />, color: 'text-accentYellow', bg: 'bg-accentYellow/10', border: 'border-accentYellow/30' };
    }
  };

  const style = getVerdictStyle();

  return (
    <MotionDiv 
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.4 }}
      className="space-y-4"
    >
      <MotionDiv 
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.1 }}
        className={`rounded-xl ${style.bg} border ${style.border} p-6 space-y-3 shadow-md`}
      >
        <div className="flex items-center gap-3">
          <div className={style.color}>{style.icon}</div>
          <div>
            <div className="text-lg font-semibold text-primaryText">Verdikt: {verdict}</div>
            <div className={`text-sm ${style.color}`}>Ocjena: {score.toFixed(1)} / 10</div>
          </div>
        </div>
        <p className="text-sm text-secondaryText">{summary}</p>
      </MotionDiv>

      <MotionDiv 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="rounded-xl bg-secondaryBg border border-borderColor p-6 space-y-4 text-sm"
      >
        <Section title="Analiza obrasca" content={pattern_analysis} delay={0.4} />
        <Section title="Procjena rizika" content={risk_assessment} delay={0.5} />
        <Section title="Bilješke evaluacije" content={eval_notes} delay={0.6} />
        <Section title="Preporuka councila" content={think_recommendation} delay={0.7} />
      </MotionDiv>
    </MotionDiv>
  );
}

function Section({ title, content, delay = 0 }: { title: string; content: string; delay?: number }) {
  return (
    <MotionDiv 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
    >
      <h4 className="font-semibold text-primaryText mb-1">{title}</h4>
      <p className="text-secondaryText">{content}</p>
    </MotionDiv>
  );
}