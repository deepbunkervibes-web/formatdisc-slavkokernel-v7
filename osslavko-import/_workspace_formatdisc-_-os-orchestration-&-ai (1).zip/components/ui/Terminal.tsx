import React, { useEffect, useRef } from 'react';
import { Loader2 } from 'lucide-react';

interface TerminalProps {
  logs: string[];
  isProcessing?: boolean;
  className?: string;
}

export const Terminal: React.FC<TerminalProps> = ({ logs, isProcessing, className }) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [logs]);

  return (
    <div
      className={`font-mono text-xs overflow-y-auto h-full ${className}`}
    >
      {logs.map((log, index) => (
        <div key={index} className="whitespace-pre-wrap text-secondaryText leading-relaxed">
          {log}
        </div>
      ))}
      {isProcessing && (
        <div className="flex items-center gap-2 text-accentBlue mt-2">
          <Loader2 size={14} className="animate-spin" />
          <span>Processing...</span>
        </div>
      )}
      <div ref={messagesEndRef} />
    </div>
  );
};
