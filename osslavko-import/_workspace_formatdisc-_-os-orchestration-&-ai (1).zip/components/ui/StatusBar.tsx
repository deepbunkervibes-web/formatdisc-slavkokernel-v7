import React from 'react';
import { Loader2, CheckCircle2, AlertCircle, XCircle } from 'lucide-react';
import { MvpStudioPhase, IdeaEvaluation } from '../../types/mvpStudio';

interface StatusBarProps {
  phase: MvpStudioPhase;
  evaluation: IdeaEvaluation | null;
}

export function StatusBar({ phase, evaluation }: StatusBarProps) {
  const getStatus = () => {
    if (phase === 'IDEA_INPUT') return null;

    switch (phase) {
      case 'EVALUATING':
        return {
          icon: <Loader2 size={16} className="animate-spin text-accentBlue" />,
          text: 'Council evaluira ideju…',
          color: 'text-accentBlue',
        };
      case 'MVP_BUILDING':
        return {
          icon: <Loader2 size={16} className="animate-spin text-accentBlue" />,
          text: 'Generiram MVP simulaciju i pitch deck…',
          color: 'text-accentBlue',
        };
      case 'RESULT':
        if (evaluation?.verdict === 'PROCEED') {
          return {
            icon: <CheckCircle2 size={16} className="text-accentGreen" />,
            text: 'MVP i pitch deck dovršeni. Ideja spremna za investitore!',
            color: 'text-accentGreen',
          };
        } else if (evaluation?.verdict === 'REVISE') {
          return {
            icon: <AlertCircle size={16} className="text-accentYellow" />,
            text: 'Ideja zahtijeva reviziju. Pogledajte preporuke councila.',
            color: 'text-accentYellow',
          };
        } else if (evaluation?.verdict === 'REJECT') {
          return {
            icon: <XCircle size={16} className="text-accentRed" />,
            text: 'Ideja odbijena. Razmislite o novom pristupu.',
            color: 'text-accentRed',
          };
        }
        return null; // Fallback
      default:
        return null;
    }
  };

  const status = getStatus();
  if (!status) return null;

  return (
    <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-secondaryBg border border-borderColor">
      {status.icon}
      <span className={`text-sm font-medium ${status.color}`}>{status.text}</span>
    </div>
  );
}
