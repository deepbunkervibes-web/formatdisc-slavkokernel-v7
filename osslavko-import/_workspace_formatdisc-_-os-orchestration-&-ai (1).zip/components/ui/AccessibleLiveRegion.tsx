import React from 'react';

/**
 * A visually hidden component that announces messages to screen readers.
 * It uses the `aria-live="polite"` attribute, so screen readers will announce
 * changes when the user is idle.
 */
interface AccessibleLiveRegionProps {
  message: string;
}

export const AccessibleLiveRegion: React.FC<AccessibleLiveRegionProps> = ({ message }) => {
  return (
    <div
      aria-live="polite"
      aria-atomic="true"
      className="sr-only"
    >
      {message}
    </div>
  );
};