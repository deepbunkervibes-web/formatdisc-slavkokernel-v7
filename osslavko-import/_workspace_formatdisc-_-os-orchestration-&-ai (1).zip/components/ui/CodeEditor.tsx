import React from 'react';
import Editor, { loader } from '@monaco-editor/react';

// Configure loader to use a reliable CDN for the monaco assets if needed
// loader.config({ paths: { vs: 'https://cdn.jsdelivr.net/npm/monaco-editor@0.44.0/min/vs' } });

interface CodeEditorProps {
  code: string;
  language?: string;
  readOnly?: boolean;
  height?: string;
}

export const CodeEditor: React.FC<CodeEditorProps> = ({ code, language = 'json', readOnly = true, height = "400px" }) => {
  return (
    <div className="rounded-xl overflow-hidden border border-borderColor shadow-lg bg-[#1e1e1e]">
      <Editor
        height={height}
        defaultLanguage={language}
        value={code}
        theme="vs-dark"
        options={{
          readOnly: readOnly,
          minimap: { enabled: false },
          fontSize: 13,
          fontFamily: '"JetBrains Mono", monospace',
          scrollBeyondLastLine: false,
          padding: { top: 16, bottom: 16 },
          roundedSelection: false,
          renderLineHighlight: 'none',
          contextmenu: false,
          scrollbar: {
            vertical: 'visible',
            horizontal: 'visible',
            verticalScrollbarSize: 10,
            horizontalScrollbarSize: 10,
          }
        }}
        loading={
          <div className="flex items-center justify-center h-full text-secondaryText gap-2 text-sm font-mono">
             <div className="w-2 h-2 bg-accentBlue animate-pulse rounded-full"></div>
             Loading Editor...
          </div>
        }
      />
    </div>
  );
};