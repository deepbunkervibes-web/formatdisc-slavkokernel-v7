import React, { useEffect, useState } from 'react';

interface RateLimitHintProps {
  error: string | null;
}

export const RateLimitHint: React.FC<RateLimitHintProps> = ({ error }) => {
  const [countdown, setCountdown] = useState(0);

  useEffect(() => {
    if (error && (error.toLowerCase().includes("rate limit") || error.includes("429"))) {
      const match = error.match(/(\d+)/);
      const cooldownTime = match ? parseInt(match[0], 10) : 60;
      
      setCountdown(cooldownTime);
      
      const timer = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      
      return () => clearInterval(timer);
    }
  }, [error]);

  if (!error) return null;

  if (countdown > 0) {
    return <p className="text-warning text-xs text-center pt-2 font-medium">Too many requests. Retry in {countdown}s.</p>;
  }

  return <p className="text-error text-xs text-center pt-2 font-medium">{error}</p>;
};