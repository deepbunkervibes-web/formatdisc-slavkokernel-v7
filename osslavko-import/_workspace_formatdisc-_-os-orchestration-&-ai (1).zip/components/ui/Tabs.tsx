import React from 'react';
import { MvpBlueprint, PitchDeck } from '../../types/mvpStudio';
import { motion } from 'framer-motion';

interface TabsProps {
  activeTab: 'council' | 'mvp' | 'deck';
  setActiveTab: (tab: 'council' | 'mvp' | 'deck') => void;
  mvpBlueprint: MvpBlueprint | null;
  pitchDeck: PitchDeck | null;
}

const MotionButton = motion.button as any;

export function Tabs({ activeTab, setActiveTab, mvpBlueprint, pitchDeck }: TabsProps) {
  return (
    <div className="flex gap-2 border-b border-borderColor">
      <MotionButton
        whileTap={{ scale: 0.95 }}
        onClick={() => setActiveTab('council')}
        className={`px-4 py-2 text-sm font-medium transition-colors ${
          activeTab === 'council'
            ? 'border-b-2 border-accentBlue text-accentBlue'
            : 'text-secondaryText hover:text-primaryText'
        }`}
      >
        Council Log
      </MotionButton>
      <MotionButton
        whileTap={{ scale: 0.95 }}
        onClick={() => setActiveTab('mvp')}
        disabled={!mvpBlueprint}
        className={`px-4 py-2 text-sm font-medium transition-colors ${
          activeTab === 'mvp'
            ? 'border-b-2 border-accentBlue text-accentBlue'
            : 'text-secondaryText hover:text-primaryText disabled:opacity-30 disabled:hover:text-secondaryText'
        }`}
      >
        MVP Preview
      </MotionButton>
      <MotionButton
        whileTap={{ scale: 0.95 }}
        onClick={() => setActiveTab('deck')}
        disabled={!pitchDeck}
        className={`px-4 py-2 text-sm font-medium transition-colors ${
          activeTab === 'deck'
            ? 'border-b-2 border-accentBlue text-accentBlue'
            : 'text-secondaryText hover:text-primaryText disabled:opacity-30 disabled:hover:text-secondaryText'
        }`}
      >
        Pitch Deck
      </MotionButton>
    </div>
  );
}