import React from 'react';
import { motion } from 'framer-motion';
import { RefreshCcw, Server, ShieldCheck, Globe } from 'lucide-react';
import { GlassCard } from './GlassCard';

const solutions = [
  { 
    icon: RefreshCcw, 
    title: 'Automatizirana migracija i ažuriranja', 
    desc: 'Automatizirani workflowi za nadogradnje OS‑a i ključnih aplikacija. Minimalan downtime, manje ručnog rada, manje grešaka. Siguran prijenos podataka i rollback mehanizmi.' 
  },
  { 
    icon: Server, 
    title: 'Centralizirano upravljanje heterogenim okruženjem', 
    desc: 'Jedan sloj nad Windows, Linux, cloud i on‑prem okruženjima. Integracija s legacy ERP‑ovima i modernim SaaS‑om. Deklarativni dizajn workflowa (manifesti, reproducibilni procesi).' 
  },
  { 
    icon: ShieldCheck, 
    title: 'AI‑pogonjen nadzor i sigurnost', 
    desc: 'AI analizira logove, metrike i anomalije 24/7. Rano upozoravanje na potencijalne incidente i kritične ranjivosti. Kriptografski potpisan audit trail za ključne operacije.' 
  },
  { 
    icon: Globe, 
    title: 'Lokalizirana podrška i rast prilagođen MSP‑ovima', 
    desc: 'Sučelje i podrška na hrvatskom jeziku. Usklađenost s GDPR‑om i priprema za EU AI Act. Fleksibilni modeli pretplate umjesto teških licenci.' 
  },
];

const MotionDiv = motion.div as any;

export const SolutionSection: React.FC = React.memo(() => (
  <section id="solution" className="py-20 bg-black text-gray-200">
    <div className="max-w-7xl mx-auto px-6">
      <div className="text-center mb-16">
        <h2 className="text-3xl md:text-4xl font-bold text-gray-100 mb-4">
            Platforma za orkestraciju OS‑a i AI‑a,<br />dizajnirana za hrvatsku realnost
        </h2>
        <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            Orkestracijski sloj između vaših postojećih sustava, novih AI alata i infrastrukturnog kaosa.
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mx-auto max-w-6xl">
        {solutions.map((p, i) => (
          <MotionDiv
            key={i}
            whileHover={{ y: -5 }}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: i * 0.1 }}
          >
             <GlassCard className="p-8 h-full transition-all duration-300 hover:shadow-xl hover:drop-shadow-glow hover:border-hackerGreen/40 flex flex-col items-start text-left">
                <div className="p-3 rounded-lg bg-hackerGreen/10 mb-4">
                    <p.icon className="w-8 h-8 text-hackerGreen" />
                </div>
                <h3 className="text-xl font-bold mb-3 text-gray-100">{p.title}</h3>
                <p className="text-base text-gray-400 leading-relaxed">{p.desc}</p>
            </GlassCard>
          </MotionDiv>
        ))}
      </div>
    </div>
  </section>
));