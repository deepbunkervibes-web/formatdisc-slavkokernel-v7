import React, { useState } from 'react';
import { SimulationResult, SimulationAudit, TimelineEntry } from '../types';
import { 
  BarChart, Bar, XAxis, YAxis, Tooltip, Cell, ResponsiveContainer
} from 'recharts';
import { ArrowLeft, Share2, Download, Check, Copy, History, AlertTriangle, CheckCircle, Shield } from 'lucide-react';

interface ResultsDashboardProps {
  data: SimulationResult;
  onReset: () => void;
  onViewHistory: () => void;
}

const impactToScore = (impact: 'LOW' | 'MEDIUM' | 'HIGH'): number => {
  if (impact === 'HIGH') return 95;
  if (impact === 'MEDIUM') return 60;
  return 25;
};

const AuditDisplay = React.memo(({ audit }: { audit: SimulationAudit | null }) => {
  const [copied, setCopied] = useState(false);
  const signature = audit?.signature;

  const copyToClipboard = () => {
    if(!signature) return;
    navigator.clipboard.writeText(signature);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!signature) return null;

  return (
    <div className="mt-8 pt-8 border-t border-border">
      <h3 className="text-xs font-bold text-secondary uppercase tracking-widest mb-4">Cryptographic Audit</h3>
      <div className="bg-surface rounded-lg p-4 border border-border font-mono text-xs flex flex-col gap-2">
         <div className="flex justify-between items-center text-tertiary">
            <span>ED25519 SIGNATURE</span>
            <button onClick={copyToClipboard} className="hover:text-primary transition-colors flex items-center gap-1">
                {copied ? <Check size={12} /> : <Copy size={12} />}
                {copied ? "Copied" : "Copy"}
            </button>
         </div>
         <div className="break-all text-secondary leading-relaxed">
            {signature}
         </div>
      </div>
    </div>
  );
});

export const ResultsDashboard: React.FC<ResultsDashboardProps> = ({ data, onReset, onViewHistory }) => {
  
  const metricsData = [
    { subject: 'Viability', A: data.eval.viability_score },
    { subject: 'Innovation', A: data.eval.innovation_score },
    { subject: 'Risk', A: data.risk.overall_risk_score },
    { subject: 'Impact', A: impactToScore(data.eval.potential_impact) },
  ];

  const verdictText = typeof data.verdict === 'string' ? data.verdict : data.verdict.decision;

  return (
    <div className="w-full max-w-4xl mx-auto pb-20">
      {/* Header */}
      <header className="flex items-center justify-between mb-8 py-4 border-b border-border">
         <button onClick={onReset} className="flex items-center gap-2 text-sm text-secondary hover:text-primary transition-colors">
            <ArrowLeft size={16} /> Back
         </button>
         <div className="flex gap-3">
             <button onClick={onViewHistory} className="p-2 text-secondary hover:text-primary transition-colors" title="History">
                <History size={18} />
             </button>
             <button className="px-3 py-1.5 text-xs font-medium bg-primary text-black rounded hover:bg-white/90 transition-colors">
                Export PDF
             </button>
         </div>
      </header>

      {/* Main Report Card */}
      <div className="bg-surface border border-border rounded-2xl shadow-xl overflow-hidden mb-8">
         <div className="p-8 md:p-10 text-center border-b border-border bg-surfaceHighlight/10">
            <h2 className="text-sm font-mono text-tertiary uppercase tracking-widest mb-3">Council Verdict</h2>
            <h1 className="text-3xl md:text-4xl font-bold text-primary mb-4">{verdictText}</h1>
            <p className="text-secondary max-w-2xl mx-auto leading-relaxed">{data.think.final_summary}</p>
         </div>

         <div className="p-8 md:p-10">
            <h3 className="text-xs font-bold text-secondary uppercase tracking-widest mb-6">Performance Metrics</h3>
            <div className="h-[200px] w-full mb-10">
               <ResponsiveContainer width="100%" height="100%">
                 <BarChart data={metricsData} layout="vertical" margin={{ top: 0, right: 30, left: 40, bottom: 0 }}>
                   <XAxis type="number" domain={[0, 100]} hide />
                   <YAxis dataKey="subject" type="category" width={100} tick={{fill: '#a1a1aa', fontSize: 12, fontWeight: 500}} axisLine={false} tickLine={false} />
                   <Tooltip 
                     cursor={{fill: 'rgba(255,255,255,0.03)'}}
                     contentStyle={{ backgroundColor: '#18181b', borderColor: '#27272a', color: '#fafafa' }}
                   />
                   <Bar dataKey="A" barSize={24} radius={[0, 4, 4, 0]}>
                      {metricsData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.A > 70 ? '#fafafa' : '#52525b'} />
                      ))}
                   </Bar>
                 </BarChart>
               </ResponsiveContainer>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
               <div>
                  <h4 className="flex items-center gap-2 text-sm font-bold text-primary mb-4">
                     <CheckCircle size={16} className="text-secondary" /> Strengths
                  </h4>
                  <ul className="space-y-2">
                     {data.think.key_strengths.map((item, i) => (
                        <li key={i} className="text-sm text-secondary pl-6 relative before:content-['•'] before:absolute before:left-2 before:text-tertiary">
                           {item}
                        </li>
                     ))}
                  </ul>
               </div>
               <div>
                  <h4 className="flex items-center gap-2 text-sm font-bold text-primary mb-4">
                     <AlertTriangle size={16} className="text-secondary" /> Weaknesses
                  </h4>
                  <ul className="space-y-2">
                     {data.think.key_weaknesses.map((item, i) => (
                        <li key={i} className="text-sm text-secondary pl-6 relative before:content-['•'] before:absolute before:left-2 before:text-tertiary">
                           {item}
                        </li>
                     ))}
                  </ul>
               </div>
            </div>
         </div>
      </div>

      <div className="bg-surface border border-border rounded-xl p-6 shadow-sm">
         <h3 className="text-xs font-bold text-secondary uppercase tracking-widest mb-4">Risk Assessment</h3>
         <div className="space-y-3">
             {[...data.risk.technical_risks, ...data.risk.execution_risks].slice(0, 4).map((risk, i) => (
                 <div key={i} className="flex items-start gap-3 text-sm text-secondary">
                    <Shield size={16} className="shrink-0 mt-0.5 text-tertiary" />
                    <span>{risk}</span>
                 </div>
             ))}
         </div>
      </div>

      <AuditDisplay audit={data.audit} />

    </div>
  );
};