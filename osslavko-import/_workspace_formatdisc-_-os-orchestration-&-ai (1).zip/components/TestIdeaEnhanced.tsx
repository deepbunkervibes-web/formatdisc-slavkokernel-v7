/* --------------------------------------------------------------------
 * components/TestIdeaEnhanced.tsx
 *
 * Professional, Minimalist Simulator UI
 * -------------------------------------------------------------------- */
import React, {
  useState,
  useEffect,
  useCallback,
  useRef,
} from "react";
import { backendApiService } from '../services/backendApiService';
import type { Simulation, TimelineEntry, SSEEvent, CouncilDecision, SimulationAudit } from "../types";
import { 
  Loader2, ArrowRight, Check, AlertTriangle, Terminal, 
  Database, Shield, Cpu, Activity, GripVertical
} from "lucide-react";
import { Reorder } from "framer-motion";

// ---- Helper: Poll for results ----
async function poll<T>(
  fn: () => Promise<T>,
  validate: (result: T) => boolean,
  interval = 3000,
  maxAttempts = 30
): Promise<T> {
  let attempts = 0;
  const executePoll = async (resolve: (value: T) => void, reject: (reason?: any) => void) => {
    attempts++;
    try {
      const result = await fn();
      if (validate(result)) {
        return resolve(result);
      } else if (maxAttempts && attempts === maxAttempts) {
        return reject(new Error("Timeout waiting for simulation results."));
      } else {
        setTimeout(executePoll, interval, resolve, reject);
      }
    } catch (error) {
      return reject(error);
    }
  };
  return new Promise<T>(executePoll);
}

const Spinner: React.FC<{ className?: string }> = React.memo(({ className = "" }) => (
  <Loader2
    className={`animate-spin ${className}`}
    role="status"
    aria-label="Loading"
  />
));

const AccessibleLiveRegion: React.FC<{ message?: string }> = React.memo(({ message = "" }) => {
  return <div aria-live="polite" className="sr-only">{message}</div>;
});

// ---- UI Components ----

const AgentProgress: React.FC<{ timeline: TimelineEntry[] }> = React.memo(({ timeline }) => {
  const steps = [
    { key: 'pattern', label: 'Pattern' },
    { key: 'risk', label: 'Risk' },
    { key: 'eval', label: 'Eval' },
    { key: 'think', label: 'Think' },
    { key: 'simulation', label: 'Sim' },
    { key: 'council', label: 'Verdict' },
  ];

  const isComplete = (key: string) => timeline.some(t => t.step.toLowerCase().includes(key));
  // Find currently active step (first one not complete)
  const activeIndex = steps.findIndex(s => !isComplete(s.key));
  // If all complete, activeIndex is -1, meaning we act as if 6 (all done)
  const currentStepIndex = activeIndex === -1 ? steps.length : activeIndex;

  return (
    <div className="w-full py-4">
      <div className="flex items-center gap-1">
         {steps.map((step, index) => {
            const completed = index < currentStepIndex;
            const active = index === currentStepIndex;

            return (
              <div key={step.key} className="flex-1 flex flex-col gap-2">
                 {/* Bar segment */}
                 <div className={`
                    h-1 w-full rounded-full transition-all duration-500
                    ${completed ? 'bg-primary' : active ? 'bg-surfaceHighlight animate-pulse' : 'bg-surfaceHighlight'}
                 `} />
                 <span className={`
                    text-[10px] font-medium uppercase tracking-wide text-center transition-colors
                    ${completed ? 'text-primary' : 'text-tertiary'}
                 `}>
                    {step.label}
                 </span>
              </div>
            );
         })}
      </div>
    </div>
  );
});

// Extended interface for internal state to support drag-and-drop
interface DraggableTimelineEntry extends TimelineEntry {
  _id: string;
}

function useSSE(
  simId: number | null,
  setTimeline: React.Dispatch<React.SetStateAction<DraggableTimelineEntry[]>>,
  setLiveMsg: (msg: string) => void,
  setVerdict: React.Dispatch<React.SetStateAction<CouncilDecision | string | null>>,
  setAudit: React.Dispatch<React.SetStateAction<SimulationAudit | null>>,
  onError?: (msg: string) => void
) {
  const esRef = useRef<EventSource | null>(null);

  useEffect(() => {
    if (!simId) return;
    
    const onMessage = (payload: SSEEvent) => {
        if (payload.type === 'timeline' && payload.entry) {
            setTimeline(prev => [...prev, { ...payload.entry!, _id: crypto.randomUUID() }]);
            setLiveMsg(`Step completed: ${payload.entry.step}`);
        } else if (payload.type === 'verdict' && payload.verdict) {
            setVerdict(payload.verdict);
        } else if (payload.type === 'audit' && payload.audit) {
            setAudit(payload.audit);
        }
    };
    
    const onErr = (e: Event) => {
        if (onError) onError("Connection interrupted.");
        esRef.current?.close();
    };

    esRef.current = backendApiService.streamSimulationEvents(simId, onMessage, onErr);

    return () => {
      esRef.current?.close();
    };
  }, [simId, setTimeline, setLiveMsg, setVerdict, setAudit, onError]);
}

export const TestIdeaEnhanced: React.FC<{
  isAuthenticated: boolean;
  onComplete: (result: Simulation) => void;
  onAuthRequired: () => void;
}> = React.memo(({ isAuthenticated, onComplete, onAuthRequired }) => {
  const [loading, setLoading] = useState(false);
  const [simId, setSimId] = useState<number | null>(null);
  const [timeline, setTimeline] = useState<DraggableTimelineEntry[]>([]);
  const [result, setResult] = useState<Simulation | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [liveMsg, setLiveMsg] = useState("");
  const [verdict, setVerdict] = useState<CouncilDecision | string | null>(null);
  const [audit, setAudit] = useState<SimulationAudit | null>(null);
  const [input, setInput] = useState("");

  useSSE(simId, setTimeline, setLiveMsg, setVerdict, setAudit, (msg) => setError(prev => `${prev ? prev + '; ' : ''}${msg}`));

  const handleSubmit = useCallback(async () => {
      if (!input.trim()) return;
      if (!isAuthenticated) {
        onAuthRequired();
        return;
      }

      setLoading(true);
      setError(null);
      setResult(null);
      setTimeline([]);
      setVerdict(null);
      setAudit(null);
      setLiveMsg("Starting simulation...");

      try {
        const { id } = await backendApiService.startSimulation(input);
        setSimId(id);
        
        const final = await poll(
          () => backendApiService.getSimulationDetails(id),
          (res) => res.status.toLowerCase() === 'completed' || res.status.toLowerCase() === 'failed'
        );

        if (final.status.toLowerCase() === 'failed') {
          throw new Error('Simulation process failed.');
        }
        
        setResult(final);
        // Map original timeline to draggable format for consistency if we were to set it here
        // But since we stream, we likely rely on the stream. 
        // If we hard set from final result, we should map IDs.
        setTimeline(final.timeline.map(t => ({ ...t, _id: crypto.randomUUID() })));
        setVerdict(final.verdict);
        setAudit(final.audit);
        setLiveMsg("Simulation complete.");

        setTimeout(() => onComplete(final), 800);

      } catch (e: any) {
        console.error(e);
        const msg = e?.message ?? "An error occurred.";
        setError(msg);
        setLiveMsg(msg);
        setLoading(false);
      }
    },
    [input, isAuthenticated, onComplete, onAuthRequired]
  );

  const finalVerdict = result?.verdict || verdict;
  const verdictText = finalVerdict ? (typeof finalVerdict === 'string' ? finalVerdict : finalVerdict.decision) : null;

  return (
    <div className="bg-surface border border-border rounded-2xl shadow-2xl overflow-hidden relative">
      <AccessibleLiveRegion message={liveMsg} />
      
      {/* Input Area */}
      <div className="p-1">
        <textarea
            className="w-full h-40 rounded-xl bg-background border border-transparent 
                       px-4 py-4 text-sm text-primary placeholder:text-tertiary 
                       focus:outline-none focus:ring-1 focus:ring-accentBlue focus:border-border
                       resize-none font-sans leading-relaxed transition-all"
            placeholder="Opišite svoj sustav ili ideju. Npr. Želim modernizirati stari ERP sustav na Windows Serveru 2012, prebaciti ga u cloud i osigurati MFA..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={loading}
        />
      </div>

      {/* Footer / Actions */}
      <div className="px-5 py-4 bg-surface border-t border-border flex items-center justify-between">
        <div className="text-xs text-secondary font-medium flex items-center gap-2">
            {!loading && <span className="flex items-center gap-1.5"><Shield size={12} /> Encrypted & Audited</span>}
            {loading && <span className="flex items-center gap-1.5 text-accentBlue"><Activity size={12} className="animate-pulse" /> Processing...</span>}
        </div>

        <button
          onClick={handleSubmit}
          disabled={loading || !input.trim()}
          className="inline-flex items-center gap-2 rounded-lg px-4 py-2
                     bg-primary text-black text-sm font-semibold tracking-tight
                     hover:bg-white/90 transition-colors
                     disabled:opacity-40 disabled:cursor-not-allowed shadow-sm"
        >
          {loading ? <Spinner className="h-4 w-4" /> : <>Pokreni <ArrowRight size={14} /></>}
        </button>
      </div>

      {/* Processing State Overlay / Panel */}
      {(loading || simId) && !result && (
        <div className="border-t border-border bg-background p-6">
            <div className="flex items-center justify-between mb-4">
               <h3 className="text-sm font-semibold text-primary">Kernel Output</h3>
               <span className="text-[10px] font-mono text-tertiary uppercase">SID: {simId}</span>
            </div>

            <AgentProgress timeline={timeline} />
            
            <Reorder.Group 
                axis="y" 
                values={timeline} 
                onReorder={setTimeline}
                className="mt-4 bg-surfaceHighlight/30 rounded-lg p-3 border border-border font-mono text-xs max-h-40 overflow-y-auto space-y-1.5 list-none scrollbar-thin scrollbar-thumb-tertiary/20"
            >
               {timeline.length === 0 && <div className="text-tertiary italic">Initializing orchestration agents...</div>}
               {timeline.map((t, i) => (
                  <Reorder.Item 
                    key={t._id} 
                    value={t}
                    className="flex gap-3 items-center p-1.5 rounded hover:bg-white/5 group bg-surface/50 border border-transparent hover:border-white/10"
                    whileDrag={{ scale: 1.02, boxShadow: "0 5px 15px rgba(0,0,0,0.3)", zIndex: 10 }}
                  >
                    <GripVertical size={14} className="text-tertiary/30 group-hover:text-tertiary/80 cursor-grab active:cursor-grabbing transition-colors shrink-0" />
                    <span className="text-tertiary shrink-0 w-8 text-center">{String(i + 1).padStart(2, '0')}</span>
                    <span className="text-primary font-semibold flex-1">{t.step}</span>
                    <span className="text-secondary opacity-70 text-[10px] uppercase tracking-wider">Completed</span>
                  </Reorder.Item>
               ))}
               <div ref={(el) => el?.scrollIntoView({ behavior: 'smooth' })} />
            </Reorder.Group>

            {verdictText && (
               <div className="mt-4 p-3 rounded bg-accentBlue/10 border border-accentBlue/20 flex items-center justify-between">
                  <span className="text-xs font-bold text-accentBlue uppercase tracking-wide">Interim Verdict</span>
                  <span className="text-sm font-bold text-primary">{verdictText}</span>
               </div>
            )}
        </div>
      )}

      {error && (
        <div className="p-4 bg-red-950/20 border-t border-red-900/30 text-red-400 text-xs text-center">
            {error}
        </div>
      )}
    </div>
  );
});