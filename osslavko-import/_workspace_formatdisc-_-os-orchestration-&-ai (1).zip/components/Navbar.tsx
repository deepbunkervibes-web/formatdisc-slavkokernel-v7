import React, { useState, useEffect } from 'react';
import { Menu, X, Sun, Moon } from 'lucide-react';
import { motion } from 'framer-motion';

interface NavbarProps {
    isAuthenticated: boolean;
    onLoginClick: () => void;
    onLogoutClick: () => void;
    onHistoryClick: () => void;
}

const MotionNav = motion.nav as any;

export const Navbar: React.FC<NavbarProps> = React.memo(({isAuthenticated, onLoginClick, onLogoutClick, onHistoryClick}) => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isDark, setIsDark] = useState(true);
  
  const navLinks = [
    { href: '#hero', label: 'Početna' },
    { href: '#problem', label: 'Problem' },
    { href: '#solution', label: 'Rješenje' },
    { href: '#why-us', label: 'Zašto mi' },
    { href: '#simulate', label: 'Simulacija' },
    { href: '#contact', label: 'Kontakt' },
  ];

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);

    // Initialize theme state
    if (localStorage.theme === 'light' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: light)').matches)) {
        if (!document.documentElement.classList.contains('dark')) {
            setIsDark(false);
        } else {
             // html has dark class by default in index.html, so we trust that unless localStorage says light
            if (localStorage.theme === 'light') {
                 setIsDark(false);
                 document.documentElement.classList.remove('dark');
            }
        }
    } else {
        setIsDark(true);
        document.documentElement.classList.add('dark');
    }

    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleTheme = () => {
      if (isDark) {
          document.documentElement.classList.remove('dark');
          localStorage.theme = 'light';
          setIsDark(false);
      } else {
          document.documentElement.classList.add('dark');
          localStorage.theme = 'dark';
          setIsDark(true);
      }
  };

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
      e.preventDefault();
      document.querySelector(href)?.scrollIntoView({ behavior: 'smooth' });
      setMobileOpen(false);
  }

  return (
    <header className={`fixed inset-x-0 top-0 z-40 transition-all duration-300 ${isScrolled ? 'bg-white/90 dark:bg-black/90 backdrop-blur-lg border-b border-gray-200 dark:border-hackerAccent/50' : 'bg-transparent'}`}>
      <div className="max-w-7xl mx-auto flex items-center justify-between py-4 px-6">
        <a href="#hero" onClick={(e) => handleLinkClick(e, '#hero')} className="font-black text-xl text-hackerGreen drop-shadow-glow tracking-tight">FORMATDISC™</a>

        <nav className="hidden md:flex items-center gap-8">
          {navLinks.map((l) => (
            <a key={l.label} href={l.href} onClick={(e) => handleLinkClick(e, l.href)} className="text-gray-600 dark:text-gray-400 hover:text-black dark:hover:text-white transition font-medium text-sm">
              {l.label}
            </a>
          ))}
        </nav>
        
        <div className="hidden md:flex items-center gap-2">
            <button 
                onClick={toggleTheme}
                className="p-2 rounded-full text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-white/10 transition-colors mr-2"
                aria-label={isDark ? "Switch to light mode" : "Switch to dark mode"}
            >
                {isDark ? <Sun size={20} /> : <Moon size={20} />}
            </button>

            {isAuthenticated ? (
                <>
                 <button onClick={onHistoryClick} className="px-4 py-2 text-sm text-gray-600 dark:text-gray-400 hover:text-black dark:hover:text-white transition font-medium">Povijest</button>
                 <button onClick={onLogoutClick} className="px-4 py-2 text-sm font-medium rounded-md bg-gray-200 dark:bg-hackerAccent text-gray-900 dark:text-white hover:bg-gray-300 dark:hover:bg-gray-700">Odjava</button>
                </>
            ) : (
                 <button onClick={onLoginClick} className="px-4 py-2 text-sm font-medium rounded-md bg-hackerGreen text-black hover:bg-emerald-300 font-semibold">Prijava</button>
            )}
        </div>

        <div className="flex items-center gap-4 md:hidden">
            <button 
                onClick={toggleTheme}
                className="p-2 rounded-full text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-white/10 transition-colors"
                aria-label="Toggle theme"
            >
                {isDark ? <Sun size={20} /> : <Moon size={20} />}
            </button>

            <button
            onClick={() => setMobileOpen(true)}
            className="p-2 rounded-full text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-hackerAccent focus:outline-none focus:ring-2 focus:ring-hackerGreen"
            aria-label="Open menu"
            >
            <Menu className="w-6 h-6" />
            </button>
        </div>

        {/* Mobile drawer */}
        {mobileOpen && (
             <div className="md:hidden fixed inset-0 z-50">
                 <div className="fixed inset-0 bg-black/30 backdrop-blur-sm" onClick={() => setMobileOpen(false)}></div>
                 <MotionNav 
                     initial={{ x: '-100%' }}
                     animate={{ x: 0 }}
                     exit={{ x: '-100%' }}
                     transition={{ type: 'tween', duration: 0.3 }}
                     className="fixed top-0 left-0 w-64 h-full bg-white dark:bg-hackerGray shadow-lg p-6 space-y-4 border-r border-gray-200 dark:border-hackerAccent"
                 >
                     <button
                        onClick={() => setMobileOpen(false)}
                        className="p-2 text-gray-600 dark:text-gray-400 hover:text-black dark:hover:text-white absolute top-4 right-4"
                        aria-label="Close menu"
                     >
                        <X className="w-6 h-6" />
                     </button>
                     <div className="font-black text-xl text-hackerGreen drop-shadow-glow mb-8">FORMATDISC™</div>
                     {navLinks.map((l) => (
                         <a key={l.label} href={l.href} onClick={(e) => handleLinkClick(e, l.href)} className="block text-gray-700 dark:text-gray-300 hover:text-black dark:hover:text-white py-2 font-medium">
                             {l.label}
                         </a>
                     ))}
                     <div className="pt-4 border-t border-gray-200 dark:border-hackerAccent/50">
                         {isAuthenticated ? (
                             <>
                              <button onClick={() => {onHistoryClick(); setMobileOpen(false);}} className="w-full text-left text-gray-700 dark:text-gray-300 hover:text-black dark:hover:text-white py-2 font-medium">Povijest</button>
                              <button onClick={() => {onLogoutClick(); setMobileOpen(false);}} className="w-full text-left text-gray-700 dark:text-gray-300 hover:text-black dark:hover:text-white py-2 font-medium">Odjava</button>
                             </>
                         ) : (
                              <button onClick={() => {onLoginClick(); setMobileOpen(false);}} className="w-full text-left text-gray-700 dark:text-gray-300 hover:text-black dark:hover:text-white py-2 font-medium">Prijava</button>
                         )}
                     </div>
                 </MotionNav>
             </div>
        )}
      </div>
    </header>
  );
});