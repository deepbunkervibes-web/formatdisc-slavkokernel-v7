import React, { useState, useEffect, useRef } from 'react';
import { ArrowRight, Loader2, Save } from 'lucide-react';
import { motion } from 'framer-motion';

interface IdeaInputProps {
  initialIdea: string;
  onSubmit: (idea: string) => void;
  onSave?: (idea: string) => void;
  error: string | null;
  isLoading?: boolean;
}

const MotionDiv = motion.div as any;
const MotionButton = motion.button as any;

const STORAGE_KEY = 'formatdisc_mvp_idea_draft';

export function IdeaInput({ 
  initialIdea, 
  onSubmit, 
  onSave,
  error, 
  isLoading = false 
}: IdeaInputProps) {
  const [idea, setIdea] = useState(initialIdea);
  const [isSaving, setIsSaving] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Load draft from local storage on mount if no initial idea provided
  useEffect(() => {
    if (!initialIdea) {
      const savedDraft = localStorage.getItem(STORAGE_KEY);
      if (savedDraft) {
        setIdea(savedDraft);
      }
    }
  }, [initialIdea]);

  const handleSave = () => {
    if (idea.trim()) {
      localStorage.setItem(STORAGE_KEY, idea);
      setIsSaving(true);
      if (onSave) onSave(idea);
      setTimeout(() => setIsSaving(false), 1500);
    }
  };

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl/Cmd + Enter for submit
      if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
        e.preventDefault();
        if (idea.trim() && !isLoading) {
          handleSubmit(e as any);
        }
      }
      // Ctrl/Cmd + S for save
      if ((e.metaKey || e.ctrlKey) && e.key === 's') {
        e.preventDefault();
        handleSave();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [idea, onSubmit, onSave, isLoading]);

  // Auto-resize textarea
  useEffect(() => {
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = 'auto';
      textarea.style.height = `${textarea.scrollHeight}px`;
    }
  }, [idea]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!idea.trim() || isLoading) return;
    
    // Clear draft on submit
    localStorage.removeItem(STORAGE_KEY);
    onSubmit(idea);
  };

  return (
    <div className="w-full max-w-3xl px-4 py-8 relative">
      {/* Background Animation - Fixed to cover the screen but contained logically */}
      <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
        {/* Blue Orb */}
        <MotionDiv
          className="absolute top-[-10%] left-[-10%] w-[600px] h-[600px] rounded-full bg-accentBlue/10 blur-[100px]"
          animate={{
            x: [0, 50, 0],
            y: [0, 30, 0],
            scale: [1, 1.1, 1],
            opacity: [0.2, 0.3, 0.2],
          }}
          transition={{
            duration: 15,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
        
        {/* Green Orb */}
        <MotionDiv
          className="absolute bottom-[-10%] right-[-10%] w-[500px] h-[500px] rounded-full bg-accentGreen/5 blur-[120px]"
          animate={{
            x: [0, -30, 0],
            y: [0, -50, 0],
            scale: [1, 1.2, 1],
            opacity: [0.1, 0.25, 0.1],
          }}
          transition={{
            duration: 18,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />

        {/* Yellow Orb (Subtle Center) */}
        <MotionDiv
          className="absolute top-[40%] left-[50%] -translate-x-1/2 w-[400px] h-[400px] rounded-full bg-accentYellow/5 blur-[90px]"
          animate={{
            scale: [1, 1.3, 1],
            opacity: [0.05, 0.1, 0.05],
          }}
          transition={{
            duration: 12,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      </div>

      <div className="space-y-6 relative z-10">
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-semibold tracking-tight text-primaryText">
            SlavkoKernel MVP Studio
          </h1>
          <p className="text-lg text-secondaryText max-w-2xl mx-auto">
            Upiši svoju ideju. Council će je evaluirati, pa automatski složiti MVP simulaciju i pitch deck – sve u jednom koraku.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <MotionDiv
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <textarea
              ref={textareaRef}
              value={idea}
              onChange={(e) => setIdea(e.target.value)}
              placeholder="Npr. Želim modernizirati on-prem ERP sustav za proizvodne tvrtke u regiji, smanjiti downtime i licence za 30%, cilj investicija 500k EUR..."
              rows={8}
              className="w-full rounded-xl bg-tertiaryBg/80 backdrop-blur-sm border border-borderColor
                      px-5 py-4 text-base text-primaryText placeholder:text-secondaryText
                      focus:outline-none focus:ring-2 focus:ring-accentBlue focus:border-accentBlue
                      resize-none transition-all shadow-lg overflow-hidden min-h-[160px]"
              autoFocus
              aria-label="Unos vaše ideje"
              disabled={isLoading}
            />
          </MotionDiv>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <span className="text-xs text-secondaryText">
                {idea.length} znakova
              </span>
              <button
                type="button"
                onClick={handleSave}
                className="text-xs text-secondaryText hover:text-primaryText flex items-center gap-1 transition-colors"
                title="Spremi skicu (Ctrl+S)"
              >
                 <Save size={12} />
                 <span className="hidden sm:inline">Spremi</span>
              </button>
              
              {isSaving && (
                <span className="text-xs text-green-500 font-medium animate-pulse">
                  Spremljeno!
                </span>
              )}
            </div>

            <MotionButton
              type="submit"
              disabled={!idea.trim() || isLoading}
              whileHover={{ scale: 1.02, backgroundColor: '#2563eb' }}
              whileTap={{ scale: 0.98 }}
              className="inline-flex items-center gap-2 rounded-full px-6 py-3
                       bg-accentBlue text-white text-sm font-semibold tracking-tight
                       hover:bg-blue-600 transition-colors shadow-lg shadow-accentBlue/20
                       disabled:opacity-40 disabled:hover:bg-accentBlue disabled:cursor-not-allowed"
              aria-label="Pošalji ideju na evaluaciju"
            >
              {isLoading ? (
                <>
                  <Loader2 className="animate-spin" size={16} />
                  U obradi...
                </>
              ) : (
                <>
                  Provjeri ideju
                  <ArrowRight size={16} />
                </>
              )}
            </MotionButton>
          </div>

          {error && (
            <MotionDiv 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="rounded-lg bg-accentRed/20 border border-accentRed px-4 py-3 text-sm text-accentRed"
              role="alert"
            >
              {error}
            </MotionDiv>
          )}
        </form>

        <p className="text-xs text-secondaryText text-center pt-4">
          Bez registracije. Bez auth. Čisto AI‑driven MVP proces. (Ctrl+S za spremanje)
        </p>
      </div>
    </div>
  );
}