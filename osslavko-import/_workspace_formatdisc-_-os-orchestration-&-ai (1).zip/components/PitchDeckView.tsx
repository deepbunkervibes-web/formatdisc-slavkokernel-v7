import React from 'react';
import { PitchDeck } from '../types/mvpStudio';
import { motion } from 'framer-motion';

interface PitchDeckViewProps {
  deck: PitchDeck;
}

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const item = {
  hidden: { opacity: 0, x: 20 },
  show: { opacity: 1, x: 0 }
};

const MotionDiv = motion.div as any;

export function PitchDeckView({ deck }: PitchDeckViewProps) {
  return (
    <MotionDiv 
      variants={container}
      initial="hidden"
      animate="show"
      className="space-y-4"
    >
      {deck.slides.map((slide, i) => (
        <MotionDiv
          key={i}
          variants={item}
          className="rounded-lg bg-tertiaryBg border border-borderColor p-5 space-y-2 hover:shadow-lg transition-all"
        >
          <div className="flex items-center gap-2">
            <span className="flex items-center justify-center w-6 h-6 rounded-full bg-accentBlue text-white text-xs font-bold shadow-sm">
              {i + 1}
            </span>
            <h4 className="text-base font-semibold text-primaryText">{slide.title}</h4>
          </div>

          <ul className="ml-4 space-y-1 text-sm text-secondaryText list-disc">
            {slide.bullets.map((bullet, j) => (
              <li key={j}>{bullet}</li>
            ))}
          </ul>

          {slide.notes && (
            <p className="text-xs text-secondaryText italic mt-2 border-t border-borderColor/50 pt-2">
              Napomena: {slide.notes}
            </p>
          )}
        </MotionDiv>
      ))}
    </MotionDiv>
  );
}