import React from 'react';
import { Simulation } from '../types';
import { TestIdeaEnhanced } from './TestIdeaEnhanced';
import { motion } from 'framer-motion';

interface SimulateSectionProps {
  isAuthenticated: boolean;
  onComplete: (result: Simulation) => void;
  onAuthRequired: () => void;
}

const MotionDiv = motion.div as any;

export const SimulateSection: React.FC<SimulateSectionProps> = React.memo(({ isAuthenticated, onComplete, onAuthRequired }) => {
  return (
    <section id="simulate" className="py-20 bg-hackerGray">
      <div className="max-w-3xl mx-auto px-6 text-center">
        <MotionDiv
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
        >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-100 mb-4">Isprobajte SlavkoKernel™</h2>
            <p className="text-lg text-gray-400 mb-10">
                Opišite svoj infrastrukturni izazov ili startup ideju. Naš AI council će generirati trenutni, auditirani izvještaj s procjenom rizika i preporukama.
            </p>
            <TestIdeaEnhanced 
                isAuthenticated={isAuthenticated}
                onComplete={onComplete}
                onAuthRequired={onAuthRequired}
            />
        </MotionDiv>
      </div>
    </section>
  );
});