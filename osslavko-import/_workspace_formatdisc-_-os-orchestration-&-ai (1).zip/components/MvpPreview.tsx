import React, { useState } from 'react';
import { MvpBlueprint } from '../types/mvpStudio';
import { motion } from 'framer-motion';
import { CodeEditor } from './ui/CodeEditor';
import { LayoutTemplate, Code2 } from 'lucide-react';

interface MvpPreviewProps {
  blueprint: MvpBlueprint;
}

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 }
};

const MotionDiv = motion.div as any;
const MotionButton = motion.button as any;

export function MvpPreview({ blueprint }: MvpPreviewProps) {
  const [viewMode, setViewMode] = useState<'visual' | 'code'>('visual');

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between border-b border-borderColor pb-4">
        <div className="space-y-1">
             <h3 className="text-xl font-semibold text-primaryText">{blueprint.project_name}</h3>
             <p className="text-sm text-secondaryText">{blueprint.value_proposition}</p>
        </div>
        
        <div className="flex bg-tertiaryBg rounded-lg p-1 border border-borderColor">
            <button 
                onClick={() => setViewMode('visual')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-all ${viewMode === 'visual' ? 'bg-accentBlue text-white shadow-sm' : 'text-secondaryText hover:text-primaryText'}`}
            >
                <LayoutTemplate size={14} /> Preview
            </button>
            <button 
                onClick={() => setViewMode('code')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-all ${viewMode === 'code' ? 'bg-accentBlue text-white shadow-sm' : 'text-secondaryText hover:text-primaryText'}`}
            >
                <Code2 size={14} /> Blueprint Source
            </button>
        </div>
      </div>

      {viewMode === 'visual' ? (
        <MotionDiv 
          variants={container}
          initial="hidden"
          animate="show"
          className="space-y-6"
        >
          <div className="space-y-4">
            {blueprint.ui_sections.map((section, i) => (
              <MotionDiv
                key={i}
                variants={item}
                className="rounded-lg bg-tertiaryBg border border-borderColor p-4 space-y-2 hover:border-accentBlue/30 transition-colors"
              >
                <div className="text-xs text-secondaryText uppercase tracking-wide">{section.type}</div>
                <h4 className="text-base font-semibold text-primaryText">{section.heading}</h4>
                <p className="text-sm text-secondaryText">{section.copy}</p>
                {section.cta_text && (
                  <MotionButton 
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="mt-2 px-4 py-2 rounded-full bg-accentBlue text-white text-xs font-medium"
                  >
                    {section.cta_text}
                  </MotionButton>
                )}
              </MotionDiv>
            ))}
          </div>

          <MotionDiv variants={item} className="space-y-2">
            <h4 className="text-sm font-semibold text-primaryText">Ključni tokovi:</h4>
            {blueprint.core_flows.map((flow, i) => (
              <details key={i} className="rounded-lg bg-tertiaryBg border border-borderColor p-3 group">
                <summary className="cursor-pointer text-sm font-medium text-primaryText group-hover:text-accentBlue transition-colors">
                  {flow.name}
                </summary>
                <ul className="mt-2 ml-4 space-y-1 text-xs text-secondaryText list-disc">
                  {flow.steps.map((step, j) => (
                    <li key={j}>{step}</li>
                  ))}
                </ul>
              </details>
            ))}
          </MotionDiv>

          {blueprint.tech_stack && blueprint.tech_stack.length > 0 && (
            <MotionDiv variants={item} className="text-xs text-secondaryText">
              <strong>Tech stack:</strong> {blueprint.tech_stack.join(', ')}
            </MotionDiv>
          )}
        </MotionDiv>
      ) : (
        <MotionDiv 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="h-full"
        >
            <CodeEditor 
                code={JSON.stringify(blueprint, null, 2)} 
                language="json" 
                height="500px"
            />
        </MotionDiv>
      )}
    </div>
  );
}