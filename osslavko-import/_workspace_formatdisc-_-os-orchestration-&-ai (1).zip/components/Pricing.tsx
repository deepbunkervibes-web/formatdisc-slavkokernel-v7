import React from 'react';
import { motion } from 'framer-motion';
import { Check } from 'lucide-react';
import { GlassCard } from './GlassCard';

const tiers = [
  {
    name: 'Starter',
    price: '€2 999',
    features: [
      '48-hour delivery SLA (core UI + auth + CI)',
      'Basic UI – no motion',
      'Basic username/password',
      'SQLite / local database',
      'Single-agent loop',
      'Basic logging',
      'Email + community hub support',
    ],
    highlight: false,
  },
  {
    name: 'Pro',
    price: '€7 499',
    features: [
      '48-hour delivery SLA (full pipeline)',
      'Refined, animation-ready UI',
      'MFA + OAuth2 (OIDC)',
      'PostgreSQL (single-region)',
      'Multi-agent scheduling',
      'GDPR-hints, eSBOM compliance',
      'Light audit trail',
      'Live sandbox & pipeline visualizer',
      '24/7 chat + phone support',
    ],
    highlight: true,
  },
  {
    name: 'Enterprise',
    price: '€14 999',
    features: [
      '48-hour SLA + rollback window',
      'Full Motion-First, responsive UI',
      'SSO + 2FA + PKI + fine-grained RBAC',
      'Multi-region PostgreSQL',
      'Deterministic agent mesh',
      'GDPR + SOC 2 + custom audit rules',
      'Full, cryptographically signed audit trail',
      'Council governance layer',
      '24/7 onsite + dedicated ops engineer',
    ],
    highlight: false,
  },
];

const MotionDiv = motion.div as any;

export const Pricing: React.FC = React.memo(() => (
  <section id="pricing" className="py-20 bg-black">
    <div className="max-w-7xl mx-auto px-6">
      <div className="text-center mb-16">
        <h2 className="text-3xl md:text-4xl font-bold text-gray-100 mb-4">
          Audit-Ready, Deterministic Delivery
        </h2>
        <p className="text-lg text-gray-400 max-w-2xl mx-auto">
          Transparentni paketi. Fiksna cijena. Isporuka unutar 48 sati, garantirano.
        </p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start max-w-6xl mx-auto">
        {tiers.map((tier, i) => (
          <MotionDiv
            key={tier.name}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: i * 0.1 }}
            className={`h-full ${tier.highlight ? 'lg:scale-105' : ''}`}
          >
             <GlassCard className={`p-8 h-full flex flex-col transition-all duration-300 ${tier.highlight ? 'border-hackerGreen/50 shadow-2xl drop-shadow-glow' : 'hover:border-gray-700'}`}>
                <h3 className="text-2xl font-bold text-gray-100">{tier.name}</h3>
                <p className="text-4xl font-black text-hackerGreen mt-4 mb-6 drop-shadow-glow">{tier.price}<span className="text-base font-medium text-gray-400">/god.</span></p>
                
                <ul className="space-y-3 text-gray-400 flex-grow mb-8">
                  {tier.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-3">
                      <Check size={18} className="text-hackerGreen shrink-0 mt-0.5" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>

                <a
                  href="#contact"
                  className={`w-full text-center mt-auto px-6 py-3 rounded-lg font-semibold transition-colors ${
                    tier.highlight
                      ? 'bg-hackerGreen text-black hover:bg-emerald-300'
                      : 'bg-hackerAccent text-gray-300 hover:bg-gray-700'
                  }`}
                >
                  Zatraži ponudu
                </a>
            </GlassCard>
          </MotionDiv>
        ))}
      </div>
    </div>
  </section>
));
