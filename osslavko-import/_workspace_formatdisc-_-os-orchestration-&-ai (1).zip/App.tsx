import React, { useState, useEffect, useCallback } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ProblemSection } from './components/ProblemSection';
import { SolutionSection } from './components/SolutionSection';
import { WhyUs } from './components/WhyUs';
import { Pricing } from './components/Pricing';
import { SimulateSection } from './components/SimulateSection';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { AuthForm } from './components/AuthForm';
import { HistoryList } from './components/HistoryList';
import { ResultsDashboard } from './components/ResultsDashboard';
import { backendApiService, isAuthenticated } from './services/backendApiService';
import { SimulationResult, AuthTokens } from './types';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Loader2 } from 'lucide-react';

type AppView = 'landing' | 'auth' | 'history' | 'results';

function App() {
  const [view, setView] = useState<AppView>('landing');
  const [isAuth, setIsAuth] = useState(isAuthenticated());
  const [selectedSim, setSelectedSim] = useState<SimulationResult | null>(null);
  const [loadingSim, setLoadingSim] = useState(false);

  useEffect(() => {
    setIsAuth(isAuthenticated());
  }, []);

  const handleLoginClick = () => setView('auth');
  
  const handleLogoutClick = () => {
    backendApiService.logout();
    setIsAuth(false);
    setView('landing');
  };
  
  const handleHistoryClick = () => {
    if (isAuth) {
      setView('history');
    } else {
      setView('auth');
    }
  };
  
  const handleLoginSuccess = (tokens: AuthTokens) => {
    setIsAuth(true);
    setView('landing');
  };

  const handleViewDetails = useCallback(async (simId: number) => {
    setLoadingSim(true);
    setView('results');
    try {
      const details = await backendApiService.getSimulationDetails(simId);
      setSelectedSim(details);
    } catch(e) {
      console.error(e);
      // Ideally, show an error toast to the user
      setView('history'); // Go back to history on error
    } finally {
      setLoadingSim(false);
    }
  }, []);

  const handleSimulateComplete = (result: SimulationResult) => {
      setSelectedSim(result);
      setView('results');
  };

  const handleReset = () => {
      setSelectedSim(null);
      setView('landing');
      setTimeout(() => {
        document.getElementById('simulate')?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
  };
  
  const renderView = () => {
    switch(view) {
      case 'auth':
        return <AuthForm onLoginSuccess={handleLoginSuccess} onCancel={() => setView('landing')} />;
      case 'history':
        return <HistoryList onBack={() => setView('landing')} onViewDetails={handleViewDetails} />;
      case 'results':
        if (loadingSim) {
          return (
            <div className="min-h-screen flex flex-col items-center justify-center text-gray-500 dark:text-gray-400">
                <Loader2 className="animate-spin text-hackerGreen mb-4" size={32} />
                <p>Loading simulation results...</p>
            </div>
          );
        }
        if (selectedSim) return <ResultsDashboard data={selectedSim} onReset={handleReset} onViewHistory={handleHistoryClick} />;
        return (
            <div className="min-h-screen flex items-center justify-center text-gray-500 dark:text-gray-400">
                <p>No result selected. Please return to history.</p>
            </div>
        );
      case 'landing':
      default:
        return (
          <>
            <Hero isAuthenticated={isAuth} onLoginClick={handleLoginClick} />
            <ProblemSection />
            <SolutionSection />
            <WhyUs />
            <Pricing />
            <SimulateSection 
                isAuthenticated={isAuth}
                onComplete={handleSimulateComplete}
                onAuthRequired={handleLoginClick}
            />
            <Contact />
            <Footer />
          </>
        );
    }
  };

  return (
    <div className="min-h-screen bg-white dark:bg-hackerGray text-gray-900 dark:text-gray-200 font-sans transition-colors duration-300">
      <ErrorBoundary>
        <Navbar 
          isAuthenticated={isAuth}
          onLoginClick={handleLoginClick}
          onLogoutClick={handleLogoutClick}
          onHistoryClick={handleHistoryClick}
        />
        <main>
          {renderView()}
        </main>
      </ErrorBoundary>
    </div>
  );
}

export default App;