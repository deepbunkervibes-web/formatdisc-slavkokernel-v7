// Faze kroz koje prolazi MVP Studio
export type MvpStudioPhase =
  | 'IDEA_INPUT'      // Korisnik unosi ideju
  | 'EVALUATING'      // SlavkoKernel evaluira ideju
  | 'MVP_BUILDING'    // Generira se MVP blueprint i pitch deck
  | 'RESULT';         // Prikazuju se svi rezultati

// Rezultat evaluacije ideje od strane SlavkoKernel councila
export interface IdeaEvaluation {
  verdict: 'PROCEED' | 'REVISE' | 'REJECT'; // Konačna odluka
  score: number;                            // Numerička ocjena (0-10)
  summary: string;                          // Kratki sažetak evaluacije
  pattern_analysis: string;                 // Analiza prepoznatog poslovnog obrasca
  risk_assessment: string;                  // Procjena rizika
  eval_notes: string;                       // Dodatne bilješke evaluacije
  think_recommendation: string;             // Preporuka za daljnje korake
  logs: Array<{                              // Detaljni logovi agenata
    timestamp: string;
    agent: string;
    message: string;
    status: 'INFO' | 'SUCCESS' | 'ERROR' | 'PROCESSING';
  }>;
}

// Blueprint za generiranu MVP simulaciju
export interface MvpBlueprint {
  project_name: string;
  value_proposition: string;
  target_users: string[];
  core_flows: Array<{
    name: string;
    steps: string[];
  }>;
  ui_sections: Array<{
    id: string;
    type: 'hero' | 'features' | 'pricing' | 'cta' | 'testimonials' | 'about';
    heading: string;
    copy: string;
    cta_text?: string;
  }>;
  tech_stack?: string[];
  estimated_time_weeks?: number;
}

// Struktura pitch decka
export interface PitchDeck {
  slides: Array<{
    title: string;
    bullets: string[];
    notes?: string;
  }>;
}

// Sažetak za investitore
export interface InvestorSummary {
  problem: string;
  solution: string;
  market_size: string;
  competitive_advantage: string;
  funding_ask: string;
  use_of_funds: string[];
  email_template: string; // Generiran tekst za email
}

// Glavni state objekt za MvpStudio komponentu
export interface MvpStudioState {
  phase: MvpStudioPhase;
  idea: string;
  evaluation: IdeaEvaluation | null;
  mvpBlueprint: MvpBlueprint | null;
  pitchDeck: PitchDeck | null;
  investorSummary: InvestorSummary | null;
  error: string | null;
}
