"use client"

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState } from "react"
import type { ModuleTelemetry, ModuleId } from "@/lib/telemetry/types"

interface UseKernelTelemetryOptions {
  moduleId: ModuleId
  pollIntervalMs?: number
}

export function useKernelTelemetry({ moduleId, pollIntervalMs = 15000 }: UseKernelTelemetryOptions) {
  const [data, setData] = useState<ModuleTelemetry | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const ws: WebSocket | null = null
    let pollTimer: number | null = null
    let cancelled = false

    // Simulate real telemetry data for demo purposes since we don't have a real backend
    const getMockTelemetry = (id: ModuleId): ModuleTelemetry => ({
      id,
      status: "OK",
      latencyMs: 12 + Math.random() * 5,
      integrityScore: 98 + Math.random() * 2,
      lastUpdated: new Date().toISOString(),
      incidentsLast24h: 0,
    })

    async function fetchSnapshot() {
      try {
        // In production: const res = await fetch(`/api/telemetry/modules/${moduleId}`);
        // Mocking for frontend-only environment:
        const json = getMockTelemetry(moduleId)
        if (!cancelled) {
          setData(json)
          setLoading(false)
          setError(null)
        }
      } catch (err: any) {
        if (!cancelled) {
          setError(err?.message ?? "Telemetry fetch failed")
          setLoading(false)
        }
      }
    }

    fetchSnapshot()

    // 2) Websocket (Simulated for this environment)
    // In production, we'd connect to real WS. Here we simulate updates via interval.
    const wsSimulation = setInterval(() => {
      if (!cancelled && Math.random() > 0.7) {
        setData((prev) =>
          prev
            ? {
                ...prev,
                latencyMs: 10 + Math.random() * 10,
                integrityScore: 95 + Math.random() * 5,
              }
            : null,
        )
      }
    }, 2000)

    pollTimer = window.setInterval(fetchSnapshot, pollIntervalMs)

    return () => {
      cancelled = true
      clearInterval(wsSimulation)
      if (pollTimer) window.clearInterval(pollTimer)
    }
  }, [moduleId, pollIntervalMs])

  return { data, loading, error }
}
