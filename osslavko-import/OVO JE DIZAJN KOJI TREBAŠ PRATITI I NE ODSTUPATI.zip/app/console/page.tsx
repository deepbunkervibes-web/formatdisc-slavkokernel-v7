import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { ConsoleContent } from "@/components/console/console-content"

export default async function ConsolePage() {
  const supabase = await createClient()
  const { data, error } = await supabase.auth.getUser()

  if (error || !data?.user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", data.user.id).single()

  return <ConsoleContent user={data.user} profile={profile} />
}
