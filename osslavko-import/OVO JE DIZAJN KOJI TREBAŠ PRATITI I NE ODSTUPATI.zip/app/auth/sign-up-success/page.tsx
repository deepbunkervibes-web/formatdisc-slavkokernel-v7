import Link from "next/link"
import { Terminal, Mail, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function SignUpSuccessPage() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6">
      {/* Background effects */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl" />
      </div>

      <div className="w-full max-w-md relative z-10 text-center">
        <div className="bg-card border border-border rounded-2xl p-8">
          <div className="w-16 h-16 bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
            <Mail className="w-8 h-8 text-emerald-500" />
          </div>

          <div className="flex items-center justify-center gap-2 mb-4">
            <Terminal className="w-5 h-5 text-emerald-500" />
            <span className="text-sm font-mono text-emerald-500">SLAVKO-OS</span>
          </div>

          <h1 className="text-2xl font-semibold text-foreground mb-2">Check your email</h1>
          <p className="text-muted-foreground mb-8">
            {"We've sent you a confirmation link. Click it to activate your account and access the kernel."}
          </p>

          <div className="space-y-4">
            <Button asChild className="w-full bg-emerald-500 hover:bg-emerald-600 text-background">
              <Link href="/auth/login">
                Back to login
                <ArrowRight className="w-4 h-4 ml-2" />
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
