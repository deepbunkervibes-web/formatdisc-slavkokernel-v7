import { Header } from "@/components/landing/header"
import { Hero } from "@/components/landing/hero"
import { Stats } from "@/components/landing/stats"
import { Features } from "@/components/landing/features"
import { Models } from "@/components/landing/models"
import { FibonacciDemo } from "@/components/landing/fibonacci-demo"
import { TelemetryDashboard } from "@/components/landing/telemetry-dashboard"
import { Pricing } from "@/components/landing/pricing"
import { CTA } from "@/components/landing/cta"
import { Footer } from "@/components/landing/footer"

export default function Page() {
  return (
    <main className="min-h-screen bg-background">
      <Header />
      <Hero />
      <Stats />
      <Features />
      <Models />
      <FibonacciDemo />
      <TelemetryDashboard />
      <Pricing />
      <CTA />
      <Footer />
    </main>
  )
}
