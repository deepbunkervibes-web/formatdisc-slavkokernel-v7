import { DocsContent } from "@/components/docs/docs-content"

export default function DocsPage() {
  return <DocsContent />
}
