"use client"

import { ChevronDown, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface Model {
  id: string
  name: string
  provider: string
  latency: string
}

interface ModelSelectorProps {
  models: Model[]
  selected: Model
  onSelect: (model: Model) => void
}

export function ModelSelector({ models, selected, onSelect }: ModelSelectorProps) {
  return (
    <div className="flex items-center gap-4">
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" className="bg-background border-border">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-emerald-500 rounded-full" />
              <span className="font-medium">{selected.name}</span>
              <span className="text-xs text-muted-foreground">({selected.provider})</span>
            </div>
            <ChevronDown className="w-4 h-4 ml-2 text-muted-foreground" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="w-64">
          {models.map((model) => (
            <DropdownMenuItem
              key={model.id}
              onClick={() => onSelect(model)}
              className={model.id === selected.id ? "bg-emerald-500/10" : ""}
            >
              <div className="flex items-center justify-between w-full">
                <div className="flex items-center gap-2">
                  <div
                    className={`w-2 h-2 rounded-full ${model.id === selected.id ? "bg-emerald-500" : "bg-muted-foreground"}`}
                  />
                  <div>
                    <p className="text-sm font-medium">{model.name}</p>
                    <p className="text-xs text-muted-foreground">{model.provider}</p>
                  </div>
                </div>
                <span className="text-xs text-muted-foreground">{model.latency}</span>
              </div>
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>

      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <Zap className="w-4 h-4 text-emerald-500" />
        <span>Ready</span>
      </div>
    </div>
  )
}
