"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Send, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"

interface ConsoleInputProps {
  onSubmit: (input: string) => void
  isProcessing: boolean
}

export function ConsoleInput({ onSubmit, isProcessing }: ConsoleInputProps) {
  const [input, setInput] = useState("")
  const [history, setHistory] = useState<string[]>([])
  const [historyIndex, setHistoryIndex] = useState(-1)
  const inputRef = useRef<HTMLTextAreaElement>(null)

  useEffect(() => {
    inputRef.current?.focus()
  }, [])

  const handleSubmit = () => {
    if (!input.trim() || isProcessing) return

    onSubmit(input)
    setHistory((prev) => [input, ...prev])
    setInput("")
    setHistoryIndex(-1)
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSubmit()
    }

    if (e.key === "ArrowUp" && history.length > 0) {
      e.preventDefault()
      const newIndex = Math.min(historyIndex + 1, history.length - 1)
      setHistoryIndex(newIndex)
      setInput(history[newIndex])
    }

    if (e.key === "ArrowDown") {
      e.preventDefault()
      if (historyIndex > 0) {
        const newIndex = historyIndex - 1
        setHistoryIndex(newIndex)
        setInput(history[newIndex])
      } else {
        setHistoryIndex(-1)
        setInput("")
      }
    }
  }

  return (
    <div className="border-t border-border bg-card/50 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-end gap-3 bg-background border border-border rounded-xl p-3 focus-within:border-emerald-500/50 transition-colors">
          <div className="flex items-center gap-2 text-emerald-500 font-mono text-sm">
            <span className="text-muted-foreground">$</span>
            <span>slavko</span>
            <span className="text-muted-foreground">~</span>
          </div>

          <textarea
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Enter command or query..."
            disabled={isProcessing}
            className="flex-1 bg-transparent border-none outline-none resize-none text-foreground placeholder:text-muted-foreground min-h-[24px] max-h-[200px]"
            rows={1}
          />

          <Button
            onClick={handleSubmit}
            disabled={!input.trim() || isProcessing}
            size="icon"
            className="bg-emerald-500 hover:bg-emerald-600 text-background shrink-0"
          >
            {isProcessing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          </Button>
        </div>

        <div className="flex items-center justify-between mt-2 text-xs text-muted-foreground">
          <span>Press Enter to send, Shift+Enter for new line</span>
          <span>↑↓ for history</span>
        </div>
      </div>
    </div>
  )
}
