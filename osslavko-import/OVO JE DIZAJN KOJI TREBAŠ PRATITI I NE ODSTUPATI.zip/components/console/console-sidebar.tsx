"use client"

import { PanelLeftClose, PanelLeft, Clock, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"

interface Message {
  id: string
  role: "user" | "assistant" | "system"
  content: string
  timestamp: Date
}

interface ConsoleSidebarProps {
  open: boolean
  onToggle: () => void
  messages: Message[]
}

export function ConsoleSidebar({ open, onToggle, messages }: ConsoleSidebarProps) {
  const sessions = [
    { id: "current", name: "Current Session", active: true, messageCount: messages.length },
    { id: "prev-1", name: "API Integration", active: false, messageCount: 24 },
    { id: "prev-2", name: "Database Query", active: false, messageCount: 12 },
  ]

  if (!open) {
    return (
      <div className="border-r border-border bg-card/50 p-2">
        <Button variant="ghost" size="icon" onClick={onToggle} className="text-muted-foreground">
          <PanelLeft className="w-4 h-4" />
        </Button>
      </div>
    )
  }

  return (
    <div className="w-64 border-r border-border bg-card/50 flex flex-col">
      <div className="p-4 border-b border-border flex items-center justify-between">
        <h2 className="font-semibold text-foreground">Sessions</h2>
        <Button variant="ghost" size="icon" onClick={onToggle} className="text-muted-foreground">
          <PanelLeftClose className="w-4 h-4" />
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto p-2 space-y-1">
        {sessions.map((session) => (
          <button
            key={session.id}
            className={`w-full text-left p-3 rounded-lg transition-colors ${
              session.active
                ? "bg-emerald-500/10 border border-emerald-500/20"
                : "hover:bg-background border border-transparent"
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className={`text-sm font-medium ${session.active ? "text-emerald-500" : "text-foreground"}`}>
                {session.name}
              </span>
              {session.active && <div className="w-2 h-2 bg-emerald-500 rounded-full" />}
            </div>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Clock className="w-3 h-3" />
              <span>{session.messageCount} messages</span>
            </div>
          </button>
        ))}
      </div>

      <div className="p-4 border-t border-border">
        <Button variant="ghost" className="w-full justify-start text-muted-foreground hover:text-red-400">
          <Trash2 className="w-4 h-4 mr-2" />
          Clear History
        </Button>
      </div>
    </div>
  )
}
