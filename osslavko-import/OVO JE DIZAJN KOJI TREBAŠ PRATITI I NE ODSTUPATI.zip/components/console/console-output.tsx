"use client"

import { forwardRef } from "react"
import { Terminal, User, Bot, Loader2 } from "lucide-react"

interface Message {
  id: string
  role: "user" | "assistant" | "system"
  content: string
  model?: string
  tokens?: number
  latency?: number
  timestamp: Date
}

interface ConsoleOutputProps {
  messages: Message[]
  isProcessing: boolean
}

export const ConsoleOutput = forwardRef<HTMLDivElement, ConsoleOutputProps>(({ messages, isProcessing }, ref) => {
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    })
  }

  return (
    <div ref={ref} className="flex-1 overflow-y-auto p-6 font-mono text-sm">
      <div className="max-w-4xl mx-auto space-y-4">
        {messages.map((message) => (
          <div key={message.id} className="group">
            {message.role === "system" && (
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 bg-emerald-500/10 rounded flex items-center justify-center shrink-0">
                  <Terminal className="w-3 h-3 text-emerald-500" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-emerald-500 text-xs">SYSTEM</span>
                    <span className="text-muted-foreground text-xs">{formatTime(message.timestamp)}</span>
                  </div>
                  <pre className="text-muted-foreground whitespace-pre-wrap">{message.content}</pre>
                </div>
              </div>
            )}

            {message.role === "user" && (
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 bg-blue-500/10 rounded flex items-center justify-center shrink-0">
                  <User className="w-3 h-3 text-blue-500" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-blue-500 text-xs">USER</span>
                    <span className="text-muted-foreground text-xs">{formatTime(message.timestamp)}</span>
                  </div>
                  <pre className="text-foreground whitespace-pre-wrap">{message.content}</pre>
                </div>
              </div>
            )}

            {message.role === "assistant" && (
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 bg-emerald-500/10 rounded flex items-center justify-center shrink-0">
                  <Bot className="w-3 h-3 text-emerald-500" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-emerald-500 text-xs">{message.model || "ASSISTANT"}</span>
                    <span className="text-muted-foreground text-xs">{formatTime(message.timestamp)}</span>
                    {message.tokens && <span className="text-muted-foreground text-xs">• {message.tokens} tokens</span>}
                    {message.latency && <span className="text-muted-foreground text-xs">• {message.latency}ms</span>}
                  </div>
                  <pre className="text-foreground whitespace-pre-wrap bg-card/50 p-3 rounded-lg border border-border">
                    {message.content}
                  </pre>
                </div>
              </div>
            )}
          </div>
        ))}

        {isProcessing && (
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 bg-emerald-500/10 rounded flex items-center justify-center shrink-0">
              <Loader2 className="w-3 h-3 text-emerald-500 animate-spin" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="text-emerald-500 text-xs">PROCESSING</span>
                <span className="text-muted-foreground text-xs animate-pulse">Executing kernel...</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
})

ConsoleOutput.displayName = "ConsoleOutput"
