"use client"

import { useState, useRef, useEffect } from "react"
import type { User } from "@supabase/supabase-js"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { ConsoleInput } from "./console-input"
import { ConsoleOutput } from "./console-output"
import { ConsoleSidebar } from "./console-sidebar"
import { ModelSelector } from "./model-selector"

interface Profile {
  display_name: string | null
  tier: string
  token_budget: number
  tokens_used: number
}

interface Message {
  id: string
  role: "user" | "assistant" | "system"
  content: string
  model?: string
  tokens?: number
  latency?: number
  timestamp: Date
}

interface ConsoleContentProps {
  user: User
  profile: Profile | null
}

const MODELS = [
  { id: "gemini-3-flash", name: "Gemini 3 Flash", provider: "Google", latency: "~200ms" },
  { id: "gemini-3-pro", name: "Gemini 3 Pro", provider: "Google", latency: "~800ms" },
  { id: "claude-sonnet-4", name: "Claude Sonnet 4", provider: "Anthropic", latency: "~600ms" },
  { id: "gpt-4o", name: "GPT-4o", provider: "OpenAI", latency: "~500ms" },
  { id: "deepseek-v3", name: "DeepSeek V3", provider: "DeepSeek", latency: "~400ms" },
]

export function ConsoleContent({ user, profile }: ConsoleContentProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "system",
      content: "SLAVKO-OS Kernel initialized. Ready for input.",
      timestamp: new Date(),
    },
  ])
  const [selectedModel, setSelectedModel] = useState(MODELS[0])
  const [isProcessing, setIsProcessing] = useState(false)
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const outputRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (outputRef.current) {
      outputRef.current.scrollTop = outputRef.current.scrollHeight
    }
  }, [messages])

  const handleSubmit = async (input: string) => {
    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setIsProcessing(true)

    // Simulate model response
    await new Promise((r) => setTimeout(r, 500 + Math.random() * 1000))

    const assistantMessage: Message = {
      id: (Date.now() + 1).toString(),
      role: "assistant",
      content: generateResponse(input, selectedModel.id),
      model: selectedModel.name,
      tokens: Math.floor(50 + Math.random() * 200),
      latency: Math.floor(200 + Math.random() * 800),
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, assistantMessage])
    setIsProcessing(false)
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <DashboardHeader user={user} profile={profile} />

      <div className="flex-1 flex">
        {/* Sidebar */}
        <ConsoleSidebar open={sidebarOpen} onToggle={() => setSidebarOpen(!sidebarOpen)} messages={messages} />

        {/* Main console area */}
        <main className="flex-1 flex flex-col">
          {/* Model selector bar */}
          <div className="border-b border-border bg-card/50 px-6 py-3">
            <ModelSelector models={MODELS} selected={selectedModel} onSelect={setSelectedModel} />
          </div>

          {/* Output area */}
          <ConsoleOutput ref={outputRef} messages={messages} isProcessing={isProcessing} />

          {/* Input area */}
          <ConsoleInput onSubmit={handleSubmit} isProcessing={isProcessing} />
        </main>
      </div>
    </div>
  )
}

function generateResponse(input: string, modelId: string): string {
  const responses: Record<string, string> = {
    help: `Available commands:
- /models - List available models
- /clear - Clear console
- /status - Show kernel status
- /config - Show configuration
- Any other input will be processed by ${modelId}`,
    "/models": `Model Registry:
├── gemini-3-flash (Google) - Fast inference
├── gemini-3-pro (Google) - High quality
├── claude-sonnet-4 (Anthropic) - Balanced
├── gpt-4o (OpenAI) - Latest GPT
└── deepseek-v3 (DeepSeek) - Efficient`,
    "/status": `Kernel Status: ONLINE
├── Uptime: 99.9%
├── Active Sessions: 1
├── Memory: 2.4GB / 8GB
└── Load: 12%`,
    "/config": `Configuration:
├── Thinking Level: 2 (Thoughtful Sage)
├── Token Budget: 5,000
├── Fibonacci Mode: Active
└── Telemetry: Enabled`,
  }

  const lowerInput = input.toLowerCase().trim()

  if (responses[lowerInput]) {
    return responses[lowerInput]
  }

  return `[${modelId}] Processing: "${input}"

Analysis complete. The input has been processed through the SLAVKO-OS kernel with the following parameters:
- Model: ${modelId}
- Capability: SPEC_ENG
- Guard: Passed
- Determinism: High

Output generated successfully.`
}
