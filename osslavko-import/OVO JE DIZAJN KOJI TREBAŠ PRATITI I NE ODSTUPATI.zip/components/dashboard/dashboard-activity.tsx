import { Clock, CheckCircle2, XCircle, Loader2 } from "lucide-react"

interface ExecutionLog {
  id: string
  model_id: string
  capability: string
  tokens_in: number
  tokens_out: number
  latency_ms: number
  status: string
  created_at: string
}

interface DashboardActivityProps {
  logs: ExecutionLog[]
}

export function DashboardActivity({ logs }: DashboardActivityProps) {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle2 className="w-4 h-4 text-emerald-500" />
      case "failed":
        return <XCircle className="w-4 h-4 text-red-500" />
      case "running":
        return <Loader2 className="w-4 h-4 text-blue-500 animate-spin" />
      default:
        return <Clock className="w-4 h-4 text-muted-foreground" />
    }
  }

  const formatTime = (date: string) => {
    return new Date(date).toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  return (
    <div className="bg-card border border-border rounded-xl p-6">
      <h2 className="text-lg font-semibold text-foreground mb-4">Recent Activity</h2>

      {logs.length === 0 ? (
        <div className="text-center py-8">
          <Clock className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
          <p className="text-muted-foreground">No activity yet</p>
          <p className="text-sm text-muted-foreground">Execute your first model to see activity here</p>
        </div>
      ) : (
        <div className="space-y-3">
          {logs.map((log) => (
            <div
              key={log.id}
              className="flex items-center justify-between p-3 bg-background rounded-lg border border-border"
            >
              <div className="flex items-center gap-3">
                {getStatusIcon(log.status)}
                <div>
                  <p className="text-sm font-medium text-foreground">{log.model_id}</p>
                  <p className="text-xs text-muted-foreground">{log.capability}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-mono text-foreground">{log.latency_ms}ms</p>
                <p className="text-xs text-muted-foreground">{formatTime(log.created_at)}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
