import { Zap, Activity, TrendingUp, Crown } from "lucide-react"

interface DashboardStatsProps {
  tokenBudget: number
  tokensUsed: number
  tokensRemaining: number
  executionCount: number
  tier: string
}

export function DashboardStats({
  tokenBudget,
  tokensUsed,
  tokensRemaining,
  executionCount,
  tier,
}: DashboardStatsProps) {
  const usagePercent = Math.round((tokensUsed / tokenBudget) * 100)

  const stats = [
    {
      label: "Token Budget",
      value: tokenBudget.toLocaleString(),
      icon: Zap,
      color: "text-emerald-500",
      bgColor: "bg-emerald-500/10",
    },
    {
      label: "Tokens Used",
      value: tokensUsed.toLocaleString(),
      subValue: `${usagePercent}%`,
      icon: Activity,
      color: "text-blue-500",
      bgColor: "bg-blue-500/10",
    },
    {
      label: "Executions",
      value: executionCount.toString(),
      icon: TrendingUp,
      color: "text-purple-500",
      bgColor: "bg-purple-500/10",
    },
    {
      label: "Plan",
      value: tier.charAt(0).toUpperCase() + tier.slice(1),
      icon: Crown,
      color: tier === "enterprise" ? "text-amber-500" : tier === "pro" ? "text-emerald-500" : "text-muted-foreground",
      bgColor: tier === "enterprise" ? "bg-amber-500/10" : tier === "pro" ? "bg-emerald-500/10" : "bg-muted/10",
    },
  ]

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {stats.map((stat) => (
        <div key={stat.label} className="bg-card border border-border rounded-xl p-4">
          <div className="flex items-center gap-3 mb-3">
            <div className={`w-8 h-8 ${stat.bgColor} rounded-lg flex items-center justify-center`}>
              <stat.icon className={`w-4 h-4 ${stat.color}`} />
            </div>
          </div>
          <p className="text-2xl font-semibold text-foreground">{stat.value}</p>
          <p className="text-sm text-muted-foreground">
            {stat.label}
            {stat.subValue && <span className="ml-1 text-xs">({stat.subValue})</span>}
          </p>
        </div>
      ))}
    </div>
  )
}
