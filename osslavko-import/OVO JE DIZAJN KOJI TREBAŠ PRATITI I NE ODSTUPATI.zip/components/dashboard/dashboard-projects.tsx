"use client"

import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Folder, Plus, MoreHorizontal } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"

interface Project {
  id: string
  name: string
  description: string | null
  created_at: string
}

interface DashboardProjectsProps {
  projects: Project[]
  userId: string
}

export function DashboardProjects({ projects: initialProjects, userId }: DashboardProjectsProps) {
  const [projects, setProjects] = useState(initialProjects)
  const [isOpen, setIsOpen] = useState(false)
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")
  const [isCreating, setIsCreating] = useState(false)

  const handleCreateProject = async () => {
    if (!name.trim()) return
    setIsCreating(true)

    const supabase = createClient()
    const { data, error } = await supabase
      .from("projects")
      .insert({ user_id: userId, name, description: description || null })
      .select()
      .single()

    if (!error && data) {
      setProjects([data, ...projects])
      setName("")
      setDescription("")
      setIsOpen(false)
    }
    setIsCreating(false)
  }

  return (
    <div className="bg-card border border-border rounded-xl p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-foreground">Projects</h2>
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="bg-emerald-500 hover:bg-emerald-600 text-background">
              <Plus className="w-4 h-4 mr-1" />
              New
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border">
            <DialogHeader>
              <DialogTitle className="text-foreground">Create Project</DialogTitle>
              <DialogDescription>Add a new project to organize your work.</DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  placeholder="My Project"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="bg-background border-border"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Input
                  id="description"
                  placeholder="Optional description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="bg-background border-border"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsOpen(false)}>
                Cancel
              </Button>
              <Button
                onClick={handleCreateProject}
                disabled={isCreating || !name.trim()}
                className="bg-emerald-500 hover:bg-emerald-600 text-background"
              >
                {isCreating ? "Creating..." : "Create"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {projects.length === 0 ? (
        <div className="text-center py-8">
          <Folder className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
          <p className="text-muted-foreground">No projects yet</p>
          <p className="text-sm text-muted-foreground">Create your first project to get started</p>
        </div>
      ) : (
        <div className="space-y-2">
          {projects.map((project) => (
            <div
              key={project.id}
              className="flex items-center justify-between p-3 bg-background rounded-lg border border-border hover:border-emerald-500/30 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-emerald-500/10 rounded-lg flex items-center justify-center">
                  <Folder className="w-4 h-4 text-emerald-500" />
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">{project.name}</p>
                  {project.description && <p className="text-xs text-muted-foreground">{project.description}</p>}
                </div>
              </div>
              <Button variant="ghost" size="icon" className="text-muted-foreground">
                <MoreHorizontal className="w-4 h-4" />
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
