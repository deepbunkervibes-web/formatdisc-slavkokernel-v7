"use client"

import { useState } from "react"
import type { User } from "@supabase/supabase-js"
import { DashboardHeader } from "./dashboard-header"
import { DashboardStats } from "./dashboard-stats"
import { DashboardActivity } from "./dashboard-activity"
import { DashboardProjects } from "./dashboard-projects"
import { DashboardFibonacci } from "./dashboard-fibonacci"

interface Profile {
  id: string
  display_name: string | null
  tier: string
  token_budget: number
  tokens_used: number
}

interface ExecutionLog {
  id: string
  model_id: string
  capability: string
  tokens_in: number
  tokens_out: number
  latency_ms: number
  status: string
  created_at: string
}

interface Project {
  id: string
  name: string
  description: string | null
  created_at: string
}

interface DashboardContentProps {
  user: User
  profile: Profile | null
  logs: ExecutionLog[]
  projects: Project[]
}

export function DashboardContent({ user, profile, logs, projects }: DashboardContentProps) {
  const [thinkingLevel, setThinkingLevel] = useState(2)

  const tokenBudget = profile?.token_budget || 5000
  const tokensUsed = profile?.tokens_used || 0
  const tokensRemaining = tokenBudget - tokensUsed

  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader user={user} profile={profile} />

      <main className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left column - Stats & Activity */}
          <div className="lg:col-span-2 space-y-6">
            <DashboardStats
              tokenBudget={tokenBudget}
              tokensUsed={tokensUsed}
              tokensRemaining={tokensRemaining}
              executionCount={logs.length}
              tier={profile?.tier || "free"}
            />
            <DashboardActivity logs={logs} />
            <DashboardProjects projects={projects} userId={user.id} />
          </div>

          {/* Right column - Fibonacci Control */}
          <div className="space-y-6">
            <DashboardFibonacci thinkingLevel={thinkingLevel} setThinkingLevel={setThinkingLevel} />
          </div>
        </div>
      </main>
    </div>
  )
}
