"use client"

import { Slider } from "@/components/ui/slider"

interface DashboardFibonacciProps {
  thinkingLevel: number
  setThinkingLevel: (level: number) => void
}

const THINKING_MODES = [
  { level: 1, name: "Lightning", desc: "Fastest execution" },
  { level: 2, name: "Thoughtful Sage", desc: "Balanced reasoning" },
  { level: 3, name: "Deep Analyst", desc: "Comprehensive analysis" },
  { level: 4, name: "Expert Mode", desc: "Maximum depth" },
  { level: 5, name: "Research", desc: "Full exploration" },
]

const FIBONACCI_LAYERS = [
  { id: "F1", name: "Core", weight: 1, desc: "Kernel identity & mode" },
  { id: "F2", name: "Primary", weight: 1, desc: "User intent & repository" },
  { id: "F3", name: "Secondary", weight: 2, desc: "Validation & readiness" },
  { id: "F4", name: "Tertiary", weight: 3, desc: "Depth & compliance" },
  { id: "F5", name: "Quaternary", weight: 5, desc: "Deploy & audit" },
]

export function DashboardFibonacci({ thinkingLevel, setThinkingLevel }: DashboardFibonacciProps) {
  const currentMode = THINKING_MODES.find((m) => m.level === thinkingLevel) || THINKING_MODES[1]

  return (
    <div className="space-y-6">
      {/* Thinking Level Card */}
      <div className="bg-card border border-border rounded-xl p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-medium text-foreground">Thinking Level</h3>
          <span className="text-sm font-medium text-emerald-500">{currentMode.name}</span>
        </div>

        <Slider
          value={[thinkingLevel]}
          onValueChange={(v) => setThinkingLevel(v[0])}
          min={1}
          max={5}
          step={1}
          className="mb-4"
        />

        <div className="flex justify-between mb-4">
          {[1, 2, 3, 4, 5].map((level) => (
            <button
              key={level}
              onClick={() => setThinkingLevel(level)}
              className={`w-10 h-10 rounded-lg font-medium transition-all ${
                level === thinkingLevel
                  ? "bg-emerald-500 text-background"
                  : "bg-background border border-border text-muted-foreground hover:border-emerald-500/50"
              }`}
            >
              {level}
            </button>
          ))}
        </div>

        <div className="bg-background rounded-lg p-3 border border-border">
          <div className="flex justify-between text-sm mb-1">
            <span className="text-muted-foreground">Token Budget</span>
            <span className="font-mono text-foreground">5.000</span>
          </div>
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>0 used</span>
            <span>0 cache hits</span>
          </div>
        </div>

        <p className="text-sm text-muted-foreground mt-3">{currentMode.desc}</p>
      </div>

      {/* Fibonacci Lattice Card */}
      <div className="bg-card border border-border rounded-xl p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-medium text-foreground">Fibonacci Lattice</h3>
          <span className="text-xs font-mono text-muted-foreground">1-1-2-3-5-8</span>
        </div>

        <div className="space-y-4">
          {FIBONACCI_LAYERS.map((layer, index) => {
            const isActive = index < thinkingLevel + 1
            return (
              <div key={layer.id}>
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono text-emerald-500">{layer.id}</span>
                    <span className="text-sm font-medium text-foreground">{layer.name}</span>
                  </div>
                  <span className="text-xs text-muted-foreground">
                    w:{layer.weight} {layer.weight}
                  </span>
                </div>
                <div className="flex gap-1">
                  {Array.from({ length: layer.weight }).map((_, i) => (
                    <div
                      key={i}
                      className={`h-2 flex-1 rounded-full transition-colors ${
                        isActive ? "bg-emerald-500" : "bg-emerald-500/20"
                      }`}
                    />
                  ))}
                </div>
                <p className="text-xs text-muted-foreground mt-1">{layer.desc}</p>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
