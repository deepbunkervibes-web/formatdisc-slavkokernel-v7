"use client"

// ═══════════════════════════════════════════════════════════════════════════════
// DEMO COMPONENT - v0.1 (rough draft)
// Ready for: Radix + CVA variants, visual effects, telemetry hooks
// ═══════════════════════════════════════════════════════════════════════════════

import { useReducer, useCallback, useEffect } from "react"
import { machineReducer, initialState } from "@/lib/state-machine/reducer"
import type { Status, ActionType } from "@/lib/state-machine/types"
import { TRANSITIONS } from "@/lib/state-machine/types"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

// Status -> visual mapping (placeholder for CVA)
const STATUS_STYLES: Record<Status, string> = {
  idle: "bg-muted text-muted-foreground",
  pending: "bg-yellow-500/20 text-yellow-600 border-yellow-500/50",
  running: "bg-blue-500/20 text-blue-600 border-blue-500/50",
  success: "bg-green-500/20 text-green-600 border-green-500/50",
  failure: "bg-red-500/20 text-red-600 border-red-500/50",
  cancelled: "bg-zinc-500/20 text-zinc-600 border-zinc-500/50",
}

// Action labels
const ACTION_LABELS: Record<ActionType, string> = {
  START: "Start",
  COMPLETE: "Complete",
  FAIL: "Fail",
  CANCEL: "Cancel",
  RESET: "Reset",
  RETRY: "Retry",
}

export function StateMachineDemo() {
  const [state, dispatch] = useReducer(machineReducer, initialState)

  // Auto-transition: pending -> running (simulates async kickoff)
  useEffect(() => {
    if (state.current === "pending") {
      const timer = setTimeout(() => {
        // Manually update to running (bypasses reducer for now)
        // TODO: integrate into reducer with internal actions
      }, 500)
      return () => clearTimeout(timer)
    }
  }, [state.current])

  const handleAction = useCallback((type: ActionType) => {
    dispatch({ type })
  }, [])

  const availableActions = TRANSITIONS[state.current] ?? []

  return (
    <div className="w-full max-w-2xl mx-auto p-6 space-y-6">
      {/* Current State Display */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>State Machine</span>
            <Badge variant="outline" className={`text-sm px-3 py-1 ${STATUS_STYLES[state.current]}`}>
              {state.current.toUpperCase()}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Context Info */}
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-muted-foreground">Attempts:</span>
              <span className="ml-2 font-mono">{state.context.attempts}</span>
            </div>
            <div>
              <span className="text-muted-foreground">Last Error:</span>
              <span className="ml-2 font-mono text-red-500">{state.context.lastError ?? "—"}</span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap gap-2 pt-4 border-t">
            {(["START", "COMPLETE", "FAIL", "CANCEL", "RETRY", "RESET"] as ActionType[]).map((action) => (
              <Button
                key={action}
                variant={availableActions.includes(action) ? "default" : "outline"}
                size="sm"
                disabled={!availableActions.includes(action)}
                onClick={() => handleAction(action)}
              >
                {ACTION_LABELS[action]}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* History Timeline */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Transition History</CardTitle>
        </CardHeader>
        <CardContent>
          {state.history.length === 0 ? (
            <p className="text-sm text-muted-foreground">No transitions yet</p>
          ) : (
            <div className="space-y-2">
              {state.history.map((entry, idx) => (
                <div key={entry.id} className="flex items-center gap-3 text-sm font-mono">
                  <span className="text-muted-foreground w-6">{idx + 1}.</span>
                  <Badge variant="outline" className={`text-xs ${STATUS_STYLES[entry.status]}`}>
                    {entry.status}
                  </Badge>
                  <span className="text-muted-foreground text-xs">
                    {new Date(entry.timestamp).toLocaleTimeString()}
                  </span>
                  {entry.metadata && (
                    <span className="text-xs text-muted-foreground">{JSON.stringify(entry.metadata)}</span>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Transition Map (Debug View) */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Valid Transitions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-2 text-sm font-mono">
            {Object.entries(TRANSITIONS).map(([from, actions]) => (
              <div
                key={from}
                className={`flex items-center gap-2 p-2 rounded ${from === state.current ? "bg-accent" : ""}`}
              >
                <Badge variant="outline" className="w-20 justify-center">
                  {from}
                </Badge>
                <span className="text-muted-foreground">→</span>
                <span>{actions.join(", ")}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
