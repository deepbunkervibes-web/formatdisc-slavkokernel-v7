"use client"

import { motion, useMotionValue, useTransform, animate } from "framer-motion"
import { useEffect, useRef } from "react"
import { useInView } from "framer-motion"

const STATS = [
  { value: 99.9, suffix: "%", label: "Uptime SLA" },
  { value: 12, suffix: "ms", label: "Avg latency" },
  { value: 50, suffix: "M+", label: "Requests/day" },
  { value: 10, suffix: "k+", label: "Developers" },
]

function AnimatedCounter({ value, suffix, delay }: { value: number; suffix: string; delay: number }) {
  const count = useMotionValue(0)
  const rounded = useTransform(count, (v) => (value % 1 !== 0 ? v.toFixed(1) : Math.round(v)))
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true })

  useEffect(() => {
    if (isInView) {
      const controls = animate(count, value, {
        duration: 2,
        delay: delay,
        ease: "easeOut",
      })
      return controls.stop
    }
  }, [isInView, count, value, delay])

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, scale: 0.5 }}
      animate={isInView ? { opacity: 1, scale: 1 } : {}}
      transition={{ duration: 0.5, delay }}
      className="text-4xl md:text-5xl font-bold text-foreground"
    >
      <motion.span>{rounded}</motion.span>
      <span className="text-primary">{suffix}</span>
    </motion.div>
  )
}

export function Stats() {
  return (
    <section className="py-24 border-y border-border bg-secondary/30 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-4"
        >
          {STATS.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="text-center"
            >
              <AnimatedCounter value={stat.value} suffix={stat.suffix} delay={index * 0.1} />
              <motion.p
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.5 + index * 0.1 }}
                className="mt-2 text-sm text-muted-foreground"
              >
                {stat.label}
              </motion.p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
