"use client"

import { useState, useEffect } from "react"

const FIBONACCI_LAYERS = [
  {
    id: "F1",
    name: "Core",
    weight: 1,
    description: "Kernel identity & mode",
    color: "from-emerald-500 to-emerald-400",
  },
  {
    id: "F2",
    name: "Primary",
    weight: 1,
    description: "User intent & repository",
    color: "from-emerald-500 to-emerald-400",
  },
  {
    id: "F3",
    name: "Secondary",
    weight: 2,
    description: "Validation & readiness",
    color: "from-emerald-400 to-teal-400",
  },
  { id: "F4", name: "Tertiary", weight: 3, description: "Depth & compliance", color: "from-teal-400 to-cyan-400" },
  { id: "F5", name: "Quaternary", weight: 5, description: "Deploy & audit", color: "from-cyan-400 to-blue-400" },
]

export function FibonacciDemo() {
  const [activeLayer, setActiveLayer] = useState(0)
  const [isAnimating, setIsAnimating] = useState(true)

  useEffect(() => {
    if (!isAnimating) return

    const interval = setInterval(() => {
      setActiveLayer((prev) => (prev + 1) % FIBONACCI_LAYERS.length)
    }, 2000)

    return () => clearInterval(interval)
  }, [isAnimating])

  return (
    <section className="py-32">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Content */}
          <div>
            <p className="text-primary font-mono text-sm mb-4 tracking-wider">FIBONACCI LATTICE</p>
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6 text-balance">
              Intelligent context prioritization
            </h2>
            <p className="text-muted-foreground text-lg mb-8">
              Our Fibonacci-weighted context system ensures the most critical information receives proportional
              attention. Each layer builds on the previous, creating a natural hierarchy of importance.
            </p>

            {/* Layer List */}
            <div className="space-y-3">
              {FIBONACCI_LAYERS.map((layer, index) => (
                <button
                  key={layer.id}
                  onClick={() => {
                    setActiveLayer(index)
                    setIsAnimating(false)
                  }}
                  className={`w-full flex items-center gap-4 p-4 rounded-xl transition-all text-left ${
                    activeLayer === index
                      ? "bg-primary/10 border border-primary/50"
                      : "bg-card border border-border hover:border-primary/30"
                  }`}
                >
                  <span
                    className={`text-sm font-mono ${activeLayer === index ? "text-primary" : "text-muted-foreground"}`}
                  >
                    {layer.id}
                  </span>
                  <div className="flex-1">
                    <span
                      className={`font-medium ${activeLayer === index ? "text-foreground" : "text-muted-foreground"}`}
                    >
                      {layer.name}
                    </span>
                    <span className="text-muted-foreground text-sm ml-2">w:{layer.weight}</span>
                  </div>
                  <span className="text-xs text-muted-foreground">{layer.description}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Visualization */}
          <div className="relative">
            {/* Background glow */}
            <div className="absolute inset-0 bg-primary/10 rounded-full blur-3xl opacity-50" />

            {/* Concentric rings */}
            <div className="relative aspect-square max-w-lg mx-auto">
              {FIBONACCI_LAYERS.slice()
                .reverse()
                .map((layer, reverseIndex) => {
                  const index = FIBONACCI_LAYERS.length - 1 - reverseIndex
                  const size = 100 - reverseIndex * 15
                  const isActive = activeLayer >= index

                  return (
                    <div
                      key={layer.id}
                      className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 transition-all duration-500 ${
                        isActive ? "border-primary/60" : "border-border"
                      }`}
                      style={{
                        width: `${size}%`,
                        height: `${size}%`,
                        backgroundColor: isActive ? "rgba(16, 185, 129, 0.05)" : "transparent",
                      }}
                    >
                      {/* Label */}
                      {activeLayer === index && (
                        <div className="absolute top-4 left-1/2 -translate-x-1/2 px-3 py-1 bg-primary text-primary-foreground text-xs font-mono rounded-full animate-fade-in">
                          {layer.id} · w:{layer.weight}
                        </div>
                      )}
                    </div>
                  )
                })}

              {/* Center core */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-16 rounded-full bg-primary flex items-center justify-center">
                <span className="font-mono font-bold text-primary-foreground">{">_"}</span>
              </div>

              {/* Sequence display */}
              <div className="absolute bottom-0 left-1/2 -translate-x-1/2 font-mono text-muted-foreground text-sm">
                1 - 1 - 2 - 3 - 5 - 8
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
