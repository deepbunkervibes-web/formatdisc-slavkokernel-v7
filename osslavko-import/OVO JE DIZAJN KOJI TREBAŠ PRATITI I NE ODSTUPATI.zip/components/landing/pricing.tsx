"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Check, Minus } from "lucide-react"
import Link from "next/link"

const PLANS = [
  {
    name: "Starter",
    description: "For individual developers",
    price: { monthly: 0, annual: 0 },
    features: [
      { name: "10k requests/month", included: true },
      { name: "3 model providers", included: true },
      { name: "Basic analytics", included: true },
      { name: "Community support", included: true },
      { name: "Custom pipelines", included: false },
      { name: "Audit logs", included: false },
      { name: "SLA", included: false },
    ],
    cta: "Get Started Free",
    variant: "outline" as const,
  },
  {
    name: "Pro",
    description: "For growing teams",
    price: { monthly: 49, annual: 39 },
    features: [
      { name: "100k requests/month", included: true },
      { name: "All model providers", included: true },
      { name: "Advanced analytics", included: true },
      { name: "Priority support", included: true },
      { name: "Custom pipelines", included: true },
      { name: "Audit logs", included: true },
      { name: "SLA", included: false },
    ],
    cta: "Start Free Trial",
    variant: "default" as const,
    featured: true,
  },
  {
    name: "Enterprise",
    description: "For organizations at scale",
    price: { monthly: null, annual: null },
    features: [
      { name: "Unlimited requests", included: true },
      { name: "All model providers", included: true },
      { name: "Custom analytics", included: true },
      { name: "Dedicated support", included: true },
      { name: "Custom pipelines", included: true },
      { name: "Audit logs + SIEM", included: true },
      { name: "99.99% SLA", included: true },
    ],
    cta: "Contact Sales",
    variant: "outline" as const,
  },
]

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.15 },
  },
}

const cardVariants = {
  hidden: { opacity: 0, y: 40 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: "easeOut" },
  },
}

export function Pricing() {
  const [isAnnual, setIsAnnual] = useState(true)

  return (
    <section id="pricing" className="py-32 bg-secondary/30">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <motion.p
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="text-primary font-mono text-sm mb-4 tracking-wider"
          >
            PRICING
          </motion.p>
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6 text-balance">
            Simple, transparent pricing
          </h2>
          <p className="max-w-2xl mx-auto text-muted-foreground text-lg mb-8">
            Start free, scale as you grow. No hidden fees, no surprises.
          </p>

          {/* Billing toggle */}
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
            className="flex items-center justify-center gap-4"
          >
            <span className={`text-sm ${!isAnnual ? "text-foreground" : "text-muted-foreground"}`}>Monthly</span>
            <motion.button
              onClick={() => setIsAnnual(!isAnnual)}
              whileTap={{ scale: 0.95 }}
              className={`relative w-14 h-8 rounded-full transition-colors ${isAnnual ? "bg-primary" : "bg-secondary"}`}
            >
              <motion.div
                className="absolute top-1 w-6 h-6 rounded-full bg-white"
                animate={{ x: isAnnual ? 28 : 4 }}
                transition={{ type: "spring", stiffness: 500, damping: 30 }}
              />
            </motion.button>
            <span className={`text-sm ${isAnnual ? "text-foreground" : "text-muted-foreground"}`}>
              Annual
              <motion.span
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="ml-2 px-2 py-0.5 bg-primary/20 text-primary text-xs rounded-full"
              >
                Save 20%
              </motion.span>
            </span>
          </motion.div>
        </motion.div>

        {/* Pricing Cards */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid md:grid-cols-3 gap-6"
        >
          {PLANS.map((plan, index) => (
            <motion.div
              key={plan.name}
              variants={cardVariants}
              whileHover={{ y: plan.featured ? -10 : -5, scale: plan.featured ? 1.02 : 1.01 }}
              className={`relative p-8 rounded-2xl transition-shadow ${
                plan.featured
                  ? "bg-card border-2 border-primary scale-105 shadow-xl shadow-primary/10"
                  : "bg-card border border-border"
              }`}
            >
              {/* Featured badge */}
              {plan.featured && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                  className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 bg-primary text-primary-foreground text-xs font-medium rounded-full"
                >
                  Most Popular
                </motion.div>
              )}

              {/* Glow effect */}
              {plan.featured && (
                <motion.div
                  className="absolute -inset-1 bg-primary/20 rounded-2xl blur-xl -z-10"
                  animate={{ opacity: [0.3, 0.6, 0.3] }}
                  transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY }}
                />
              )}

              {/* Plan info */}
              <h3 className="text-xl font-semibold text-foreground mb-2">{plan.name}</h3>
              <p className="text-muted-foreground text-sm mb-6">{plan.description}</p>

              {/* Price */}
              <div className="mb-8">
                {plan.price.monthly !== null ? (
                  <div className="flex items-baseline gap-1">
                    <motion.span
                      key={isAnnual ? "annual" : "monthly"}
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="text-4xl font-bold text-foreground"
                    >
                      ${isAnnual ? plan.price.annual : plan.price.monthly}
                    </motion.span>
                    <span className="text-muted-foreground">/month</span>
                  </div>
                ) : (
                  <div className="text-4xl font-bold text-foreground">Custom</div>
                )}
              </div>

              {/* CTA */}
              <Link href="/auth/sign-up">
                <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                  <Button
                    className={`w-full mb-8 ${
                      plan.featured ? "bg-primary text-primary-foreground hover:bg-primary/90" : ""
                    }`}
                    variant={plan.variant}
                  >
                    {plan.cta}
                  </Button>
                </motion.div>
              </Link>

              {/* Features */}
              <ul className="space-y-3">
                {plan.features.map((feature, featureIndex) => (
                  <motion.li
                    key={feature.name}
                    initial={{ opacity: 0, x: -10 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.1 * featureIndex }}
                    className="flex items-center gap-3 text-sm"
                  >
                    {feature.included ? (
                      <Check className="w-4 h-4 text-primary flex-shrink-0" />
                    ) : (
                      <Minus className="w-4 h-4 text-muted-foreground/50 flex-shrink-0" />
                    )}
                    <span className={feature.included ? "text-foreground" : "text-muted-foreground/50"}>
                      {feature.name}
                    </span>
                  </motion.li>
                ))}
              </ul>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
