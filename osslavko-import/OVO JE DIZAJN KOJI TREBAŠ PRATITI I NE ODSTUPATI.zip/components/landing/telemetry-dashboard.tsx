"use client"

import { useKernelTelemetry } from "@/hooks/use-kernel-telemetry"
import type { ModuleId, ModuleStatus } from "@/lib/telemetry/types"
import { cn } from "@/lib/utils"

const MODULES: { id: ModuleId; label: string; description: string }[] = [
  { id: "EXECUTION_KERNEL", label: "Execution Kernel", description: "Core orchestration engine" },
  { id: "COMPLIANCE_ENGINE", label: "Compliance Engine", description: "Policy & guard validation" },
  { id: "FORENSICS_SERVICE", label: "Forensics Service", description: "Audit & traceability" },
]

const STATUS_STYLES: Record<ModuleStatus, { bg: string; text: string; pulse: boolean }> = {
  OK: { bg: "bg-emerald-500/20", text: "text-emerald-400", pulse: false },
  DEGRADED: { bg: "bg-amber-500/20", text: "text-amber-400", pulse: true },
  BLOCKED: { bg: "bg-red-500/20", text: "text-red-400", pulse: true },
}

function ModuleCard({ moduleId }: { moduleId: ModuleId }) {
  const { data, loading, error } = useKernelTelemetry({ moduleId, pollIntervalMs: 10000 })
  const module = MODULES.find((m) => m.id === moduleId)!

  if (loading) {
    return (
      <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-6 animate-pulse">
        <div className="h-4 w-24 bg-white/10 rounded mb-4" />
        <div className="h-8 w-16 bg-white/10 rounded" />
      </div>
    )
  }

  if (error || !data) {
    return (
      <div className="rounded-2xl border border-red-500/30 bg-red-500/5 p-6">
        <p className="text-red-400 text-sm">{error || "No data"}</p>
      </div>
    )
  }

  const style = STATUS_STYLES[data.status]

  return (
    <div className="group rounded-2xl border border-white/10 bg-white/[0.02] p-6 hover:border-emerald-500/30 hover:bg-emerald-500/[0.02] transition-all duration-300">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className={cn("relative w-2.5 h-2.5 rounded-full", style.bg)}>
            <div className={cn("absolute inset-0 rounded-full", style.bg, style.pulse && "animate-ping")} />
            <div className={cn("absolute inset-0 rounded-full", style.text.replace("text-", "bg-"))} />
          </div>
          <span className="text-sm font-medium text-white/60">{module.label}</span>
        </div>
        <span className={cn("text-xs font-mono px-2 py-1 rounded", style.bg, style.text)}>{data.status}</span>
      </div>

      <p className="text-xs text-white/40 mb-6">{module.description}</p>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <p className="text-xs text-white/40 mb-1">Latency</p>
          <p className="text-lg font-mono text-white">
            {data.latencyMs.toFixed(1)}
            <span className="text-white/40 text-sm">ms</span>
          </p>
        </div>
        <div>
          <p className="text-xs text-white/40 mb-1">Integrity</p>
          <div className="flex items-center gap-2">
            <p className="text-lg font-mono text-emerald-400">{data.integrityScore.toFixed(1)}</p>
            <div className="flex-1 h-1.5 bg-white/10 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-emerald-500 to-emerald-400 rounded-full transition-all duration-500"
                style={{ width: `${data.integrityScore}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      <div className="mt-4 pt-4 border-t border-white/5 flex items-center justify-between">
        <p className="text-xs text-white/30">
          Incidents (24h):{" "}
          <span className={data.incidentsLast24h > 0 ? "text-amber-400" : "text-emerald-400"}>
            {data.incidentsLast24h}
          </span>
        </p>
        <p className="text-xs text-white/30 font-mono">{new Date(data.lastUpdated).toLocaleTimeString()}</p>
      </div>
    </div>
  )
}

export function TelemetryDashboard() {
  return (
    <section className="py-32 relative">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom,rgba(16,185,129,0.05),transparent_70%)]" />

      <div className="max-w-6xl mx-auto px-6 relative">
        <div className="text-center mb-16">
          <p className="text-emerald-400 text-sm font-mono tracking-wider mb-4">LIVE TELEMETRY</p>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">System Health Monitor</h2>
          <p className="text-white/60 text-lg max-w-2xl mx-auto">
            Real-time visibility into kernel operations, compliance status, and forensic integrity.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {MODULES.map((module) => (
            <ModuleCard key={module.id} moduleId={module.id} />
          ))}
        </div>

        <div className="mt-12 p-6 rounded-2xl border border-white/10 bg-white/[0.02]">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-white font-medium">System Overview</h3>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-xs text-emerald-400 font-mono">OPERATIONAL</span>
            </div>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div>
              <p className="text-2xl font-mono text-white">
                99.97<span className="text-white/40 text-sm">%</span>
              </p>
              <p className="text-xs text-white/40">Uptime (30d)</p>
            </div>
            <div>
              <p className="text-2xl font-mono text-white">
                2.4<span className="text-white/40 text-sm">M</span>
              </p>
              <p className="text-xs text-white/40">Requests today</p>
            </div>
            <div>
              <p className="text-2xl font-mono text-white">
                14<span className="text-white/40 text-sm">ms</span>
              </p>
              <p className="text-xs text-white/40">Avg latency</p>
            </div>
            <div>
              <p className="text-2xl font-mono text-emerald-400">0</p>
              <p className="text-xs text-white/40">Active incidents</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
