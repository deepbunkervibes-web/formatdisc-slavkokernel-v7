"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Check, Sparkles, Zap, Brain } from "lucide-react"

const MODELS = [
  {
    id: "flash",
    name: "Gemini Flash",
    provider: "Google",
    badge: "Speed",
    icon: Zap,
    description: "Ultra-fast responses for real-time applications",
    capabilities: ["EXECUTE_FAST", "CODER"],
    latency: "8ms",
    costTier: "low",
  },
  {
    id: "sonnet",
    name: "Claude Sonnet",
    provider: "Anthropic",
    badge: "Balanced",
    icon: Sparkles,
    description: "Best balance of speed, cost, and capability",
    capabilities: ["SPEC_ENG", "ARCHITECT", "CODER", "AUDITOR"],
    latency: "45ms",
    costTier: "standard",
    featured: true,
  },
  {
    id: "opus",
    name: "Claude Opus",
    provider: "Anthropic",
    badge: "Power",
    icon: Brain,
    description: "Maximum capability for complex reasoning",
    capabilities: ["SPEC_ENG", "ARCHITECT", "AUDITOR"],
    latency: "120ms",
    costTier: "premium",
  },
]

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.15 },
  },
}

const cardVariants = {
  hidden: { opacity: 0, y: 30, scale: 0.95 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { duration: 0.5, ease: "easeOut" },
  },
}

export function Models() {
  const [hoveredModel, setHoveredModel] = useState<string | null>(null)

  return (
    <section id="models" className="py-32 bg-secondary/30">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <motion.p
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="text-primary font-mono text-sm mb-4 tracking-wider"
          >
            MODEL REGISTRY
          </motion.p>
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6 text-balance">
            The right model for every task
          </h2>
          <p className="max-w-2xl mx-auto text-muted-foreground text-lg">
            We route to 15+ models across providers. Here are some of our most popular selections.
          </p>
        </motion.div>

        {/* Models Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid md:grid-cols-3 gap-6"
        >
          {MODELS.map((model) => {
            const Icon = model.icon
            const isHovered = hoveredModel === model.id

            return (
              <motion.div
                key={model.id}
                variants={cardVariants}
                whileHover={{ y: -8, scale: 1.02 }}
                className={`relative p-8 rounded-2xl cursor-pointer ${
                  model.featured
                    ? "bg-card border-2 border-primary"
                    : "bg-card border border-border hover:border-primary/50"
                }`}
                onMouseEnter={() => setHoveredModel(model.id)}
                onMouseLeave={() => setHoveredModel(null)}
              >
                {/* Featured badge */}
                {model.featured && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 bg-primary text-primary-foreground text-xs font-medium rounded-full"
                  >
                    Most Popular
                  </motion.div>
                )}

                {/* Glow effect for featured */}
                {model.featured && (
                  <motion.div
                    className="absolute -inset-1 bg-primary/20 rounded-2xl blur-xl -z-10"
                    animate={{ opacity: [0.3, 0.5, 0.3] }}
                    transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY }}
                  />
                )}

                <div className="relative">
                  {/* Header */}
                  <div className="flex items-start justify-between mb-6">
                    <motion.div
                      className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center"
                      whileHover={{ scale: 1.1, rotate: 5 }}
                      transition={{ type: "spring", stiffness: 400 }}
                    >
                      <Icon className={`w-6 h-6 ${model.featured ? "text-primary" : "text-muted-foreground"}`} />
                    </motion.div>
                    <motion.span
                      animate={{ scale: isHovered ? 1.05 : 1 }}
                      className="px-3 py-1 rounded-full bg-secondary text-xs text-muted-foreground"
                    >
                      {model.badge}
                    </motion.span>
                  </div>

                  {/* Info */}
                  <h3 className="text-xl font-semibold text-foreground mb-1">{model.name}</h3>
                  <p className="text-sm text-muted-foreground mb-4">{model.provider}</p>
                  <p className="text-muted-foreground mb-6">{model.description}</p>

                  {/* Stats */}
                  <div className="flex gap-4 mb-6 text-sm">
                    <div>
                      <span className="text-muted-foreground">Latency</span>
                      <p className="text-foreground font-mono">{model.latency}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Cost</span>
                      <p className="text-foreground font-mono capitalize">{model.costTier}</p>
                    </div>
                  </div>

                  {/* Capabilities */}
                  <div className="space-y-2">
                    <span className="text-xs text-muted-foreground">Capabilities</span>
                    <div className="flex flex-wrap gap-2">
                      {model.capabilities.map((cap, capIndex) => (
                        <motion.span
                          key={cap}
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: capIndex * 0.1 }}
                          className={`flex items-center gap-1 px-2 py-1 rounded text-xs font-mono ${
                            isHovered ? "bg-primary/20 text-primary" : "bg-secondary text-muted-foreground"
                          } transition-colors`}
                        >
                          <Check className="w-3 h-3" />
                          {cap}
                        </motion.span>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            )
          })}
        </motion.div>
      </div>
    </section>
  )
}
