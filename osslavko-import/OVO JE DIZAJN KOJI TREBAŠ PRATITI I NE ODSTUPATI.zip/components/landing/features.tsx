"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef } from "react"
import { Cpu, Zap, Shield, GitBranch, Gauge, Layers } from "lucide-react"

const FEATURES = [
  {
    icon: Cpu,
    title: "Intelligent Routing",
    description:
      "Automatically route requests to the optimal model based on capability requirements, latency constraints, and cost targets.",
  },
  {
    icon: Zap,
    title: "Sub-20ms Decisions",
    description: "Lightning-fast model selection with deterministic scoring algorithms. No guesswork, just precision.",
  },
  {
    icon: Shield,
    title: "Guard Rails Built-in",
    description:
      "Enforce capability contracts and transition guards. Prevent invalid state transitions before they happen.",
  },
  {
    icon: GitBranch,
    title: "Pipeline Orchestration",
    description: "Chain capabilities together in deterministic pipelines. SPEC_ENG → ARCHITECT → CODER → AUDITOR.",
  },
  {
    icon: Gauge,
    title: "Real-time Telemetry",
    description: "Monitor token usage, cache hits, and model performance with microsecond precision timestamps.",
  },
  {
    icon: Layers,
    title: "Fibonacci Context",
    description:
      "Intelligent context layering using Fibonacci-weighted priorities. Core → Primary → Secondary → Tertiary.",
  },
]

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
}

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.6,
      ease: "easeOut",
    },
  },
}

export function Features() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  return (
    <section id="features" className="py-32">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <motion.p
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="text-primary font-mono text-sm mb-4 tracking-wider"
          >
            CAPABILITIES
          </motion.p>
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6 text-balance">
            Everything you need to orchestrate AI
          </h2>
          <p className="max-w-2xl mx-auto text-muted-foreground text-lg">
            Built for teams who need deterministic, auditable AI pipelines. No magic, just engineering.
          </p>
        </motion.div>

        {/* Features Grid */}
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {FEATURES.map((feature) => {
            const Icon = feature.icon
            return (
              <motion.div
                key={feature.title}
                variants={itemVariants}
                whileHover={{ scale: 1.02, y: -5 }}
                className="group relative p-8 rounded-2xl bg-card border border-border hover:border-primary/50 transition-colors"
              >
                {/* Hover glow */}
                <motion.div
                  className="absolute inset-0 rounded-2xl bg-primary/5"
                  initial={{ opacity: 0 }}
                  whileHover={{ opacity: 1 }}
                  transition={{ duration: 0.3 }}
                />

                <div className="relative">
                  <motion.div
                    className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-6"
                    whileHover={{ scale: 1.1, rotate: 5 }}
                    transition={{ type: "spring", stiffness: 400 }}
                  >
                    <Icon className="w-6 h-6 text-primary" />
                  </motion.div>
                  <h3 className="text-xl font-semibold text-foreground mb-3">{feature.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
                </div>
              </motion.div>
            )
          })}
        </motion.div>
      </div>
    </section>
  )
}
