"use client"

import { useReducer, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { capabilityReducer, initialCapabilityState } from "@/lib/state-machine/reducer"
import { CAPABILITIES } from "@/lib/state-machine/capabilities"
import { selectModel } from "@/lib/state-machine/orchestrator"
import type { CapabilityState, OrchestratorConstraints } from "@/lib/state-machine/types"
import { CAPABILITY_TRANSITIONS } from "@/lib/state-machine/types"

const CAPABILITY_COLORS: Record<CapabilityState, string> = {
  SPEC_ENG: "bg-blue-500/10 text-blue-500 border-blue-500/20",
  ARCHITECT: "bg-purple-500/10 text-purple-500 border-purple-500/20",
  CODER: "bg-green-500/10 text-green-500 border-green-500/20",
  AUDITOR: "bg-orange-500/10 text-orange-500 border-orange-500/20",
  EXECUTE_FAST: "bg-yellow-500/10 text-yellow-500 border-yellow-500/20",
}

export function FCPDemo() {
  const [state, dispatch] = useReducer(capabilityReducer, initialCapabilityState)
  const [input, setInput] = useState("")
  const [constraints, setConstraints] = useState<OrchestratorConstraints>({
    determinism: "strict",
  })

  const currentDef = CAPABILITIES[state.current]
  const availableTransitions = CAPABILITY_TRANSITIONS[state.current] || []
  const selection = selectModel(state.current, constraints)

  const handleTransition = (to: CapabilityState) => {
    dispatch({
      type: "TRANSITION",
      to,
      input,
      model: selection.model?.id,
    })
    setInput("")
  }

  const handleExecute = () => {
    if (!selection.model) return
    dispatch({
      type: "EXECUTE",
      input,
      model: selection.model.id,
    })
  }

  return (
    <div className="space-y-6 p-6 max-w-4xl mx-auto">
      <div className="text-center space-y-2">
        <h1 className="text-2xl font-bold">FCP-1: Formal Capability Pipeline</h1>
        <p className="text-muted-foreground">Deterministic multi-stage reasoning with enforced capability contracts</p>
      </div>

      {/* Current State */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium">Current Capability</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <Badge variant="outline" className={`text-lg px-4 py-2 ${CAPABILITY_COLORS[state.current]}`}>
              {state.current}
            </Badge>
            <div className="text-sm text-muted-foreground">{currentDef?.purpose}</div>
          </div>

          {state.context.lastGuardFailure && (
            <div className="mt-3 p-3 bg-destructive/10 text-destructive rounded-md text-sm">
              Guard Failure: {state.context.lastGuardFailure}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Model Selection */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium">Orchestrator Selection</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">Selected Model:</span>
            {selection.model ? (
              <Badge variant="secondary">{selection.model.name}</Badge>
            ) : (
              <Badge variant="destructive">No model available</Badge>
            )}
            <span className="text-xs text-muted-foreground">{selection.reason}</span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">Alternatives:</span>
            {selection.alternatives.map((m) => (
              <Badge key={m.id} variant="outline" className="text-xs">
                {m.name}
              </Badge>
            ))}
          </div>

          <div className="flex gap-2">
            <Button
              size="sm"
              variant={constraints.determinism === "strict" ? "default" : "outline"}
              onClick={() => setConstraints((c) => ({ ...c, determinism: "strict" }))}
            >
              Strict
            </Button>
            <Button
              size="sm"
              variant={constraints.determinism === "relaxed" ? "default" : "outline"}
              onClick={() => setConstraints((c) => ({ ...c, determinism: "relaxed" }))}
            >
              Relaxed
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Input */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium">Input</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Textarea
            placeholder={`Enter input for ${state.current}...`}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            rows={4}
          />

          <div className="flex gap-2">
            <Button onClick={handleExecute} disabled={!selection.model}>
              Execute
            </Button>
            <Button variant="outline" onClick={() => dispatch({ type: "RESET" })}>
              Reset
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Transitions */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium">Available Transitions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            {availableTransitions.length > 0 ? (
              availableTransitions.map((to) => (
                <Button
                  key={to}
                  variant="outline"
                  className={CAPABILITY_COLORS[to]}
                  onClick={() => handleTransition(to)}
                >
                  {state.current} → {to}
                </Button>
              ))
            ) : (
              <span className="text-sm text-muted-foreground">No transitions available (terminal state)</span>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Guarantees & Forbidden */}
      <div className="grid grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-green-500">Guarantees</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="text-sm space-y-1">
              {currentDef?.guarantees.map((g, i) => (
                <li key={i} className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-green-500 rounded-full" />
                  {g}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-red-500">Forbidden</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="text-sm space-y-1">
              {currentDef?.forbidden.map((f, i) => (
                <li key={i} className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-red-500 rounded-full" />
                  {f}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>

      {/* History */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium">Audit Timeline ({state.history.length} entries)</CardTitle>
        </CardHeader>
        <CardContent>
          {state.history.length === 0 ? (
            <p className="text-sm text-muted-foreground">No history yet</p>
          ) : (
            <div className="space-y-2 max-h-60 overflow-y-auto">
              {state.history.map((entry, i) => (
                <div key={entry.id} className="flex items-center gap-3 text-sm p-2 bg-muted/50 rounded">
                  <span className="text-muted-foreground w-6">{i + 1}.</span>
                  <Badge variant="outline" className={CAPABILITY_COLORS[entry.capability]}>
                    {entry.capability}
                  </Badge>
                  {entry.model && (
                    <Badge variant="secondary" className="text-xs">
                      {entry.model}
                    </Badge>
                  )}
                  {!entry.guardResult.passed && (
                    <Badge variant="destructive" className="text-xs">
                      GUARD FAIL
                    </Badge>
                  )}
                  <span className="text-xs text-muted-foreground ml-auto">
                    {new Date(entry.timestamp).toLocaleTimeString()}
                  </span>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Pipeline Visualization */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium">FCP-1 Pipeline</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            {(["SPEC_ENG", "ARCHITECT", "CODER", "AUDITOR"] as CapabilityState[]).map((cap, i, arr) => (
              <div key={cap} className="flex items-center">
                <div
                  className={`px-3 py-2 rounded border text-xs font-medium ${
                    state.current === cap
                      ? CAPABILITY_COLORS[cap] + " ring-2 ring-offset-2"
                      : "bg-muted text-muted-foreground"
                  }`}
                >
                  {cap}
                </div>
                {i < arr.length - 1 && <div className="w-8 h-px bg-border mx-2" />}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
