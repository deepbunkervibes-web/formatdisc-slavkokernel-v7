"use client"

import { useState } from "react"
import { Settings, Menu, Clover } from "lucide-react"
import { Slider } from "@/components/ui/slider"

const THINKING_LEVELS = [
  { level: 1, name: "Swift Scout", description: "Fast, minimal reasoning" },
  { level: 2, name: "Thoughtful Sage", description: "Balanced reasoning and speed" },
  { level: 3, name: "Deep Analyst", description: "Thorough analysis" },
  { level: 4, name: "System Architect", description: "Comprehensive synthesis" },
  { level: 5, name: "Oracle Prime", description: "Maximum depth reasoning" },
]

const FIBONACCI_LAYERS = [
  { id: "F1", name: "Core", weight: 1, description: "Kernel identity & mode" },
  { id: "F2", name: "Primary", weight: 1, description: "User intent & repository" },
  { id: "F3", name: "Secondary", weight: 2, description: "Validation & readiness" },
  { id: "F4", name: "Tertiary", weight: 3, description: "Depth & compliance" },
  { id: "F5", name: "Quaternary", weight: 5, description: "Deploy & audit" },
]

export function SlavkoOS() {
  const [thinkingLevel, setThinkingLevel] = useState(2)
  const [tokenBudget] = useState(5000)
  const [tokensUsed] = useState(0)
  const [cacheHits] = useState(0)

  const currentLevel = THINKING_LEVELS[thinkingLevel - 1]

  return (
    <div className="min-h-screen bg-[#0a0f0a] text-white font-mono">
      {/* Header */}
      <header className="flex items-center justify-between px-4 py-3 border-b border-emerald-900/30">
        <div className="flex items-center gap-3">
          <button className="p-1 hover:bg-emerald-900/20 rounded">
            <Menu className="w-5 h-5 text-gray-400" />
          </button>
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-lg bg-emerald-600 flex items-center justify-center">
              <span className="text-lg font-bold">{">_"}</span>
            </div>
            <div>
              <div className="font-semibold tracking-wide">SLAVKO-OS</div>
              <div className="text-xs text-gray-500">v1.0.0</div>
            </div>
          </div>
        </div>
        <button className="p-2 hover:bg-emerald-900/20 rounded">
          <Settings className="w-5 h-5 text-gray-400" />
        </button>
      </header>

      <main className="p-4 space-y-4 max-w-lg mx-auto">
        {/* Status Badge */}
        <div className="flex justify-center py-6">
          <div className="flex items-center gap-2 text-gray-500 text-sm">
            <span className="w-2 h-2 rounded-full bg-gray-600" />
            Experimental
          </div>
        </div>

        {/* Thinking Level Card */}
        <div className="bg-[#0d120d] border border-emerald-900/30 rounded-xl p-5 space-y-5">
          <div className="flex items-center justify-between">
            <h2 className="text-gray-300 tracking-wide">Thinking Level</h2>
            <div className="flex items-center gap-2 text-emerald-400">
              <Clover className="w-5 h-5" />
              <span>{currentLevel.name}</span>
            </div>
          </div>

          {/* Slider */}
          <div className="space-y-4">
            <Slider
              value={[thinkingLevel]}
              onValueChange={(v) => setThinkingLevel(v[0])}
              min={1}
              max={5}
              step={1}
              className="[&_[role=slider]]:bg-white [&_[role=slider]]:border-0 [&_.range]:bg-emerald-500"
            />

            {/* Level Buttons */}
            <div className="flex justify-between gap-2">
              {[1, 2, 3, 4, 5].map((level) => (
                <button
                  key={level}
                  onClick={() => setThinkingLevel(level)}
                  className={`w-12 h-10 rounded-lg text-sm font-medium transition-all ${
                    level === thinkingLevel
                      ? "bg-emerald-600 text-white"
                      : "bg-[#1a1f1a] text-gray-500 hover:bg-[#252a25]"
                  }`}
                >
                  {level}
                </button>
              ))}
            </div>
          </div>

          {/* Token Budget */}
          <div className="bg-[#0a0f0a] rounded-lg p-4 space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-gray-500 text-sm">Token Budget</span>
              <span className="text-white font-semibold">{(tokenBudget / 1000).toFixed(3)}</span>
            </div>
            <div className="flex justify-between text-xs text-gray-600">
              <span>{tokensUsed} used</span>
              <span>{cacheHits} cache hits</span>
            </div>
          </div>

          <p className="text-gray-500 text-sm">{currentLevel.description}</p>
        </div>

        {/* Fibonacci Lattice Card */}
        <div className="bg-[#0d120d] border border-emerald-900/30 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-gray-300 font-semibold tracking-wide">Fibonacci Lattice</h2>
            <span className="text-gray-500 text-sm font-mono">1-1-2-3-5-8</span>
          </div>

          <div className="space-y-4">
            {FIBONACCI_LAYERS.map((layer) => (
              <div key={layer.id} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-emerald-500 text-sm">{layer.id}</span>
                    <span className="text-white font-medium">{layer.name}</span>
                  </div>
                  <span className="text-gray-500 text-sm">
                    w:{layer.weight} <span className="text-emerald-400">{layer.weight}</span>
                  </span>
                </div>

                {/* Progress Bars */}
                <div className="flex gap-1">
                  {Array.from({ length: layer.weight }).map((_, i) => (
                    <div key={i} className="h-2 rounded-full bg-emerald-500 flex-1" />
                  ))}
                </div>

                <p className="text-gray-600 text-xs">{layer.description}</p>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  )
}
