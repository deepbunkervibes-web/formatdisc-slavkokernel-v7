"use client"

import { useState } from "react"
import Link from "next/link"
import { Terminal, Search, ChevronRight, ExternalLink, BookOpen, Code, Zap, Settings, ArrowLeft } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

const INTRO_CONTENT = `
<p>SLAVKO-OS is a deterministic AI orchestration kernel designed for enterprise-grade model management and execution.</p>

<h2>What is SLAVKO-OS?</h2>
<p>SLAVKO-OS provides a formal framework for:</p>
<ul>
  <li>Multi-model orchestration with capability-based routing</li>
  <li>Deterministic state transitions with guard enforcement</li>
  <li>Fibonacci-weighted context prioritization</li>
  <li>Real-time telemetry and audit logging</li>
</ul>

<h2>Key Features</h2>
<ul>
  <li><strong>FCP-1 Protocol</strong> - Formal Capability Protocol for model selection</li>
  <li><strong>Fibonacci Lattice</strong> - Weighted context layers (1-1-2-3-5-8)</li>
  <li><strong>Guard System</strong> - Deterministic transition validation</li>
  <li><strong>Telemetry</strong> - Real-time execution monitoring</li>
</ul>
`

const QUICKSTART_CONTENT = `
<p>Get started with SLAVKO-OS in under 5 minutes.</p>

<h2>1. Create an Account</h2>
<p>Sign up at <code>/auth/sign-up</code> to create your SLAVKO-OS account.</p>

<h2>2. Access the Console</h2>
<p>Once logged in, navigate to the Console to start interacting with the kernel.</p>

<pre><code>$ slavko ~ help
Available commands:
├── /models - List available models
├── /clear - Clear console
├── /status - Show kernel status
└── /config - Show configuration</code></pre>

<h2>3. Execute Your First Query</h2>
<p>Type any query into the console to process it through the selected model.</p>
`

const INSTALLATION_CONTENT = `
<p>Install SLAVKO-OS locally or deploy to your infrastructure.</p>

<h2>Prerequisites</h2>
<ul>
  <li>Node.js 18+</li>
  <li>pnpm or npm</li>
  <li>Supabase project (for authentication)</li>
</ul>

<h2>Installation</h2>
<pre><code>git clone https://github.com/slavko-os/kernel
cd kernel
pnpm install
pnpm dev</code></pre>

<h2>Environment Variables</h2>
<pre><code>NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key</code></pre>
`

const STATE_MACHINE_CONTENT = `
<p>The SLAVKO-OS state machine enforces deterministic transitions between execution states.</p>

<h2>States</h2>
<ul>
  <li><code>IDLE</code> - Ready for input</li>
  <li><code>PENDING</code> - Awaiting processing</li>
  <li><code>RUNNING</code> - Active execution</li>
  <li><code>COMPLETED</code> - Successful completion</li>
  <li><code>FAILED</code> - Error state</li>
  <li><code>CANCELLED</code> - User-cancelled</li>
</ul>

<h2>Transitions</h2>
<pre><code>const TRANSITIONS = {
  idle: ['pending'],
  pending: ['running', 'cancelled'],
  running: ['completed', 'failed', 'cancelled'],
  completed: ['idle'],
  failed: ['idle'],
  cancelled: ['idle'],
}</code></pre>
`

const FIBONACCI_CONTENT = `
<p>The Fibonacci Lattice provides weighted context prioritization using the sequence 1-1-2-3-5-8.</p>

<h2>Layers</h2>
<ul>
  <li><strong>F1 Core (w:1)</strong> - Kernel identity & mode</li>
  <li><strong>F2 Primary (w:1)</strong> - User intent & repository</li>
  <li><strong>F3 Secondary (w:2)</strong> - Validation & readiness</li>
  <li><strong>F4 Tertiary (w:3)</strong> - Depth & compliance</li>
  <li><strong>F5 Quaternary (w:5)</strong> - Deploy & audit</li>
</ul>

<h2>Weight Distribution</h2>
<p>Higher-numbered layers receive more weight, ensuring comprehensive coverage increases with thinking depth.</p>
`

const ORCHESTRATION_CONTENT = `
<p>Model orchestration uses the FCP-1 protocol for capability-based routing.</p>

<h2>selectModel Algorithm</h2>
<pre><code>function selectModel(capability, constraints) {
  return MODELS
    .filter(m => m.capabilities.includes(capability))
    .filter(m => m.latencyMs <= constraints.maxLatency)
    .sort((a, b) => a.cost - b.cost)[0]
}</code></pre>

<h2>Capabilities</h2>
<ul>
  <li><code>SPEC_ENG</code> - Specification engineering</li>
  <li><code>ARCHITECT</code> - System architecture</li>
  <li><code>CODER</code> - Code generation</li>
  <li><code>AUDITOR</code> - Code review & audit</li>
</ul>
`

const CAPABILITIES_CONTENT = `
<p>Capabilities define what operations a model can perform.</p>

<h2>Capability Definition</h2>
<pre><code>interface Capability {
  id: string
  name: string
  requiredDeterminism: number // 0-1
  maxLatencyMs: number
  requiredGuards: GuardType[]
}</code></pre>

<h2>Built-in Capabilities</h2>
<ul>
  <li><code>SPEC_ENG</code> - High determinism, formal output</li>
  <li><code>ARCHITECT</code> - System design, context synthesis</li>
  <li><code>CODER</code> - Code generation, implementation</li>
  <li><code>AUDITOR</code> - Review, compliance checking</li>
  <li><code>EXECUTE_FAST</code> - Low latency, quick responses</li>
</ul>
`

const GUARDS_CONTENT = `
<p>Guards enforce transition validity in the state machine.</p>

<h2>Guard Types</h2>
<pre><code>type GuardType = 
  | 'CAPABILITY_CHECK'
  | 'BUDGET_CHECK'
  | 'LATENCY_CHECK'
  | 'DETERMINISM_CHECK'</code></pre>

<h2>Guard Execution</h2>
<pre><code>function executeGuard(guard: Guard, context: Context): boolean {
  switch (guard.type) {
    case 'CAPABILITY_CHECK':
      return context.model.capabilities.includes(context.capability)
    case 'BUDGET_CHECK':
      return context.tokensRemaining >= guard.params.minTokens
    // ...
  }
}</code></pre>
`

const TELEMETRY_CONTENT = `
<p>Telemetry provides real-time monitoring of kernel execution.</p>

<h2>Metrics</h2>
<ul>
  <li><code>latency_ms</code> - Execution time</li>
  <li><code>tokens_in</code> - Input token count</li>
  <li><code>tokens_out</code> - Output token count</li>
  <li><code>model_id</code> - Selected model</li>
  <li><code>capability</code> - Executed capability</li>
</ul>

<h2>useKernelTelemetry Hook</h2>
<pre><code>const { metrics, subscribe } = useKernelTelemetry()

subscribe('execution', (event) => {
  console.log('Execution:', event)
})</code></pre>
`

const ENVIRONMENT_CONTENT = `
<p>Configure SLAVKO-OS via environment variables.</p>

<h2>Required Variables</h2>
<pre><code>NEXT_PUBLIC_SUPABASE_URL=https://xxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...

# Optional
NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL=http://localhost:3000</code></pre>

<h2>Model API Keys</h2>
<pre><code>OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...
GOOGLE_API_KEY=AIza...</code></pre>
`

const MODELS_CONTENT = `
<p>Configure available models in the model registry.</p>

<h2>Model Definition</h2>
<pre><code>interface ModelProfile {
  id: string
  name: string
  provider: string
  capabilities: Capability[]
  latencyMs: number
  costPer1kTokens: number
  determinism: number
}</code></pre>

<h2>Default Models</h2>
<ul>
  <li>Gemini 3 Flash - Fast inference</li>
  <li>Gemini 3 Pro - High quality</li>
  <li>Claude Sonnet 4 - Balanced</li>
  <li>GPT-4o - Latest GPT</li>
  <li>DeepSeek V3 - Efficient</li>
</ul>
`

const DOCS_SECTIONS = [
  {
    title: "Getting Started",
    icon: Zap,
    items: [
      { title: "Introduction", slug: "introduction", content: INTRO_CONTENT },
      { title: "Quick Start", slug: "quick-start", content: QUICKSTART_CONTENT },
      { title: "Installation", slug: "installation", content: INSTALLATION_CONTENT },
    ],
  },
  {
    title: "Core Concepts",
    icon: BookOpen,
    items: [
      { title: "State Machine", slug: "state-machine", content: STATE_MACHINE_CONTENT },
      { title: "Fibonacci Lattice", slug: "fibonacci-lattice", content: FIBONACCI_CONTENT },
      { title: "Model Orchestration", slug: "model-orchestration", content: ORCHESTRATION_CONTENT },
    ],
  },
  {
    title: "API Reference",
    icon: Code,
    items: [
      { title: "Capabilities", slug: "capabilities", content: CAPABILITIES_CONTENT },
      { title: "Guards", slug: "guards", content: GUARDS_CONTENT },
      { title: "Telemetry", slug: "telemetry", content: TELEMETRY_CONTENT },
    ],
  },
  {
    title: "Configuration",
    icon: Settings,
    items: [
      { title: "Environment", slug: "environment", content: ENVIRONMENT_CONTENT },
      { title: "Models", slug: "models", content: MODELS_CONTENT },
    ],
  },
]

export function DocsContent() {
  const [activeSection, setActiveSection] = useState("introduction")
  const [searchQuery, setSearchQuery] = useState("")

  const currentItem = DOCS_SECTIONS.flatMap((s) => s.items).find((i) => i.slug === activeSection)

  const filteredSections = DOCS_SECTIONS.map((section) => ({
    ...section,
    items: section.items.filter((item) => item.title.toLowerCase().includes(searchQuery.toLowerCase())),
  })).filter((section) => section.items.length > 0)

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/" className="flex items-center gap-3">
              <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center">
                <Terminal className="w-4 h-4 text-background" />
              </div>
              <span className="font-semibold text-foreground">SLAVKO-OS</span>
            </Link>
            <span className="text-muted-foreground">/</span>
            <span className="text-foreground">Documentation</span>
          </div>

          <div className="flex items-center gap-4">
            <Link href="/dashboard">
              <Button variant="outline" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to App
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto flex">
        {/* Sidebar */}
        <aside className="w-64 border-r border-border min-h-[calc(100vh-4rem)] p-6 sticky top-16 overflow-y-auto">
          <div className="relative mb-6">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search docs..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 bg-background border-border"
            />
          </div>

          <nav className="space-y-6">
            {filteredSections.map((section) => (
              <div key={section.title}>
                <div className="flex items-center gap-2 mb-2">
                  <section.icon className="w-4 h-4 text-emerald-500" />
                  <span className="text-sm font-medium text-foreground">{section.title}</span>
                </div>
                <ul className="space-y-1 ml-6">
                  {section.items.map((item) => (
                    <li key={item.slug}>
                      <button
                        onClick={() => setActiveSection(item.slug)}
                        className={`w-full text-left px-3 py-1.5 rounded text-sm transition-colors ${
                          activeSection === item.slug
                            ? "bg-emerald-500/10 text-emerald-500"
                            : "text-muted-foreground hover:text-foreground"
                        }`}
                      >
                        {item.title}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </nav>
        </aside>

        {/* Main content */}
        <main className="flex-1 p-8 max-w-4xl">
          {currentItem && (
            <article className="prose prose-invert max-w-none">
              <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
                <span>Docs</span>
                <ChevronRight className="w-4 h-4" />
                <span className="text-emerald-500">{currentItem.title}</span>
              </div>

              <h1 className="text-3xl font-bold text-foreground mb-6">{currentItem.title}</h1>

              <div
                className="text-muted-foreground space-y-4 [&_h2]:text-xl [&_h2]:font-semibold [&_h2]:text-foreground [&_h2]:mt-8 [&_h2]:mb-4 [&_h3]:text-lg [&_h3]:font-medium [&_h3]:text-foreground [&_h3]:mt-6 [&_h3]:mb-3 [&_pre]:bg-card [&_pre]:border [&_pre]:border-border [&_pre]:rounded-lg [&_pre]:p-4 [&_pre]:overflow-x-auto [&_code]:text-emerald-500 [&_code]:font-mono [&_code]:text-sm [&_ul]:list-disc [&_ul]:pl-6 [&_li]:mb-2"
                dangerouslySetInnerHTML={{ __html: currentItem.content }}
              />

              <div className="mt-12 pt-8 border-t border-border">
                <div className="flex items-center justify-between">
                  <Button variant="outline" className="text-muted-foreground bg-transparent">
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Edit on GitHub
                  </Button>
                </div>
              </div>
            </article>
          )}
        </main>
      </div>
    </div>
  )
}
