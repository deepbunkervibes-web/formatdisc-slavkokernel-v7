/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type ModuleId = "EXECUTION_KERNEL" | "COMPLIANCE_ENGINE" | "FORENSICS_SERVICE"

export type ModuleStatus = "OK" | "DEGRADED" | "BLOCKED"

export interface ModuleTelemetry {
  id: ModuleId
  status: ModuleStatus
  latencyMs: number
  integrityScore: number // 0–100
  lastUpdated: string // ISO
  incidentsLast24h: number
}
