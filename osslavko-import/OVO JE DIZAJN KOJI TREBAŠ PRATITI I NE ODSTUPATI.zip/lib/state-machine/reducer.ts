// ═══════════════════════════════════════════════════════════════════════════════
// REDUCER - v0.2 (FCP-1 Protocol)
// ═══════════════════════════════════════════════════════════════════════════════

import type {
  MachineState,
  Action,
  Status,
  StateEntry,
  CapabilityState,
  CapabilityMachineState,
  GuardResult,
  ModelId,
} from "./types"
import { TRANSITIONS, CAPABILITY_TRANSITIONS } from "./types"
import { getCapability } from "./capabilities"

export const initialState: MachineState = {
  current: "idle",
  history: [],
  context: {
    attempts: 0,
    lastError: null,
    startedAt: null,
    completedAt: null,
  },
}

export const initialCapabilityState: CapabilityMachineState = {
  current: "SPEC_ENG",
  history: [],
  context: {
    iterations: 0,
    lastGuardFailure: null,
    startedAt: null,
    completedAt: null,
  },
}

function createEntry(status: Status, metadata?: Record<string, unknown>): StateEntry {
  return {
    id: crypto.randomUUID(),
    status,
    timestamp: Date.now(),
    metadata,
  }
}

function runGuards(capability: CapabilityState, input: unknown): GuardResult {
  const definition = getCapability(capability)
  if (!definition) {
    return { passed: true, failedGuards: [] }
  }

  const failedGuards: GuardResult["failedGuards"] = []

  for (const guard of definition.guards) {
    if (!guard.check(input)) {
      failedGuards.push({ guard, reason: guard.description })
    }
  }

  return {
    passed: failedGuards.length === 0,
    failedGuards,
  }
}

function canTransition(from: Status, action: Action["type"]): boolean {
  return TRANSITIONS[from]?.includes(action) ?? false
}

function canTransitionCapability(from: CapabilityState, to: CapabilityState): boolean {
  const allowed = CAPABILITY_TRANSITIONS[from]
  return allowed?.includes(to) ?? false
}

export function machineReducer(state: MachineState, action: Action): MachineState {
  const { type, payload } = action

  // Guard: check if transition is valid
  if (!canTransition(state.current, type)) {
    console.warn(`[StateMachine] Invalid transition: ${state.current} -> ${type}`)
    return state
  }

  const now = Date.now()

  switch (type) {
    case "START":
      return {
        ...state,
        current: "pending",
        history: [...state.history, createEntry("pending", payload?.metadata)],
        context: {
          ...state.context,
          attempts: state.context.attempts + 1,
          startedAt: now,
          completedAt: null,
        },
      }

    case "COMPLETE":
      return {
        ...state,
        current: "success",
        history: [...state.history, createEntry("success", payload?.metadata)],
        context: {
          ...state.context,
          lastError: null,
          completedAt: now,
        },
      }

    case "FAIL":
      return {
        ...state,
        current: "failure",
        history: [...state.history, createEntry("failure", payload?.metadata)],
        context: {
          ...state.context,
          lastError: payload?.error ?? "Unknown error",
          completedAt: now,
        },
      }

    case "CANCEL":
      return {
        ...state,
        current: "cancelled",
        history: [...state.history, createEntry("cancelled", payload?.metadata)],
        context: {
          ...state.context,
          completedAt: now,
        },
      }

    case "RETRY":
      return {
        ...state,
        current: "pending",
        history: [...state.history, createEntry("pending", { retry: true, ...payload?.metadata })],
        context: {
          ...state.context,
          attempts: state.context.attempts + 1,
          startedAt: now,
          completedAt: null,
        },
      }

    case "RESET":
      return {
        ...initialState,
        history: [...state.history, createEntry("idle", { reset: true })],
      }

    default:
      return state
  }
}

// Simulate async transition (pending -> running)
// This would be called after START to move to running state
export function runningReducer(state: MachineState): MachineState {
  if (state.current !== "pending") return state

  return {
    ...state,
    current: "running",
    history: [...state.history, createEntry("running")],
  }
}

export type CapabilityAction =
  | { type: "TRANSITION"; to: CapabilityState; input?: unknown; model?: ModelId }
  | { type: "RESET" }
  | { type: "EXECUTE"; input: unknown; model: ModelId }

export function capabilityReducer(state: CapabilityMachineState, action: CapabilityAction): CapabilityMachineState {
  const now = Date.now()

  switch (action.type) {
    case "TRANSITION": {
      // Validate transition
      if (!canTransitionCapability(state.current, action.to)) {
        console.warn(`[FCP-1] Invalid transition: ${state.current} -> ${action.to}`)
        return state
      }

      // Run guards for target capability
      const guardResult = runGuards(action.to, action.input)

      if (!guardResult.passed) {
        const failureMsg = guardResult.failedGuards.map((f) => f.reason).join("; ")
        console.warn(`[FCP-1] Guard failed: ${failureMsg}`)

        return {
          ...state,
          context: {
            ...state.context,
            lastGuardFailure: failureMsg,
          },
          history: [
            ...state.history,
            {
              id: crypto.randomUUID(),
              capability: action.to,
              timestamp: now,
              model: action.model ?? null,
              guardResult,
              input: action.input,
            },
          ],
        }
      }

      return {
        ...state,
        current: action.to,
        history: [
          ...state.history,
          {
            id: crypto.randomUUID(),
            capability: action.to,
            timestamp: now,
            model: action.model ?? null,
            guardResult,
            input: action.input,
          },
        ],
        context: {
          ...state.context,
          iterations: state.context.iterations + 1,
          lastGuardFailure: null,
          startedAt: state.context.startedAt ?? now,
        },
      }
    }

    case "EXECUTE": {
      const guardResult = runGuards(state.current, action.input)

      return {
        ...state,
        history: [
          ...state.history,
          {
            id: crypto.randomUUID(),
            capability: state.current,
            timestamp: now,
            model: action.model,
            guardResult,
            input: action.input,
          },
        ],
        context: {
          ...state.context,
          lastGuardFailure: guardResult.passed ? null : guardResult.failedGuards.map((f) => f.reason).join("; "),
        },
      }
    }

    case "RESET":
      return {
        ...initialCapabilityState,
        context: {
          ...initialCapabilityState.context,
          completedAt: now,
        },
      }

    default:
      return state
  }
}
