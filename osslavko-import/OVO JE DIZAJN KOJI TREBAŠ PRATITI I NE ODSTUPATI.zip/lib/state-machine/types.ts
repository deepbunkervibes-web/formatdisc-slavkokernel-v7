// ═══════════════════════════════════════════════════════════════════════════════
// STATE MACHINE TYPES - v0.2 (FCP-1 Protocol)
// ═══════════════════════════════════════════════════════════════════════════════

export type Status = "idle" | "pending" | "running" | "success" | "failure" | "cancelled"

export type ActionType = "START" | "COMPLETE" | "FAIL" | "CANCEL" | "RESET" | "RETRY"

export interface StateEntry {
  id: string
  status: Status
  timestamp: number
  metadata?: Record<string, unknown>
}

export interface MachineState {
  current: Status
  history: StateEntry[]
  context: {
    attempts: number
    lastError: string | null
    startedAt: number | null
    completedAt: number | null
  }
}

export interface Action {
  type: ActionType
  payload?: {
    error?: string
    metadata?: Record<string, unknown>
  }
}

// Transition map - defines valid state transitions
export const TRANSITIONS: Record<Status, ActionType[]> = {
  idle: ["START"],
  pending: ["CANCEL", "RESET"],
  running: ["COMPLETE", "FAIL", "CANCEL"],
  success: ["RESET"],
  failure: ["RETRY", "RESET"],
  cancelled: ["RESET", "RETRY"],
}

// ═══════════════════════════════════════════════════════════════════════════════
// ═══════════════════════════════════════════════════════════════════════════════

export type CapabilityState = "SPEC_ENG" | "ARCHITECT" | "CODER" | "AUDITOR" | "EXECUTE_FAST"

export type ModelId =
  | "gemini-3-flash"
  | "gemini-3-pro"
  | "deepseek-3.1"
  | "deepseek-3.2"
  | "claude-sonnet-4.5"
  | "claude-haiku-4.5"
  | "copilot"
  | "gpt-oss20"
  | "gpt-oss120"
  | "qwen"

export type GuardFailAction = "REJECT" | "DOWNGRADE" | "ESCALATE"

export interface CapabilityGuard {
  id: string
  description: string
  check: (input: unknown) => boolean
  onFail: GuardFailAction
}

export interface CapabilityDefinition {
  id: CapabilityState
  purpose: string
  guarantees: readonly string[]
  forbidden: readonly string[]

  inputContract: {
    required: readonly string[]
    optional?: readonly string[]
    forbidden?: readonly string[]
  }

  outputContract: {
    structure: "freeform" | "structured" | "code" | "diff" | "table"
    guarantees: readonly string[]
  }

  promptProfile: {
    systemPrompt: string
    temperature: number
    maxTokens?: number
  }

  allowedModels: readonly ModelId[]
  guards: CapabilityGuard[]
}

export interface ModelProfile {
  id: ModelId
  name: string
  supports: readonly CapabilityState[]
  latency: number // ms estimate
  cost: number // relative 1-10
  determinism: "low" | "medium" | "high"
}

export interface OrchestratorConstraints {
  latencyMs?: number
  costTier?: "low" | "medium" | "high"
  determinism?: "strict" | "relaxed"
}

export interface OrchestratorContext {
  capability: CapabilityState
  constraints: OrchestratorConstraints
}

// FCP-1 Transition rules
export const CAPABILITY_TRANSITIONS: Record<CapabilityState, CapabilityState[]> = {
  SPEC_ENG: ["ARCHITECT"],
  ARCHITECT: ["CODER"],
  CODER: ["AUDITOR"],
  AUDITOR: ["SPEC_ENG", "CODER"], // Can loop back
  EXECUTE_FAST: [], // Terminal or non-authoritative
}

export interface GuardResult {
  passed: boolean
  failedGuards: Array<{ guard: CapabilityGuard; reason: string }>
}

export interface CapabilityMachineState {
  current: CapabilityState
  history: Array<{
    id: string
    capability: CapabilityState
    timestamp: number
    model: ModelId | null
    guardResult: GuardResult
    input?: unknown
    output?: unknown
  }>
  context: {
    iterations: number
    lastGuardFailure: string | null
    startedAt: number | null
    completedAt: number | null
  }
}
