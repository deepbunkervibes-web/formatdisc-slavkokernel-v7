// ═══════════════════════════════════════════════════════════════════════════════
// FCP-1: ORCHESTRATOR (Model Selection Algorithm)
// ═══════════════════════════════════════════════════════════════════════════════

import type { CapabilityState, ModelId, ModelProfile, OrchestratorContext, OrchestratorConstraints } from "./types"

// ─────────────────────────────────────────────────────────────────────────────
// Model Registry
// ─────────────────────────────────────────────────────────────────────────────

export const MODEL_PROFILES: ModelProfile[] = [
  {
    id: "gemini-3-flash",
    name: "Gemini 3 Flash",
    supports: ["EXECUTE_FAST"],
    latency: 100,
    cost: 1,
    determinism: "medium",
  },
  {
    id: "gemini-3-pro",
    name: "Gemini 3 Pro",
    supports: ["ARCHITECT", "SPEC_ENG"],
    latency: 500,
    cost: 5,
    determinism: "high",
  },
  {
    id: "deepseek-3.1",
    name: "DeepSeek 3.1",
    supports: ["SPEC_ENG", "ARCHITECT"],
    latency: 400,
    cost: 3,
    determinism: "high",
  },
  {
    id: "deepseek-3.2",
    name: "DeepSeek 3.2",
    supports: ["CODER", "AUDITOR"],
    latency: 450,
    cost: 4,
    determinism: "high",
  },
  {
    id: "claude-sonnet-4.5",
    name: "Claude Sonnet 4.5",
    supports: ["SPEC_ENG", "ARCHITECT", "AUDITOR"],
    latency: 600,
    cost: 7,
    determinism: "high",
  },
  {
    id: "claude-haiku-4.5",
    name: "Claude Haiku 4.5",
    supports: ["CODER", "EXECUTE_FAST"],
    latency: 150,
    cost: 2,
    determinism: "medium",
  },
  {
    id: "copilot",
    name: "GitHub Copilot",
    supports: ["CODER"],
    latency: 200,
    cost: 3,
    determinism: "medium",
  },
  {
    id: "gpt-oss20",
    name: "GPT OSS20",
    supports: ["CODER", "EXECUTE_FAST"],
    latency: 180,
    cost: 2,
    determinism: "medium",
  },
  {
    id: "gpt-oss120",
    name: "GPT OSS120",
    supports: ["ARCHITECT", "SPEC_ENG"],
    latency: 800,
    cost: 8,
    determinism: "high",
  },
  {
    id: "qwen",
    name: "Qwen",
    supports: ["SPEC_ENG"],
    latency: 350,
    cost: 2,
    determinism: "high",
  },
]

// ─────────────────────────────────────────────────────────────────────────────
// Selection Algorithm
// ─────────────────────────────────────────────────────────────────────────────

export interface SelectionResult {
  model: ModelProfile | null
  reason: string
  alternatives: ModelProfile[]
}

export function selectModel(capability: CapabilityState, constraints: OrchestratorConstraints = {}): SelectionResult {
  // Step 1: Filter by capability support
  let candidates = MODEL_PROFILES.filter((m) => m.supports.includes(capability))

  if (candidates.length === 0) {
    return {
      model: null,
      reason: `No models support capability: ${capability}`,
      alternatives: [],
    }
  }

  // Step 2: Filter by determinism requirement
  if (constraints.determinism === "strict") {
    const strictCandidates = candidates.filter((m) => m.determinism === "high")
    if (strictCandidates.length > 0) {
      candidates = strictCandidates
    }
  }

  // Step 3: Filter by cost tier
  if (constraints.costTier) {
    const costMap = { low: 3, medium: 6, high: 10 }
    const maxCost = costMap[constraints.costTier]
    const costFiltered = candidates.filter((m) => m.cost <= maxCost)
    if (costFiltered.length > 0) {
      candidates = costFiltered
    }
  }

  // Step 4: Sort by priority (latency first if specified, otherwise cost)
  if (constraints.latencyMs) {
    candidates.sort((a, b) => a.latency - b.latency)
  } else {
    candidates.sort((a, b) => a.cost - b.cost)
  }

  const selected = candidates[0]
  const alternatives = candidates.slice(1)

  return {
    model: selected,
    reason: constraints.latencyMs
      ? `Selected for lowest latency (${selected.latency}ms)`
      : `Selected for lowest cost (${selected.cost}/10)`,
    alternatives,
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Orchestrator Context Builder
// ─────────────────────────────────────────────────────────────────────────────

export function createOrchestratorContext(
  capability: CapabilityState,
  constraints?: OrchestratorConstraints,
): OrchestratorContext {
  return {
    capability,
    constraints: constraints ?? {},
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Model Lookup
// ─────────────────────────────────────────────────────────────────────────────

export function getModelProfile(id: ModelId): ModelProfile | undefined {
  return MODEL_PROFILES.find((m) => m.id === id)
}

export function getModelsForCapability(capability: CapabilityState): ModelProfile[] {
  return MODEL_PROFILES.filter((m) => m.supports.includes(capability))
}
