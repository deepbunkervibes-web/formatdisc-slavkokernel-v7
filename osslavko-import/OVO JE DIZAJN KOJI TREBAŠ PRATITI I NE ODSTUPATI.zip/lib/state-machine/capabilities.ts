// ═══════════════════════════════════════════════════════════════════════════════
// FCP-1: CAPABILITY DEFINITIONS (Frozen Contracts)
// ═══════════════════════════════════════════════════════════════════════════════

import type { CapabilityDefinition, CapabilityGuard } from "./types"

// ─────────────────────────────────────────────────────────────────────────────
// Guard helper functions
// ─────────────────────────────────────────────────────────────────────────────

function containsCodePatterns(input: unknown): boolean {
  if (typeof input !== "string") return false
  const codePatterns = [/function\s+\w+/, /const\s+\w+\s*=/, /import\s+.*from/, /class\s+\w+/, /=>/, /\{\s*\n.*\n\s*\}/]
  return codePatterns.some((p) => p.test(input))
}

function containsNarrativeTone(input: unknown): boolean {
  if (typeof input !== "string") return false
  const narrativePatterns = [
    /I think/i,
    /we should/i,
    /it would be nice/i,
    /perhaps/i,
    /maybe we could/i,
    /in my opinion/i,
  ]
  return narrativePatterns.some((p) => p.test(input))
}

function containsSolutionContent(input: unknown): boolean {
  if (typeof input !== "string") return false
  const solutionPatterns = [/the solution is/i, /we can fix this by/i, /implement.*as follows/i, /here's how to/i]
  return solutionPatterns.some((p) => p.test(input))
}

// ─────────────────────────────────────────────────────────────────────────────
// SPEC_ENG Definition
// ─────────────────────────────────────────────────────────────────────────────

const SPEC_ENG_GUARDS: CapabilityGuard[] = [
  {
    id: "no-solution",
    description: "No solution content allowed",
    check: (input) => !containsSolutionContent(input),
    onFail: "REJECT",
  },
  {
    id: "no-code",
    description: "No code snippets allowed",
    check: (input) => !containsCodePatterns(input),
    onFail: "REJECT",
  },
  {
    id: "no-narrative",
    description: "Narrative language forbidden",
    check: (input) => !containsNarrativeTone(input),
    onFail: "REJECT",
  },
]

export const SPEC_ENG: CapabilityDefinition = {
  id: "SPEC_ENG",
  purpose: "Transform ambiguous problem statements into formal, deterministic engineering specifications.",

  guarantees: [
    "No solution provided",
    "Formal decomposition only",
    "Deterministic structure",
    "No narrative or persuasive language",
  ],

  forbidden: ["Code", "Implementation suggestions", "Optimization strategies", "Storytelling"],

  inputContract: {
    required: ["problem_statement"],
    forbidden: ["proposed_solution", "code_snippets"],
  },

  outputContract: {
    structure: "structured",
    guarantees: ["Explicit assumptions", "Explicit constraints", "Explicit unknowns", "Actionable next states"],
  },

  promptProfile: {
    systemPrompt: `You are operating in SPEC_ENG mode.
Decompose the input into:
- Assumptions
- Constraints
- Invariants
- Unknowns
- Required decisions
Do NOT propose solutions.
Do NOT write code.
Use neutral, formal language.`,
    temperature: 0,
  },

  allowedModels: ["deepseek-3.1", "qwen", "claude-sonnet-4.5"],
  guards: SPEC_ENG_GUARDS,
}

// ─────────────────────────────────────────────────────────────────────────────
// ARCHITECT Definition
// ─────────────────────────────────────────────────────────────────────────────

const ARCHITECT_GUARDS: CapabilityGuard[] = [
  {
    id: "has-spec",
    description: "Must have formal spec from SPEC_ENG",
    check: (input) => {
      if (typeof input !== "object" || input === null) return false
      return "assumptions" in input || "constraints" in input
    },
    onFail: "ESCALATE",
  },
]

export const ARCHITECT: CapabilityDefinition = {
  id: "ARCHITECT",
  purpose: "Synthesize system architecture from formal specifications.",

  guarantees: [
    "Component boundaries defined",
    "Interface contracts specified",
    "Data flow explicit",
    "No implementation details",
  ],

  forbidden: ["Implementation code", "Specific library choices", "Optimization"],

  inputContract: {
    required: ["formal_spec", "constraints"],
  },

  outputContract: {
    structure: "structured",
    guarantees: ["Component diagram or list", "Interface definitions", "Data flow description"],
  },

  promptProfile: {
    systemPrompt: `You are operating in ARCHITECT mode.
Given a formal specification, produce:
- Component boundaries
- Interface contracts
- Data flow diagrams (textual)
- Dependency graph
Do NOT write implementation code.
Do NOT choose specific libraries.
Focus on structure, not details.`,
    temperature: 0,
  },

  allowedModels: ["gemini-3-pro", "claude-sonnet-4.5", "gpt-oss120"],
  guards: ARCHITECT_GUARDS,
}

// ─────────────────────────────────────────────────────────────────────────────
// CODER Definition
// ─────────────────────────────────────────────────────────────────────────────

const CODER_GUARDS: CapabilityGuard[] = [
  {
    id: "has-architecture",
    description: "Must have architecture from ARCHITECT",
    check: (input) => {
      if (typeof input !== "object" || input === null) return false
      return "components" in input || "interfaces" in input
    },
    onFail: "ESCALATE",
  },
]

export const CODER: CapabilityDefinition = {
  id: "CODER",
  purpose: "Implement code from architecture specifications.",

  guarantees: ["Follows architecture contracts", "Type-safe implementation", "No architectural decisions"],

  forbidden: ["Architectural changes", "New components not in spec"],

  inputContract: {
    required: ["architecture", "component_spec"],
  },

  outputContract: {
    structure: "code",
    guarantees: ["Compilable code", "Follows interface contracts"],
  },

  promptProfile: {
    systemPrompt: `You are operating in CODER mode.
Implement the specified component following:
- The provided architecture
- Interface contracts exactly
- Type definitions provided
Do NOT add new components.
Do NOT change architecture.
Write clean, minimal code.`,
    temperature: 0,
  },

  allowedModels: ["copilot", "claude-haiku-4.5", "deepseek-3.2", "gpt-oss20"],
  guards: CODER_GUARDS,
}

// ─────────────────────────────────────────────────────────────────────────────
// AUDITOR Definition
// ─────────────────────────────────────────────────────────────────────────────

const AUDITOR_GUARDS: CapabilityGuard[] = [
  {
    id: "has-code",
    description: "Must have code to audit",
    check: (input) => {
      if (typeof input !== "string") return false
      return containsCodePatterns(input)
    },
    onFail: "REJECT",
  },
]

export const AUDITOR: CapabilityDefinition = {
  id: "AUDITOR",
  purpose: "Adversarial verification of implementation against contracts.",

  guarantees: ["Contract compliance check", "Security audit", "Edge case analysis", "No fixes provided"],

  forbidden: ["Code modifications", "Suggestions", "Opinions"],

  inputContract: {
    required: ["code", "original_spec", "architecture"],
  },

  outputContract: {
    structure: "table",
    guarantees: ["Violation list with severity", "Contract compliance matrix", "Pass/Fail verdict"],
  },

  promptProfile: {
    systemPrompt: `You are operating in AUDITOR mode.
Audit the provided code against:
- Original specification
- Architecture contracts
- Interface definitions
Report:
- Violations (with severity)
- Contract compliance (pass/fail per contract)
- Security concerns
Do NOT suggest fixes.
Do NOT modify code.
Be adversarial and thorough.`,
    temperature: 0,
  },

  allowedModels: ["deepseek-3.2", "claude-sonnet-4.5"],
  guards: AUDITOR_GUARDS,
}

// ─────────────────────────────────────────────────────────────────────────────
// EXECUTE_FAST Definition
// ─────────────────────────────────────────────────────────────────────────────

export const EXECUTE_FAST: CapabilityDefinition = {
  id: "EXECUTE_FAST",
  purpose: "Low-latency execution for simple, well-defined tasks.",

  guarantees: ["Fast response", "Minimal processing"],

  forbidden: ["Complex reasoning", "Multi-step analysis"],

  inputContract: {
    required: ["simple_task"],
  },

  outputContract: {
    structure: "freeform",
    guarantees: ["Direct answer"],
  },

  promptProfile: {
    systemPrompt: `Execute the task directly. Be concise.`,
    temperature: 0,
    maxTokens: 500,
  },

  allowedModels: ["gemini-3-flash", "claude-haiku-4.5", "gpt-oss20"],
  guards: [],
}

// ─────────────────────────────────────────────────────────────────────────────
// Capability Registry
// ─────────────────────────────────────────────────────────────────────────────

export const CAPABILITIES: Record<string, CapabilityDefinition> = {
  SPEC_ENG,
  ARCHITECT,
  CODER,
  AUDITOR,
  EXECUTE_FAST,
}

export function getCapability(id: string): CapabilityDefinition | undefined {
  return CAPABILITIES[id]
}
