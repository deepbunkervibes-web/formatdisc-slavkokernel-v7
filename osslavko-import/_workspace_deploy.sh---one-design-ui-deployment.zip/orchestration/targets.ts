import { DeploymentTarget } from '../types';

// Define target-specific deployment information
export const deploymentTargetInfo = {
  [DeploymentTarget.Vercel]: {
    token: 'VERCEL_TOKEN',
    command: 'Running `npx vercel --prod`'
  },
  [DeploymentTarget.Netlify]: {
    token: 'NETLIFY_AUTH_TOKEN',
    command: 'Running `npx netlify deploy --prod`'
  },
  [DeploymentTarget.Firebase]: {
    token: 'FIREBASE_TOKEN',
    command: 'Running `npx firebase deploy --only hosting`'
  },
  [DeploymentTarget.AWS]: {
    token: 'AWS Credentials',
    command: 'Uploading build artifacts to AWS S3...'
  },
  [DeploymentTarget.Github]: {
    token: 'GitHub Token',
    command: 'Deploying to GitHub Pages...'
  },
};
