
import { useState, useCallback, useRef } from 'react';
import { DeploymentConfig, LogEntry, DeploymentStatus, DeploymentStage, DeploymentResult } from '../types';
import { generateDeploymentSummary } from '../services/geminiService';
import { deploymentTargetInfo } from '../orchestration/targets';

const initialStatus: DeploymentStatus = {
    stage: DeploymentStage.IDLE,
    message: 'Ready to deploy.'
};

// Abort-aware sleep function
const sleep = (ms: number, signal: AbortSignal) => new Promise((resolve, reject) => {
    const timeout = setTimeout(resolve, ms);
    signal.addEventListener('abort', () => {
        clearTimeout(timeout);
        reject(new DOMException('Aborted', 'AbortError'));
    });
});

export const useDeploymentOrchestrator = () => {
    const [logs, setLogs] = useState<LogEntry[]>([]);
    const [status, setStatus] = useState<DeploymentStatus>(initialStatus);
    const [summary, setSummary] = useState<DeploymentResult[]>([]);
    const abortControllerRef = useRef<AbortController | null>(null);

    const isDeploying = status.stage !== DeploymentStage.IDLE && 
                        status.stage !== DeploymentStage.SUCCESS &&
                        status.stage !== DeploymentStage.FAILED &&
                        status.stage !== DeploymentStage.CANCELLED;

    const addLog = useCallback((message: string, type: LogEntry['type']) => {
        const timestamp = new Date().toLocaleTimeString('en-US', {
            hour12: false,
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
        });
        setLogs(prev => [...prev, { timestamp, message, type }]);
    }, []);

    const updateStatus = useCallback((stage: DeploymentStage, message: string) => {
        setStatus({ stage, message });
    }, []);
    
    const cancelDeployment = useCallback(() => {
        if (abortControllerRef.current) {
            abortControllerRef.current.abort();
            updateStatus(DeploymentStage.CANCELLED, 'Deployment cancelled by user.');
            addLog('Deployment cancellation requested.', 'SYSTEM');
        }
    }, [addLog, updateStatus]);

    const startDeployment = useCallback(async (config: DeploymentConfig) => {
        if (isDeploying) return;

        abortControllerRef.current = new AbortController();
        const { signal } = abortControllerRef.current;

        setLogs([]);
        setSummary([]);
        updateStatus(DeploymentStage.PREPARING, 'Preparing deployment...');
        
        try {
            // SHARED STEPS (PREP, CLONE, INSTALL, BUILD)
            addLog(`Starting new deployment for '${config.projectName}' to ${config.targets.length} target(s)...`, 'SYSTEM');
            await sleep(500, signal);
            
            updateStatus(DeploymentStage.CLONING, 'Cloning repository...');
            addLog(`Cloning repository from '${config.repoUrl}'...`, 'GIT');
            await sleep(1500, signal);
            addLog(`Checking out branch '${config.branch}'...`, 'GIT');
            await sleep(500, signal);

            updateStatus(DeploymentStage.INSTALLING, 'Installing dependencies...');
            addLog("Searching for 'build' script in package.json...", 'BUILD');
            await sleep(700, signal);
            addLog("✔ 'build' script found.", 'SUCCESS');
            addLog(`Installing dependencies with 'npm install'...`, 'BUILD');
            await sleep(2500, signal);

            updateStatus(DeploymentStage.BUILDING, 'Running build script...');
            addLog(`Running build script 'npm run build'...`, 'BUILD');
            await sleep(2000, signal);
            
            // Simulate build failure occasionally (5% chance)
            if (Math.random() < 0.05) throw new Error("Build process failed.");
            addLog(`Build successful. Artifacts ready in 'dist/' folder.`, 'SUCCESS');
            
            // PARALLEL DEPLOYMENT STEPS
            addLog(`--- Starting parallel deployment to ${config.targets.join(', ')} ---`, 'SYSTEM');
            updateStatus(DeploymentStage.DEPLOYING, `Deploying to ${config.targets.length} targets simultaneously...`);

            const deploymentPromises = config.targets.map(async (target) => {
                const targetInfo = deploymentTargetInfo[target];
                
                // Retry loop: attempt = 1 is the initial try
                for (let attempt = 1; attempt <= config.retries + 1; attempt++) {
                    signal.throwIfAborted();
                    try {
                        // STEP: AUTH
                        addLog(`[${target}] Checking for auth token: ${targetInfo.token}...`, 'INFO');
                        await sleep(700, signal);
                        addLog(`[${target}] ✔ ${targetInfo.token} found in environment.`, 'SUCCESS');

                        // STEP: DEPLOYING
                        addLog(`[${target}] ${targetInfo.command}`, 'DEPLOY');
                        await sleep(3000, signal);
                        // Simulate deployment failure occasionally (20% chance)
                        if (Math.random() < 0.2) throw new Error(`Deployment to ${target} failed during upload.`);

                        // STEP: VERIFYING
                        addLog(`[${target}] Verifying deployment...`, 'DEPLOY');
                        await sleep(1500, signal);
                        addLog(`[${target}] ✔ Deployment successful.`, 'SUCCESS');

                        // STEP: SUMMARIZING
                        addLog(`[${target}] Generating deployment summary with Gemini...`, 'INFO');
                        const summary = await generateDeploymentSummary(config.projectName, target);
                        addLog(`[${target}] ${summary}`, 'SUCCESS');

                        return summary; // Success, break the loop and return
                    } catch (error) {
                        if (signal.aborted) {
                           throw new DOMException('Aborted', 'AbortError');
                        }
                        
                        const errorMessage = error instanceof Error ? error.message : `An unknown error occurred.`;
                        addLog(`✖ [${target}] ${errorMessage}`, 'ERROR');
                        
                        const isLastAttempt = attempt > config.retries;
                        
                        if (!isLastAttempt) {
                            // Exponential backoff with jitter to prevent thundering herd
                            // Base delay doubles each attempt: 1s, 2s, 4s...
                            const baseDelay = 1000 * Math.pow(2, attempt - 1);
                            // Add random jitter up to 1s
                            const jitter = Math.random() * 1000;
                            // Cap max delay at 10 seconds
                            const backoffDelay = Math.min(baseDelay + jitter, 10000);
                            
                            addLog(`[${target}] Retrying (${attempt}/${config.retries}) in ${(backoffDelay / 1000).toFixed(1)}s...`, 'SYSTEM');
                            await sleep(backoffDelay, signal);
                        } else {
                            throw new Error(`Deployment to ${target} failed after ${config.retries} retries.`);
                        }
                    }
                }
                // Fallback return (should not be reached due to loop/throw logic)
                throw new Error(`Deployment to ${target} failed unexpectedly.`);
            });

            const results = await Promise.allSettled(deploymentPromises);
            
            if (signal.aborted) {
                throw new DOMException('Aborted', 'AbortError');
            }
            
            const finalSummary: DeploymentResult[] = results.map((result, index) => {
                const target = config.targets[index];
                if (result.status === 'fulfilled') {
                    return { target, status: 'fulfilled', value: result.value as string };
                } else {
                    const reason = result.reason instanceof Error ? result.reason.message : String(result.reason);
                    return { target, status: 'rejected', reason: reason === 'Aborted' ? 'Cancelled by user.' : reason };
                }
            });
            setSummary(finalSummary);

            const failedDeployments = finalSummary.filter(r => r.status === 'rejected' && r.reason !== 'Cancelled by user.');

            if (failedDeployments.length > 0) {
                throw new Error(`${failedDeployments.length} deployment(s) failed. See logs for details.`);
            }

            updateStatus(DeploymentStage.SUCCESS, 'All deployments completed successfully!');
            addLog('Finished. Exit code: 0', 'SYSTEM');

        } catch (error) {
            if (signal.aborted) {
                addLog('✖ Deployment process was cancelled.', 'ERROR');
                updateStatus(DeploymentStage.CANCELLED, 'Deployment cancelled.');
            } else {
                console.error("Deployment Error:", error);
                const errorMessage = error instanceof Error ? error.message : "An unknown error occurred.";
                addLog(`✖ ${errorMessage}`, 'ERROR');
                updateStatus(DeploymentStage.FAILED, 'Deployment failed.');
            }
            addLog('Finished. Exit code: 1', 'SYSTEM');
        } finally {
            abortControllerRef.current = null;
        }
    }, [isDeploying, addLog, updateStatus]);

    return { logs, status, summary, isDeploying, startDeployment, cancelDeployment };
};
