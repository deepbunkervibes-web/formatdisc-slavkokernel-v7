import React from 'react';
import { Header } from './components/Header';
import { ConfigPanel } from './components/ConfigPanel';
import { LogPanel } from './components/LogPanel';
import { SummaryPanel } from './components/SummaryPanel';
import { useDeploymentOrchestrator } from './hooks/useDeploymentOrchestrator';

const App: React.FC = () => {
  const { logs, status, summary, isDeploying, startDeployment, cancelDeployment } = useDeploymentOrchestrator();

  return (
    <div className="bg-gray-900 text-gray-200 min-h-screen font-mono">
      <Header />
      <main className="max-w-screen-2xl mx-auto p-4 lg:p-6 grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8">
        <div className="lg:col-span-1 flex flex-col gap-6 lg:gap-8">
          <ConfigPanel
            onDeploy={startDeployment}
            onCancel={cancelDeployment}
            isDeploying={isDeploying}
            status={status}
          />
          <SummaryPanel summary={summary} />
        </div>
        <div className="lg:col-span-2">
          <LogPanel logs={logs} />
        </div>
      </main>
    </div>
  );
};

export default App;