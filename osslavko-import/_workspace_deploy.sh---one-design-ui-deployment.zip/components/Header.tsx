
import React from 'react';
import { RocketIcon } from './Icons';

export const Header: React.FC = () => {
  return (
    <header className="bg-gray-900/80 backdrop-blur-sm border-b border-cyan-500/20 sticky top-0 z-10">
      <div className="max-w-screen-2xl mx-auto px-4 lg:px-6">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-3">
            <RocketIcon className="w-7 h-7 text-cyan-400" />
            <h1 className="text-2xl font-bold tracking-wider text-gray-100">
              deploy<span className="text-cyan-400">.sh</span>
            </h1>
          </div>
          <span className="text-sm text-gray-500 hidden sm:block">One-design deploy for UI projects</span>
        </div>
      </div>
    </header>
  );
};
