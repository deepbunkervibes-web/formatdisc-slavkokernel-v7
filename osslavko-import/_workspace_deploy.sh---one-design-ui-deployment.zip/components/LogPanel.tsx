import React, { useRef, useEffect } from 'react';
import { LogEntry } from '../types';

interface LogPanelProps {
  logs: LogEntry[];
}

const getLogTypeClasses = (type: LogEntry['type']) => {
    switch (type) {
        case 'INFO': return 'text-gray-400';
        case 'GIT': return 'text-blue-400';
        case 'BUILD': return 'text-purple-400';
        case 'DEPLOY': return 'text-yellow-400';
        case 'SUCCESS': return 'text-green-400 font-bold';
        case 'ERROR': return 'text-red-400 font-bold';
        case 'SYSTEM': return 'text-cyan-400';
        default: return 'text-gray-400';
    }
};

const getLogPrefix = (type: LogEntry['type']) => {
    switch (type) {
        case 'INFO': return '[INFO]  ';
        case 'GIT': return '[GIT]   ';
        case 'BUILD' : return '[BUILD] ';
        case 'DEPLOY': return '[DEPLOY]';
        case 'SUCCESS': return '[SUCCESS]';
        case 'ERROR': return '[ERROR] ';
        case 'SYSTEM': return '[SYSTEM]';
        default: return '[LOG]   ';
    }
}

export const LogPanel: React.FC<LogPanelProps> = ({ logs }) => {
    const logContainerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (logContainerRef.current) {
            logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
        }
    }, [logs]);

  return (
    <div className="bg-black/80 border border-gray-700/50 rounded-lg flex flex-col h-full backdrop-blur-sm lg:max-h-[calc(100vh-10rem)]">
        <div className="flex-shrink-0 p-4 border-b border-gray-700/50">
            <h2 className="text-xl font-bold text-cyan-400">Live Output</h2>
        </div>
      <div ref={logContainerRef} className="p-4 flex-grow overflow-y-auto">
        {logs.length === 0 ? (
             <div className="flex items-center justify-center h-full">
                <p className="text-gray-500">Waiting for deployment to start...</p>
             </div>
        ) : (
            logs.map((log, index) => (
                <div key={index} className="flex text-sm">
                    <span className="text-gray-600 mr-4">{log.timestamp}</span>
                    <span className={`flex-shrink-0 ${getLogTypeClasses(log.type)}`}>{getLogPrefix(log.type)}</span>
                    <span className="ml-2 whitespace-pre-wrap break-words">{log.message}</span>
                </div>
            ))
        )}
      </div>
    </div>
  );
};
