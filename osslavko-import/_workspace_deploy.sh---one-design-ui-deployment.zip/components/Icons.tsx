
import React from 'react';

type IconProps = React.SVGProps<SVGSVGElement>;

export const RocketIcon: React.FC<IconProps> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.59 14.37a6 6 0 0 1-5.84 7.38v-4.82m5.84-2.56a6 6 0 0 0-5.84-7.38v4.82m5.84 2.56l-4.82-5.84m-2.56 5.84l4.82 5.84m6.36-5.84a6 6 0 0 1-7.38 5.84m-2.56-5.84a6 6 0 0 0-7.38 5.84m2.56-5.84l-5.84 4.82m5.84-4.82a6 6 0 0 0 5.84-7.38m-5.84 2.56a6 6 0 0 1-5.84 7.38" />
  </svg>
);

export const TerminalIcon: React.FC<IconProps> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M6.429 9.75 2.25 12l4.179 2.25m0-4.5 5.571 3 5.571-3m-11.142 0L2.25 7.5 12 2.25l9.75 5.25-5.571 3m-5.571 0-4.179 2.25m11.142 0-5.571 3-5.571-3" />
        <path strokeLinecap="round" strokeLinejoin="round" d="m21 12-2.25-1.125-2.25 1.125m-11.142 0L2.25 12l2.25 1.125M6.429 14.25 12 16.5l5.571-2.25" />
    </svg>
);

export const VercelIcon: React.FC<IconProps> = (props) => (
    <svg role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill="currentColor" {...props}>
        <title>Vercel</title>
        <path d="M24 22.525H0l12-21.05 12 21.05z" />
    </svg>
);

export const NetlifyIcon: React.FC<IconProps> = (props) => (
    <svg role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill="currentColor" {...props}>
        <title>Netlify</title>
        <path d="M12.729 24H5.459L16.299 0h7.27L12.729 24zM.459 24H5.25L10.5 15.69l-4.79-8.4L.459 24z" />
    </svg>
);

export const AwsIcon: React.FC<IconProps> = (props) => (
    <svg role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill="currentColor" {...props}>
        <title>Amazon AWS</title>
        <path d="M13.682 1.331 11.34 3.127l.142 1.282c.118.995 2.054.498 2.11-.142l.332-2.936zm-3.336 0L8.004 3.127l.142 1.282c.118.995 2.054.498 2.11-.142l.333-2.936zM7.17 6.223c-1.31 0-1.855.557-1.855 1.342 0 .91.936 1.117 2.227 1.485 1.63.44 2.89.995 2.89 2.53 0 1.514-1.396 2.588-3.64 2.588-2.228 0-3.61-1.05-3.818-2.617l1.74-.285c.142.91.853 1.428 2.055 1.428 1.117 0 1.8-.498 1.8-1.253 0-.825-.676-1.078-2.11-1.485-1.57-.41-2.948-.91-2.948-2.558 0-1.428 1.28-2.5 3.522-2.5 1.942 0 3.322.853 3.522 2.39l-1.683.256c-.17-.797-.825-1.253-1.826-1.253zm13.142 5.093c0 3.35-2.2 5.918-6.17 5.918-4.088 0-6.28-2.54-6.28-5.918 0-3.35 2.197-5.918 6.28-5.918 4.058 0 6.17 2.568 6.17 5.918zm-2.14 0c0-2.227-1.31-4.002-4.03-4.002-2.72 0-4.03 1.775-4.03 4.002 0 2.228 1.31 4.002 4.03 4.002 2.72 0 4.03-1.774 4.03-4.002z" />
    </svg>
);

export const GithubIcon: React.FC<IconProps> = (props) => (
    <svg role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill="currentColor" {...props}>
        <title>GitHub</title>
        <path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12" />
    </svg>
);

export const FirebaseIcon: React.FC<IconProps> = (props) => (
    <svg role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill="currentColor" {...props}>
        <title>Firebase</title>
        <path d="M3.13 12.35l3.33-8.89 3.13 3.13-3 7.99zm14.74-8.89l-9.85 2.5v11.57l5.85-5.85zM9.59 1.1l-3.24 8.62L9.59 13l8.16-2.18z" />
    </svg>
);

export const CheckCircleIcon: React.FC<IconProps> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
  </svg>
);

export const XCircleIcon: React.FC<IconProps> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="m9.75 9.75 4.5 4.5m0-4.5-4.5 4.5M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
  </svg>
);