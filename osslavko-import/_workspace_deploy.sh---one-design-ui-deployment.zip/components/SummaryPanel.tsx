import React from 'react';
import { DeploymentResult, DeploymentTarget } from '../types';
import { AwsIcon, CheckCircleIcon, FirebaseIcon, GithubIcon, NetlifyIcon, VercelIcon, XCircleIcon } from './Icons';

interface SummaryPanelProps {
  summary: DeploymentResult[];
}

const targetIconMap: Record<DeploymentTarget, React.ReactNode> = {
    [DeploymentTarget.Vercel]: <VercelIcon className="w-6 h-6" />,
    [DeploymentTarget.Netlify]: <NetlifyIcon className="w-6 h-6" />,
    [DeploymentTarget.AWS]: <AwsIcon className="w-6 h-6" />,
    [DeploymentTarget.Github]: <GithubIcon className="w-6 h-6" />,
    [DeploymentTarget.Firebase]: <FirebaseIcon className="w-6 h-6" />,
};

const ResultCard: React.FC<{ result: DeploymentResult }> = ({ result }) => {
    const isSuccess = result.status === 'fulfilled';
    const borderColor = isSuccess ? 'border-green-500' : 'border-red-500';
    const statusTextColor = isSuccess ? 'text-green-400' : 'text-red-400';
    
    return (
        <div className={`bg-gray-900/50 p-4 rounded-md border-l-4 ${borderColor}`}>
            <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                    {targetIconMap[result.target]}
                    <span className="font-bold text-gray-200">{result.target}</span>
                </div>
                <div className={`flex items-center gap-1 font-semibold ${statusTextColor}`}>
                    {isSuccess ? <CheckCircleIcon className="w-5 h-5" /> : <XCircleIcon className="w-5 h-5" />}
                    <span>{isSuccess ? 'Success' : 'Failed'}</span>
                </div>
            </div>
            <p className="text-sm text-gray-400 font-sans break-words">
                {isSuccess ? result.value : result.reason}
            </p>
        </div>
    );
};

export const SummaryPanel: React.FC<SummaryPanelProps> = ({ summary }) => {
  if (summary.length === 0) {
    return null; // Don't render anything if there's no summary
  }

  return (
    <div className="bg-gray-800/50 border border-gray-700/50 rounded-lg p-6 flex flex-col space-y-4 backdrop-blur-sm animate-fade-in">
      <h2 className="text-xl font-bold text-cyan-400">
        Deployment Summary
      </h2>
      <div className="flex flex-col space-y-3">
        {summary.map((result) => (
          <ResultCard key={result.target} result={result} />
        ))}
      </div>
    </div>
  );
};