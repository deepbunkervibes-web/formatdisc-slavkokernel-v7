import React, { useState, useMemo } from 'react';
import { DeploymentTarget, DeploymentConfig, DeploymentStatus } from '../types';
import { AwsIcon, GithubIcon, NetlifyIcon, VercelIcon, TerminalIcon, FirebaseIcon, CheckCircleIcon } from './Icons';

interface ConfigPanelProps {
  onDeploy: (config: DeploymentConfig) => void;
  onCancel: () => void;
  isDeploying: boolean;
  status: DeploymentStatus;
}

const TargetCard: React.FC<{
    name: DeploymentTarget,
    icon: React.ReactNode,
    isSelected: boolean,
    onSelect: () => void,
    isDisabled: boolean,
}> = ({ name, icon, isSelected, onSelect, isDisabled }) => {
    const baseClasses = "relative flex flex-col items-center justify-center p-4 border-2 rounded-lg transition-all duration-200 group";
    const disabledClasses = "opacity-50 cursor-not-allowed";
    const enabledClasses = "cursor-pointer transform hover:scale-105";
    
    const selectedClasses = "bg-cyan-500/20 border-cyan-400 shadow-lg shadow-cyan-500/20";
    const unselectedClasses = "bg-gray-800/50 border-gray-700 hover:border-gray-500 hover:bg-gray-700/50";
    
    const iconColorClass = isSelected ? "text-cyan-400" : "text-gray-400 group-hover:text-gray-300";
    const labelColorClass = isSelected ? "text-cyan-100" : "text-gray-400 group-hover:text-gray-200";

    return (
        <div 
            className={`${baseClasses} ${isSelected ? selectedClasses : unselectedClasses} ${isDisabled ? disabledClasses : enabledClasses}`} 
            onClick={!isDisabled ? onSelect : undefined}
        >
            {isSelected && (
                <div className="absolute top-2 right-2">
                    <CheckCircleIcon className="w-5 h-5 text-cyan-400 drop-shadow-md" />
                </div>
            )}
            <div className={`transition-colors duration-200 ${iconColorClass}`}>
                {icon}
            </div>
            <span className={`mt-2 text-sm font-semibold transition-colors duration-200 ${labelColorClass}`}>{name}</span>
        </div>
    );
};

export const ConfigPanel: React.FC<ConfigPanelProps> = ({ onDeploy, onCancel, isDeploying, status }) => {
  const [projectName, setProjectName] = useState('My Awesome App');
  const [repoUrl, setRepoUrl] = useState('https://github.com/user/repo');
  const [branch, setBranch] = useState('main');
  const [retries, setRetries] = useState(2);
  const [targets, setTargets] = useState<DeploymentTarget[]>([DeploymentTarget.Vercel]);

  const handleTargetSelect = (targetToToggle: DeploymentTarget) => {
    setTargets(prev => 
      prev.includes(targetToToggle)
        ? prev.filter(t => t !== targetToToggle)
        : [...prev, targetToToggle]
    );
  };
  
  const isFormValid = useMemo(() => {
    return projectName.trim() !== '' && repoUrl.trim() !== '' && branch.trim() !== '' && targets.length > 0 && retries >= 0;
  }, [projectName, repoUrl, branch, targets, retries]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isFormValid && !isDeploying) {
      onDeploy({ projectName, repoUrl, branch, targets, retries });
    }
  };

  const deployButtonText = targets.length > 0
    ? `Deploy to ${targets.length} Target${targets.length !== 1 ? 's' : ''}`
    : 'Select a Target';

  return (
    <div className="bg-gray-800/50 border border-gray-700/50 rounded-lg p-6 flex flex-col space-y-6 h-full backdrop-blur-sm">
      <h2 className="text-xl font-bold text-cyan-400 flex items-center gap-2">
        <TerminalIcon className="w-6 h-6"/>
        Deployment Configuration
      </h2>
      
      <form onSubmit={handleSubmit} className="flex flex-col space-y-6 flex-grow">
        {/* Input fields */}
        <div>
          <label htmlFor="projectName" className="block text-sm font-medium text-gray-400 mb-1">Project Name</label>
          <input
            type="text"
            id="projectName"
            value={projectName}
            onChange={(e) => setProjectName(e.target.value)}
            className="w-full bg-gray-900 border border-gray-600 rounded-md px-3 py-2 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition"
            placeholder="e.g., My Awesome App"
            disabled={isDeploying}
          />
        </div>
        <div>
          <label htmlFor="repoUrl" className="block text-sm font-medium text-gray-400 mb-1">Git Repository URL</label>
          <input
            type="text"
            id="repoUrl"
            value={repoUrl}
            onChange={(e) => setRepoUrl(e.target.value)}
            className="w-full bg-gray-900 border border-gray-600 rounded-md px-3 py-2 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition"
            placeholder="e.g., https://github.com/user/repo"
            disabled={isDeploying}
          />
        </div>
        <div className="grid grid-cols-2 gap-4">
            <div>
              <label htmlFor="branch" className="block text-sm font-medium text-gray-400 mb-1">Branch</label>
              <input
                type="text"
                id="branch"
                value={branch}
                onChange={(e) => setBranch(e.target.value)}
                className="w-full bg-gray-900 border border-gray-600 rounded-md px-3 py-2 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition"
                placeholder="e.g., main"
                disabled={isDeploying}
              />
            </div>
            <div>
              <label htmlFor="retries" className="block text-sm font-medium text-gray-400 mb-1">Retry Attempts on Failure</label>
              <input
                type="number"
                id="retries"
                min="0"
                max="5"
                value={retries}
                onChange={(e) => setRetries(parseInt(e.target.value, 10))}
                className="w-full bg-gray-900 border border-gray-600 rounded-md px-3 py-2 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition"
                disabled={isDeploying}
              />
            </div>
        </div>


        <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Deployment Targets (select one or more)</label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                <TargetCard name={DeploymentTarget.Vercel} icon={<VercelIcon className="w-8 h-8"/>} isSelected={targets.includes(DeploymentTarget.Vercel)} onSelect={() => handleTargetSelect(DeploymentTarget.Vercel)} isDisabled={isDeploying} />
                <TargetCard name={DeploymentTarget.Netlify} icon={<NetlifyIcon className="w-8 h-8"/>} isSelected={targets.includes(DeploymentTarget.Netlify)} onSelect={() => handleTargetSelect(DeploymentTarget.Netlify)} isDisabled={isDeploying} />
                <TargetCard name={DeploymentTarget.AWS} icon={<AwsIcon className="w-8 h-8"/>} isSelected={targets.includes(DeploymentTarget.AWS)} onSelect={() => handleTargetSelect(DeploymentTarget.AWS)} isDisabled={isDeploying} />
                <TargetCard name={DeploymentTarget.Github} icon={<GithubIcon className="w-8 h-8"/>} isSelected={targets.includes(DeploymentTarget.Github)} onSelect={() => handleTargetSelect(DeploymentTarget.Github)} isDisabled={isDeploying} />
                <TargetCard name={DeploymentTarget.Firebase} icon={<FirebaseIcon className="w-8 h-8"/>} isSelected={targets.includes(DeploymentTarget.Firebase)} onSelect={() => handleTargetSelect(DeploymentTarget.Firebase)} isDisabled={isDeploying} />
            </div>
        </div>
        
        <div className="flex-grow"></div>

        <div className="space-y-4">
            <div className="h-6 text-center text-gray-400 transition-opacity duration-300" style={{ opacity: isDeploying ? 1 : 0 }}>
              {isDeploying && (
                  <p className="text-sm animate-pulse">{status.message}</p>
              )}
            </div>

            {isDeploying ? (
                <button
                    type="button"
                    onClick={onCancel}
                    className="w-full flex items-center justify-center bg-red-600 text-white font-bold py-3 px-4 rounded-md transition-all duration-200 ease-in-out hover:bg-red-500 focus:outline-none focus:ring-4 focus:ring-red-500/50"
                >
                    Cancel Deployment
                </button>
            ) : (
                <button
                    type="submit"
                    disabled={!isFormValid}
                    className="w-full flex items-center justify-center bg-cyan-500 text-gray-900 font-bold py-3 px-4 rounded-md transition-all duration-200 ease-in-out hover:bg-cyan-400 disabled:bg-gray-600 disabled:cursor-not-allowed transform hover:scale-105 disabled:scale-100 focus:outline-none focus:ring-4 focus:ring-cyan-500/50"
                >
                    {deployButtonText}
                </button>
            )}
        </div>
      </form>
    </div>
  );
};