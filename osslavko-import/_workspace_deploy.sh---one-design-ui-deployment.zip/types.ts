export interface LogEntry {
  timestamp: string;
  message: string;
  type: 'INFO' | 'GIT' | 'BUILD' | 'DEPLOY' | 'SUCCESS' | 'ERROR' | 'SYSTEM';
}

export enum DeploymentTarget {
  Vercel = 'Vercel',
  Netlify = 'Netlify',
  AWS = 'AWS S3',
  Github = 'GitHub Pages',
  Firebase = 'Firebase Hosting'
}

export interface DeploymentConfig {
  projectName: string;
  repoUrl: string;
  branch: string;
  targets: DeploymentTarget[];
  retries: number;
}

export interface DeploymentResult {
  target: DeploymentTarget;
  status: 'fulfilled' | 'rejected';
  value?: string; // Success message from Gemini
  reason?: string; // Error message
}

export enum DeploymentStage {
  IDLE = 'IDLE',
  PREPARING = 'PREPARING',
  CLONING = 'CLONING',
  INSTALLING = 'INSTALLING',
  BUILDING = 'BUILDING',
  DEPLOYING = 'DEPLOYING',
  VERIFYING = 'VERIFYING',
  SUMMARIZING = 'SUMMARIZING',
  SUCCESS = 'SUCCESS',
  FAILED = 'FAILED',
  CANCELLED = 'CANCELLED'
}

export interface DeploymentStatus {
  stage: DeploymentStage;
  message: string;
}