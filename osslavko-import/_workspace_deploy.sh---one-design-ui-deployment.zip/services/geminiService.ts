import { GoogleGenAI } from "@google/genai";

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function generateDeploymentSummary(projectName: string, target: string): Promise<string> {
  try {
    // Generate a realistic URL based on the project name and target
    const sanitizedName = projectName.toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
    const randomSuffix = Math.random().toString(36).substring(2, 7);
    
    let deploymentUrl = `https://${sanitizedName}.com`;
    
    if (target.includes('Vercel')) {
      deploymentUrl = `https://${sanitizedName}-${randomSuffix}.vercel.app`;
    } else if (target.includes('Netlify')) {
      deploymentUrl = `https://${sanitizedName}-${randomSuffix}.netlify.app`;
    } else if (target.includes('AWS')) {
      deploymentUrl = `http://${sanitizedName}.s3-website-us-east-1.amazonaws.com`;
    } else if (target.includes('GitHub')) {
      deploymentUrl = `https://username.github.io/${sanitizedName}`;
    } else if (target.includes('Firebase')) {
      deploymentUrl = `https://${sanitizedName}.web.app`;
    }

    const prompt = `Generate a concise, positive, and slightly technical deployment confirmation message for a project named "${projectName}" that was just successfully deployed to "${target}".
    
    Include the following deployment URL in the response: ${deploymentUrl}
    
    Format it as a single success message.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text.trim();
  } catch (error) {
    console.error("Error generating content from Gemini:", error);
    throw new Error("Failed to communicate with Gemini API.");
  }
}